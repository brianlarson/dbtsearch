-- MySQL dump 10.13  Distrib 8.4.8, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: dpvnkagjdf
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sjdagfmtduqanfjnqhconsgoijoaawdqhiui` (`primaryOwnerId`),
  CONSTRAINT `fk_sjdagfmtduqanfjnqhconsgoijoaawdqhiui` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_updhhvyjnklasukuwvdglpnjoftlkwrcheuy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_epakhjbbludxwiwwagnzwynxumwlpcukytsc` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_jdoyfrncrdcqcpznqyucocsdazunysfjjwpx` (`dateRead`),
  KEY `fk_edxnxranljpfetvvciklmqbnruvzmybncdlc` (`pluginId`),
  CONSTRAINT `fk_edxnxranljpfetvvciklmqbnruvzmybncdlc` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gtsdmfefgduixcrxtncchzjmbywjcryuawcs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_amybgbpsbfcgcpeyubuvqotpsdvnvbvooinf` (`sessionId`,`volumeId`),
  KEY `idx_qzobyvfxcaawafypbranjjdvyahkoafxjkuo` (`volumeId`),
  CONSTRAINT `fk_dbwsijwuwkkfxdomhhskdfovpraomxtqidao` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iaturpcvpheoodqdpshqfxkgzkgvwsomiqbm` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `mimeType` varchar(255) DEFAULT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ibzydaxpfyxdmgxvvymxvatgudzdwqdgxkvz` (`filename`,`folderId`),
  KEY `idx_yrlefevebytaumozennxtjulsxwgzpayqsxi` (`folderId`),
  KEY `idx_tajszgezhrphyslxrcgindvjrklahifzbqzy` (`volumeId`),
  KEY `fk_eisrzfkmbcaezjcywtkzkrvhoffoaiycokoe` (`uploaderId`),
  CONSTRAINT `fk_eisrzfkmbcaezjcywtkzkrvhoffoaiycokoe` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hmlfditetkupevkzquggkppqmjyzzowrxlxn` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nkfqwseyjcfnlkfpjqhwllyijyruetgarsuk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pqckahszpjdfzsnubbbnhyziwvctzvkajbsu` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_ozmwyskohzqnzivrlmwcowuimzjmqmmxhdss` (`siteId`),
  CONSTRAINT `fk_bvtnygbjkiqjzrkjkqqzmiwtmcklnwojzzoy` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ozmwyskohzqnzivrlmwcowuimzjmqmmxhdss` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auth_oauth_tokens`
--

DROP TABLE IF EXISTS `auth_oauth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_oauth_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ownerHandle` varchar(255) NOT NULL,
  `providerType` varchar(255) NOT NULL,
  `tokenType` varchar(255) NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `accessToken` text,
  `secret` text,
  `expires` varchar(255) DEFAULT NULL,
  `refreshToken` text,
  `resourceOwnerId` varchar(255) DEFAULT NULL,
  `values` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_qqzjgobzuvowjqvenqwhywgyxxvvwyubekca` (`userId`),
  CONSTRAINT `fk_qqzjgobzuvowjqvenqwhywgyxxvvwyubekca` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bulkopevents`
--

DROP TABLE IF EXISTS `bulkopevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulkopevents` (
  `key` char(10) NOT NULL,
  `senderClass` varchar(255) NOT NULL,
  `eventName` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`key`,`senderClass`,`eventName`),
  KEY `idx_weitsldbxtsyxdknydtfryjpftgppyhjltps` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qjqvyumedofesxcqiflpwelaofpdlouvtyvq` (`groupId`),
  KEY `fk_raespjqgwtptvxirapmlhbzheulqiysavmcq` (`parentId`),
  CONSTRAINT `fk_fxvykarmissmfmqvripwfwchcblrelzpcnlk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_raespjqgwtptvxirapmlhbzheulqiysavmcq` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zrbvxdjdxjjuneolnzbkqdgmwsvbjscfelam` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iaigjbvfsmqehbvmseowpxrmizrphtenomks` (`name`),
  KEY `idx_cffjigavwgzadkpusrctpwissximtxirgemm` (`handle`),
  KEY `idx_xvnsbrrblkgvcxaupugorwmtghuflrqzpnfk` (`structureId`),
  KEY `idx_ykzcrufpgzwhueajtgcfipxtrttpsexdryah` (`fieldLayoutId`),
  KEY `idx_jzpyalcbchqsokrxqtdfwmwywcszsdcgwvbu` (`dateDeleted`),
  CONSTRAINT `fk_pfyjrmjioxdoraktxipoyfrgyurxzezophzd` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zrumtkuibkficyreplbksdhkhqqffgfwsftl` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_onryfxeochbwlzoeqhqmivrsporngdupjjyx` (`groupId`,`siteId`),
  KEY `idx_jekvlqvexmibfxhtxfdkpzglrzyxctsuehrb` (`siteId`),
  CONSTRAINT `fk_ofhqyzeybkrxozvgrvtmrosbdjtbzpmcrriw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_reoxjcgdptyiwomtfugqznoeyeiimhjkwhth` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_wrbxgrslowvjgravniehhxedcydcessppceg` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_juldqjniaotmqycnwlbeekmpgzmbfhfpqrvw` (`siteId`),
  KEY `fk_qmalyptmpgtwrrcppkgzukwqzegmplzbzvpu` (`userId`),
  CONSTRAINT `fk_juldqjniaotmqycnwlbeekmpgzmbfhfpqrvw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nrwqiephavhnkflblrpnrwggnyztblsuftpk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qmalyptmpgtwrrcppkgzukwqzegmplzbzvpu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_nqohrembkgoftireiawtgrxizqthbxpulpll` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_auvtyhvxqerifpgnbvdonfzamkkwiofxvwky` (`siteId`),
  KEY `fk_wcqwgeqwysjrxrjodtorfvnnqubzqikwsrxv` (`fieldId`),
  KEY `fk_zvozzomxpkshixsctlsabppvppdlytqazmkx` (`userId`),
  CONSTRAINT `fk_auvtyhvxqerifpgnbvdonfzamkkwiofxvwky` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hyqkzijeqyvqnokdfswanzchbytqkklgupoq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wcqwgeqwysjrxrjodtorfvnnqubzqikwsrxv` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zvozzomxpkshixsctlsabppvppdlytqazmkx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contentblocks`
--

DROP TABLE IF EXISTS `contentblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contentblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xgkyopjnmteaiswrpearpkxonnyvbvdjfmfn` (`primaryOwnerId`),
  KEY `idx_iqsjkfjkyjscvryllfalukiivisozznvbyov` (`fieldId`),
  CONSTRAINT `fk_tfgedqleccgvjolqczquxcmlsguxbgntvrwb` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uuuszknusrexffngjbrryypjxwzmjamogcdc` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wrqalwhfxljtvbohalzoeipcooqddjsuozmd` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_molrcpbrbeyvqquktogwdlcrbubeiwwttzen` (`userId`),
  CONSTRAINT `fk_molrcpbrbeyvqquktogwdlcrbubeiwwttzen` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uplkvmxohiicdpxljbnauafefzrobbahgchg` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_nndydzruvwwlnmaeljnfimzvcfsplngyfote` (`creatorId`,`provisional`),
  KEY `idx_igpahyxrdzqnbshfzrydunzyuqbsymgtgogg` (`saved`),
  KEY `fk_tbxmnvcguaczrgirlncvdjlylcqsoxvbalhf` (`canonicalId`),
  CONSTRAINT `fk_tbxmnvcguaczrgirlncvdjlylcqsoxvbalhf` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_weltfdrqnzmzsglqmiqkujkwryerjaaaylve` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_niildyvqvqzhmuhczclqolpegywieuujbrmo` (`elementId`,`timestamp`,`userId`),
  KEY `fk_nsgivtqgjtgtuhqzabqapfojcquuykxwqurg` (`userId`),
  KEY `fk_hsfqrlmurexyathfdqvkktknvrasipnglsjl` (`siteId`),
  KEY `fk_cppigcluitwkamknyxliomtkrimbbkcsydhw` (`draftId`),
  CONSTRAINT `fk_cppigcluitwkamknyxliomtkrimbbkcsydhw` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dfegckdrzufiidcslmsqeccdlxfmldcgkeaq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hsfqrlmurexyathfdqvkktknvrasipnglsjl` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nsgivtqgjtgtuhqzabqapfojcquuykxwqurg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fdyrdnrtbafgwyijwfxqskymubebvefufujw` (`dateDeleted`),
  KEY `idx_vjieuflnmemexumjmavvmdqyfzzozlhlneyz` (`fieldLayoutId`),
  KEY `idx_kiuoovlbabsfaqjwwzetgxhqdxmnksohileh` (`type`),
  KEY `idx_lgtmrjrvnzbypudntkzmxupbjnodgldfmrne` (`enabled`),
  KEY `idx_vqrykjfyzfugdubehibtlfevvbzeuvivlwel` (`canonicalId`),
  KEY `idx_kttlisagbaokytbicbkymuvfadqobifpdqdr` (`archived`,`dateCreated`),
  KEY `idx_edfzrwdpmhilvoqwlqxqinuxlvalhtdkfrxx` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_rstoonfcqhoxrsfsxvlzbsfxvbfkzwdpujvl` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_nsgkgzclgqjbluswvrdspsinwghbsxkfcgll` (`draftId`),
  KEY `fk_uzsqpazbfyprpqxmxtlxzqiywppyqjxlbzdp` (`revisionId`),
  CONSTRAINT `fk_crftevxdivfdolksisfycvyyeoyginziwjay` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_nsgkgzclgqjbluswvrdspsinwghbsxkfcgll` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uzsqpazbfyprpqxmxtlxzqiywppyqjxlbzdp` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wwoxpgklhymatmjxzgelcjderokyvmziwdeo` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_jghblnqmhquoaxocmnmiahosenxhhjesseuw` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `idx_vjvxoeyhlmhdpoybzwgwjtzilfnxwdeuhavv` (`sortOrder`),
  KEY `fk_ileizbcpjrqpkkbezcvwkasdekkwhsebhsxn` (`ownerId`),
  CONSTRAINT `fk_haiynjzgufdpgfupfxdaroigcmgggwvxjpca` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ileizbcpjrqpkkbezcvwkasdekkwhsebhsxn` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_afirobsjvgwkhrmscwyowlmfnkgtgueonkiw` (`elementId`,`siteId`),
  KEY `idx_msiduzvcodisvumekfeesgoloqpaerwvuatb` (`siteId`),
  KEY `idx_xhjjtbqyhqywclwdcmdpznqeevsurqfqnjyk` (`title`,`siteId`),
  KEY `idx_cjepnrclvjxgmeunszgksbjtphlnhpdkcyhp` (`slug`,`siteId`),
  KEY `idx_nggziugtxpsmfuubmvpdsykctpnnkxlvymsv` (`enabled`),
  KEY `idx_noliftcdcjsxywkstaogysgvcennkrlemasq` (`uri`,`siteId`),
  CONSTRAINT `fk_hhjysovwtnmlfcsmjfkvwhguqphldrreifby` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jeawtlvwjnznhmelownhqxgdhloembuhpmjk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `status` enum('live','pending','expired') NOT NULL DEFAULT 'live',
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vjiupkenrtuaajczmczpoklwqoysmgzzpxzr` (`postDate`),
  KEY `idx_fcbkpfzykmllajskqntwzncccooxywwyrrpt` (`expiryDate`),
  KEY `idx_rhsaypgdrrxziqeriulianhxnfgrkmdopjju` (`status`),
  KEY `idx_rtxrwdtlbjtzljxgmhiwbwtoveaigrikirjq` (`sectionId`),
  KEY `idx_pnoofzuyjylmciwhkcwdhktvxemwyxakqkne` (`typeId`),
  KEY `idx_jbfbhdfuiguxmkljfbldpjtjeafqzuzkzxrm` (`primaryOwnerId`),
  KEY `idx_aoqsinjeunwmxjlzhavekdpljkxptxggkvvk` (`fieldId`),
  KEY `fk_yuoogbvrynmeozafclbqcxfpploxmxghxflt` (`parentId`),
  CONSTRAINT `fk_ephjlpvxdvegkycxcewzfrnupddjshnivkpy` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fauekljzdhmpgtckvvegwlzcdyqgwcnnooyn` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pzitoqchjzglmctjymfslhxqmjgftxfxwujb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ttohsenicleazwalankrdbzswfkalbtnkamr` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yrqjhygsdheouowiwidmrxlmwptekxghrucd` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yuoogbvrynmeozafclbqcxfpploxmxghxflt` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_perxkinhkfrhzbqjryquisgkcfzpgtwmfpek` (`authorId`),
  KEY `idx_bnutyvzusrxzqqpwrgyskafokunzrjbwzlpe` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_cfpwzikqipjyspkexbuybtkhdudgxrygkfoy` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vaxdacrdiazabudaehlrzpsfhgupoloeyzwv` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `uiLabelFormat` varchar(255) NOT NULL DEFAULT '{title}',
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `allowLineBreaksInTitles` tinyint(1) NOT NULL DEFAULT '0',
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dxiuydpcbssyeyiumxedlbdmmejvobcqjthp` (`fieldLayoutId`),
  KEY `idx_pkymgtjrajggiiowoazqnhlvkgcrvgxepsvo` (`dateDeleted`),
  CONSTRAINT `fk_jqqutxsrxpnxiqadmrjfjytpsbkuxputoduh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eeyffsrgrrgkvkvgehlyodzfxbujijuhikfs` (`dateDeleted`),
  KEY `idx_lzwrrlnhfgaouvvzyhjfwyeftaapyzqulrhu` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iuorhimhdhqkkyfffmpkybgbkcmwgneibjms` (`handle`,`context`),
  KEY `idx_rvitkpblaqyupwifojjzxvejdioxpttvvlxx` (`context`),
  KEY `idx_petgugtsvixvzbkdtkurusddaziqpwkybnom` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_emailtemplates`
--

DROP TABLE IF EXISTS `formie_emailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_emailtemplates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `template` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_fieldlayout_pages`
--

DROP TABLE IF EXISTS `formie_fieldlayout_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_fieldlayout_pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `label` text NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kusmvqezbezehtrmytogwsmndofymazmvsvl` (`layoutId`),
  CONSTRAINT `fk_enirkhcjfnaxnwsdazldopfptpdlflojobkz` FOREIGN KEY (`layoutId`) REFERENCES `formie_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_fieldlayout_rows`
--

DROP TABLE IF EXISTS `formie_fieldlayout_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_fieldlayout_rows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `pageId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bsulhpcphipejeujoynoogtxqmkytslmcrlb` (`layoutId`),
  KEY `idx_rpdsnbshckfyalprvfubacfyonjcwelmsyxn` (`pageId`),
  CONSTRAINT `fk_ahwhnsqancjrxbtdlapwkkclapkyntlvobag` FOREIGN KEY (`pageId`) REFERENCES `formie_fieldlayout_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wpusxbunbxkmuzsakxshkyajnwhfpyklikvs` FOREIGN KEY (`layoutId`) REFERENCES `formie_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_fieldlayouts`
--

DROP TABLE IF EXISTS `formie_fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_fields`
--

DROP TABLE IF EXISTS `formie_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `pageId` int NOT NULL,
  `rowId` int NOT NULL,
  `syncId` int DEFAULT NULL,
  `label` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `settings` mediumtext,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lukrfznytkrobhdvypnfuxqgkwyzefmrrvro` (`layoutId`),
  KEY `idx_euhdmkuqmfzmjqlhhmukwszbmmnaoucsqyex` (`pageId`),
  KEY `idx_vjmaenyqsyqojdjfsqkrfpysjdttnxicropm` (`rowId`),
  KEY `idx_xkzbapidohhiaxfuftnkcbcefidnzghqvpin` (`syncId`),
  KEY `idx_jzszipxetmkrllqbhkgpcioboghbeuikpmru` (`handle`),
  CONSTRAINT `fk_ahyytqwqmwbjkuewzklpsvuauepownfwlpui` FOREIGN KEY (`rowId`) REFERENCES `formie_fieldlayout_rows` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ckijkfhzscmhafxaecsewlofbjpzckkxschq` FOREIGN KEY (`syncId`) REFERENCES `formie_fields` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rjipprsmqlnkmicyxmgqxtfvlurjnrxibnfi` FOREIGN KEY (`pageId`) REFERENCES `formie_fieldlayout_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_scrghlbbmjajaiejduqruvmuzesibbnbhrir` FOREIGN KEY (`layoutId`) REFERENCES `formie_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_forms`
--

DROP TABLE IF EXISTS `formie_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_forms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(64) NOT NULL,
  `settings` mediumtext,
  `layoutId` int DEFAULT NULL,
  `templateId` int DEFAULT NULL,
  `submitActionEntryId` int DEFAULT NULL,
  `submitActionEntrySiteId` int DEFAULT NULL,
  `defaultStatusId` int DEFAULT NULL,
  `dataRetention` enum('forever','minutes','hours','days','weeks','months','years') NOT NULL DEFAULT 'forever',
  `dataRetentionValue` int DEFAULT NULL,
  `userDeletedAction` enum('retain','delete') NOT NULL DEFAULT 'retain',
  `fileUploadsAction` enum('retain','delete') NOT NULL DEFAULT 'retain',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_agpqovpqpedaungcinfconpysoumfxfpkajb` (`layoutId`),
  KEY `idx_iztrnntmnyjmosclrplnxnmncgqpcbruduke` (`templateId`),
  KEY `idx_jvhyeacwdbdszqgvfbzalgsiszrrtecdyozr` (`defaultStatusId`),
  KEY `idx_pjjqoyqookjbydcvoanklzfnchdnjyrdjafw` (`submitActionEntryId`),
  KEY `idx_lpkoormhigjebnncdfiuxpgmkfzriewrackq` (`submitActionEntrySiteId`),
  CONSTRAINT `fk_bjvtrvzhrjctswpssvropvsgrogrwfwccbog` FOREIGN KEY (`submitActionEntryId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ckkgiakochwaufxhfchulblljwncospjidyd` FOREIGN KEY (`defaultStatusId`) REFERENCES `formie_statuses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_gegbfnxztxcssenestwdmksjwbqjlfteypud` FOREIGN KEY (`layoutId`) REFERENCES `formie_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jnxpaxerqhnmymrtenuiwpejghsyevdhhojy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_shxyrszdbjmumvxikyiazwqpemwessmkhicy` FOREIGN KEY (`templateId`) REFERENCES `formie_formtemplates` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_formtemplates`
--

DROP TABLE IF EXISTS `formie_formtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_formtemplates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `template` varchar(255) DEFAULT NULL,
  `useCustomTemplates` tinyint(1) DEFAULT '1',
  `outputCssLayout` tinyint(1) DEFAULT '1',
  `outputCssTheme` tinyint(1) DEFAULT '1',
  `outputJsBase` tinyint(1) DEFAULT '1',
  `outputJsTheme` tinyint(1) DEFAULT '1',
  `outputCssLocation` varchar(255) DEFAULT NULL,
  `outputJsLocation` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uqolhiddaablansebaptepmzqqxdlvzssnwu` (`fieldLayoutId`),
  CONSTRAINT `fk_lyvnwtlbdlkgsnffibtpaeecjtoqexinptyd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_integrations`
--

DROP TABLE IF EXISTS `formie_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_integrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `settings` mediumtext,
  `cache` longtext,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_notifications`
--

DROP TABLE IF EXISTS `formie_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `formId` int NOT NULL,
  `templateId` int DEFAULT NULL,
  `pdfTemplateId` int DEFAULT NULL,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `subject` text,
  `recipients` enum('email','conditions') NOT NULL DEFAULT 'email',
  `to` text,
  `toConditions` text,
  `cc` text,
  `bcc` text,
  `replyTo` text,
  `replyToName` text,
  `from` text,
  `fromName` text,
  `sender` text,
  `content` text,
  `attachFiles` tinyint(1) DEFAULT '1',
  `attachPdf` tinyint(1) DEFAULT '0',
  `attachAssets` text,
  `enableConditions` tinyint(1) DEFAULT '0',
  `conditions` text,
  `customSettings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lsumhsgxdcwqvinywgeenagjqnkxbbixsfsq` (`formId`),
  KEY `idx_ttthnanyuenickkrkpqvxvvuwnbrvbbgirye` (`templateId`),
  KEY `fk_trtktzpfsdnpcmccwpjfpypznznithtmgrzd` (`pdfTemplateId`),
  CONSTRAINT `fk_trtktzpfsdnpcmccwpjfpypznznithtmgrzd` FOREIGN KEY (`pdfTemplateId`) REFERENCES `formie_pdftemplates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xifasvovsrcrdsrtnfllmkgfjwmuqlajlenq` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zxsnvruagbyzahdcpngfkttzyvuwvfaazmxh` FOREIGN KEY (`templateId`) REFERENCES `formie_emailtemplates` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_payments`
--

DROP TABLE IF EXISTS `formie_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `integrationId` int NOT NULL,
  `submissionId` int NOT NULL,
  `fieldId` int NOT NULL,
  `subscriptionId` int DEFAULT NULL,
  `amount` decimal(14,4) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `status` enum('pending','redirect','success','failed','processing') NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `message` text,
  `redirectUrl` text,
  `note` mediumtext,
  `response` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_extpizjnfqzpfrmartzwdedlfvmzemjaqvxe` (`integrationId`),
  KEY `idx_pdrtszdvuhmooxrnosvmobtweonqfgojrtna` (`fieldId`),
  KEY `idx_ngrqntrekojuuqbztglfgwhxjghcphtijmer` (`reference`),
  KEY `fk_ornclflusmsmvdgtsguhpaddleplmiqijgot` (`submissionId`),
  KEY `fk_fgibypyswgutfqwwdgtzkuuvzdfnslhlrlvy` (`subscriptionId`),
  CONSTRAINT `fk_ajegzlnyfuixaixpbnljggjjefmxispqqxfa` FOREIGN KEY (`fieldId`) REFERENCES `formie_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fgibypyswgutfqwwdgtzkuuvzdfnslhlrlvy` FOREIGN KEY (`subscriptionId`) REFERENCES `formie_payments_subscriptions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ornclflusmsmvdgtsguhpaddleplmiqijgot` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_stkjkvemulcgzzezsszndlrngtvmbwdjuwmx` FOREIGN KEY (`integrationId`) REFERENCES `formie_integrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_payments_plans`
--

DROP TABLE IF EXISTS `formie_payments_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_payments_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `integrationId` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `reference` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `planData` text,
  `isArchived` tinyint(1) NOT NULL,
  `dateArchived` datetime DEFAULT NULL,
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_opfcaqdqbdmrjldtpcvrurdaixayylhbgcox` (`handle`),
  KEY `idx_pnuxdzzbxxcowteajngpwbvznpsnllmhbsgz` (`integrationId`),
  KEY `idx_zkfjlrshizvrfztfylbtxssjkcnyjofmfdao` (`reference`),
  CONSTRAINT `fk_rwfwmvpkrdnoxnoxshyykevdcttjwkfbsbtb` FOREIGN KEY (`integrationId`) REFERENCES `formie_integrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_payments_subscriptions`
--

DROP TABLE IF EXISTS `formie_payments_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_payments_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `integrationId` int DEFAULT NULL,
  `submissionId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `planId` int DEFAULT NULL,
  `reference` varchar(255) NOT NULL,
  `subscriptionData` text,
  `trialDays` int NOT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `hasStarted` tinyint(1) NOT NULL DEFAULT '1',
  `isSuspended` tinyint(1) NOT NULL DEFAULT '0',
  `dateSuspended` datetime DEFAULT NULL,
  `isCanceled` tinyint(1) NOT NULL,
  `dateCanceled` datetime DEFAULT NULL,
  `isExpired` tinyint(1) NOT NULL,
  `dateExpired` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mawanhfudbezbdbdqfwvooxsiewcyaakcqme` (`integrationId`),
  KEY `idx_pfgkeoipadohqfxiflamkkpbapeyxalmjxfn` (`submissionId`),
  KEY `idx_kzrtwqnuftahxxarumchptvuyuhjbbbvbhxu` (`fieldId`),
  KEY `idx_bosjdcpaeqteajrglmjgjvkkukthmzakxdgm` (`planId`),
  KEY `idx_jnjenzfoigydshutskrctwcagfvadcpksxgn` (`reference`),
  KEY `idx_yrfdfeoqjypdkyvgbsrqflxptfcpadtirakc` (`nextPaymentDate`),
  KEY `idx_jbpwixkeizdhuwywnszomochvtgyvezodoqb` (`dateExpired`),
  KEY `idx_mzexgzjbqhmhvjxfpyiurqxplqosqjbaeayf` (`dateExpired`),
  CONSTRAINT `fk_jsgkqllraonfuashcsdgyimsvhzaqppuzqii` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_khspybrvbfjwhgsbsefieajplgvrsjubaosb` FOREIGN KEY (`fieldId`) REFERENCES `formie_fields` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_lbtrvmvyijujtjuxpfbiuwxwhbosuqpcxykd` FOREIGN KEY (`integrationId`) REFERENCES `formie_integrations` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_utlatdigrjvcqpdvqikqyfnqaekxvbpiskik` FOREIGN KEY (`planId`) REFERENCES `formie_payments_plans` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_pdftemplates`
--

DROP TABLE IF EXISTS `formie_pdftemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_pdftemplates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `template` varchar(255) NOT NULL,
  `filenameFormat` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_relations`
--

DROP TABLE IF EXISTS `formie_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gxbanvtoailrdfeuzgwqxkwljuubfgceopdm` (`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_sszmfhtkzwpbrvqfnyrcfofugvwcwkzboidc` (`sourceId`),
  KEY `idx_mlgedgvkcjvtpgiewaliohogrojetupldhiw` (`targetId`),
  KEY `idx_ybtxnpqsdxvlupyigvptvvrmgpfktmlhuzbu` (`sourceSiteId`),
  CONSTRAINT `fk_lszmnmdiiihethsrecmbcldubwefnhrozyfg` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tzwlimyqnvqfingdrtziornotdbsfitirfeo` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vbnqvpoliftycfrdbyebkmfcwvgnzdnqyqlt` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_sentnotifications`
--

DROP TABLE IF EXISTS `formie_sentnotifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_sentnotifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `formId` int DEFAULT NULL,
  `submissionId` int DEFAULT NULL,
  `notificationId` int DEFAULT NULL,
  `subject` text,
  `to` text,
  `cc` text,
  `bcc` text,
  `replyTo` text,
  `replyToName` text,
  `from` text,
  `fromName` text,
  `sender` text,
  `body` mediumtext,
  `htmlBody` mediumtext,
  `info` text,
  `success` tinyint(1) DEFAULT NULL,
  `message` text,
  `dateCreated` datetime DEFAULT NULL,
  `dateUpdated` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_hrmpdjncqxoygumpiqypgkjfntkkblihjqdy` (`formId`),
  KEY `fk_ezmqfjklwyffmuyjdroettgfqujtbbqpvvgp` (`submissionId`),
  KEY `fk_gwhbmbzmyblrydkdwmmtdvojhtwzlspljjto` (`notificationId`),
  CONSTRAINT `fk_ezmqfjklwyffmuyjdroettgfqujtbbqpvvgp` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_gwhbmbzmyblrydkdwmmtdvojhtwzlspljjto` FOREIGN KEY (`notificationId`) REFERENCES `formie_notifications` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hrmpdjncqxoygumpiqypgkjfntkkblihjqdy` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ookleavvqkkvrlyyvsvdxpnseoxylzblmeym` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_statuses`
--

DROP TABLE IF EXISTS `formie_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `color` enum('green','orange','red','blue','yellow','pink','purple','turquoise','light','grey','black') NOT NULL DEFAULT 'green',
  `description` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `isDefault` tinyint(1) DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_stencils`
--

DROP TABLE IF EXISTS `formie_stencils`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_stencils` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `data` mediumtext,
  `templateId` int DEFAULT NULL,
  `submitActionEntryId` int DEFAULT NULL,
  `submitActionEntrySiteId` int DEFAULT NULL,
  `defaultStatusId` int DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dhvkosxqyrzprerfyhdjpyfvqdapkhrvvzuj` (`templateId`),
  KEY `idx_olnacahfyojerityknbrjiaxmzdxgisjximm` (`defaultStatusId`),
  CONSTRAINT `fk_gcrtznmtejpkrfwwkiyguowlysqtlyitaxgj` FOREIGN KEY (`templateId`) REFERENCES `formie_formtemplates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_odnlyvvynsjeskjiipkxflftozonngzjjvxk` FOREIGN KEY (`defaultStatusId`) REFERENCES `formie_statuses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formie_submissions`
--

DROP TABLE IF EXISTS `formie_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_submissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` json DEFAULT NULL,
  `formId` int NOT NULL,
  `statusId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `isIncomplete` tinyint(1) DEFAULT '0',
  `isSpam` tinyint(1) DEFAULT '0',
  `spamReason` text,
  `spamClass` varchar(255) DEFAULT NULL,
  `snapshot` text,
  `ipAddress` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jelsywtvtwiyrukvwztufgzzmhjgjoguxssq` (`formId`),
  KEY `idx_iqablwtkemgdwzkxntkokjqdycpdyapahofm` (`statusId`),
  KEY `idx_lipyxlbxojhcavybiocljpenkdiqskkmkpmj` (`userId`),
  CONSTRAINT `fk_gahyzududeralvzekjjzmcfkuarxytdfquwy` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lmodwhbheuhoindvoxujusbtvxlyrvsdijen` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_nddlkkavwelormoyisumpsnvsmsqrollhipg` FOREIGN KEY (`statusId`) REFERENCES `formie_statuses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qjpuujykqoggaazvthwarwxxspbhndskqjbr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gkuhmaeowjvxyiewrlkwwlewqexbubogtuuh` (`name`),
  KEY `idx_tfkthxnplimxwujhbaraeuhlgsnlnqxfapcl` (`handle`),
  KEY `idx_qenwrkbhryzcygdowixxfiwhpuysrycssqrp` (`fieldLayoutId`),
  KEY `idx_ooqahrrvgfsnkuofjdonkqmwtpzdpclrvhtb` (`sortOrder`),
  CONSTRAINT `fk_sacvxmecghyxaupomxkyrdlitoedzpdmkufo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tctkcqjtysxcvxoimwvcnwpqarkgkosgzuav` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mbzmfvuhrnqsofpjezpzggxwwgofcijqnhak` (`accessToken`),
  UNIQUE KEY `idx_kffsvywadmaehwklcvbzbdnwrlafcqoewsqa` (`name`),
  KEY `fk_wiuofkflblkcmocmuuwsznxktwcjcoakgrvk` (`schemaId`),
  CONSTRAINT `fk_wiuofkflblkcmocmuuwsznxktwcjcoakgrvk` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jgavddjcgatmbcocmkhsyexpnvytwioxkdxu` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hcbuxczgelioplgemirqizadmcachcgumqkn` (`name`),
  KEY `idx_fdjctfzwhcmdkjfykirqqetyauabfbdbzvdm` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_euqlnppmjjodpxeqxljjsgehqzexigvyvwcp` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xhfmhhtacndkmzgjieigpccgiadftvidkizp` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_jnmvumvivgxsqcmxebofbkphigxpnlofgcta` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_cigftlftmdldbcofhslfclrgsabnoitezjpz` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=361 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ncixrpcknuobndlbokuaqzgxzuhoubeowxtw` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_lonhqlcmebwksiubvoieppridyvnrroflmjy` (`sourceId`),
  KEY `idx_wnsatuffkpcjzzdyccjkgcktuwlocgzdlpvo` (`targetId`),
  KEY `idx_upoprbgouhnoshrzbhyxoteolvtnoipcqmqd` (`sourceSiteId`),
  CONSTRAINT `fk_idhopznuqajxjvuuwcuwivwjvcbrbkgurzqk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kscdgbqhrdbxowhzvrsxerzbjowpfmlqmojn` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ugqsiympvnfipmsmcuapvqwninxhkxgrbily` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_whmeeqijueqmgszlewrvugghngpgcrqwtvnx` (`canonicalId`,`num`),
  KEY `fk_ftusbdubqmskuqxpxatskmlwgdjuifjpqsgu` (`creatorId`),
  CONSTRAINT `fk_ftusbdubqmskuqxpxatskmlwgdjuifjpqsgu` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_poihfafdybckyotyvpynufnglnykzpbtgaej` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_howftmpwtvbnboovsarwidajedytwnnojuwn` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindexqueue`
--

DROP TABLE IF EXISTS `searchindexqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bcpzkgaphearpjbtbutmhwzbgpybztijhawb` (`elementId`,`siteId`,`reserved`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindexqueue_fields`
--

DROP TABLE IF EXISTS `searchindexqueue_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue_fields` (
  `jobId` int NOT NULL,
  `fieldHandle` varchar(255) NOT NULL,
  PRIMARY KEY (`jobId`,`fieldHandle`),
  UNIQUE KEY `idx_ylkwmoefxyyfwlikdcaspwmzljqmtzjkpeic` (`jobId`,`fieldHandle`),
  CONSTRAINT `fk_lbxkueafuoyxfilerfztsqqmnvvrssdrcpzi` FOREIGN KEY (`jobId`) REFERENCES `searchindexqueue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zygyovqtqyhyapkawjbuymhypstddnnxbrga` (`handle`),
  KEY `idx_imckjbyhavglbatycwvlcyrddfxswnnqhhvs` (`name`),
  KEY `idx_cntiquhfccpbvfgaylfzxiutvyipumzpbdrx` (`structureId`),
  KEY `idx_dyrkaxqhzttcrvcuelojstczobkvbmokeagm` (`dateDeleted`),
  CONSTRAINT `fk_bpfgzjoymvvdoxnseivbklyffmctivyjvjin` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_lerygecqeixywkuvfglzcgyhrzgjzfjvszwn` (`typeId`),
  CONSTRAINT `fk_eglqjfhrrsjtbiljmksfeasjevgmbcdassop` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lerygecqeixywkuvfglzcgyhrzgjzfjvszwn` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yiiluorvhhjwfeywqnsixavwxgqcqgmwfktw` (`sectionId`,`siteId`),
  KEY `idx_qrlpoohvheqjqumcffwfbrqfgmbjpbmjasec` (`siteId`),
  CONSTRAINT `fk_uoqfugoxksdgkgbnoohpgvwnwmfkwdsgwwua` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xhkrqxgqknbnkoimtrfcrxeqyrbjibelnmbi` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yqojtpnuwwyjyznskkizflntralaviysnhus` (`uid`),
  KEY `idx_hexnbcztnxohtpcrqhqdynrxrjfvgvuxfcot` (`token`),
  KEY `idx_jkxzdogzuiygbkzikobqhhdusrtdxbqzrmqr` (`dateUpdated`),
  KEY `idx_vksonscovdkwlgnkbjvqgbmwwruuovjaqkgy` (`userId`),
  CONSTRAINT `fk_pfdkdoxkavzqcajsrakjlbjhfwxrhxgduplt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nzfckmtvalbexchartjzkdjdypeokjgujkhv` (`userId`,`message`),
  CONSTRAINT `fk_tlarfwtlcntposvkjewkuendprcosgucfwkr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gbjzbkubslygmakdedggubwjtkgirmdncswv` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_krapaacvjskttuprasktditnaceztzhtxzbb` (`dateDeleted`),
  KEY `idx_jhtddukryhwkgyuacrsxeextvattpuvvxbvs` (`handle`),
  KEY `idx_ydggkomttzfbjyqyofkbbfbwoybaxfwrypwd` (`sortOrder`),
  KEY `fk_kpmriwgvefbziwrgdoyevkhtxhrdbcoomqet` (`groupId`),
  CONSTRAINT `fk_kpmriwgvefbziwrgdoyevkhtxhrdbcoomqet` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_vxjekahruonyfvgkrtfvqfvwxynyptqitcox` (`userId`),
  CONSTRAINT `fk_vxjekahruonyfvgkrtfvqfvwxynyptqitcox` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_eeaeorfsbmefxcokjwuwweauwefmvdvzbuha` (`structureId`,`elementId`),
  KEY `idx_yuffoyzbfnkmndffpqrlwyjhfqyrlxafcbjl` (`root`),
  KEY `idx_jboopwrndpopymmwhbrnfzlvryroafqgsamr` (`lft`),
  KEY `idx_mgfgvkjdybmfgsdcfttyyakaqsslsepyewyn` (`rgt`),
  KEY `idx_uljyrsppdfyyvnuuslpedaruxvgtukjddoxm` (`level`),
  KEY `idx_vfsptvwnisiqamodlduzuxpvbvfsosfbwtwq` (`elementId`),
  CONSTRAINT `fk_tlrvnrwiedyassgssxokyqgecpuzgetaexaq` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jdblthvgzrzetbjdzwlnmjjbkwncuwfuejqa` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aoikhmbxjkkpcblgbgmpxcyrxihnmrjkavyy` (`key`,`language`),
  KEY `idx_nhigfxhmnevfpwezxzjylqsuwwskztibxlcf` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fazrrudwowqfclfjfurksdlursddogekvymt` (`name`),
  KEY `idx_pnsqetocpmdxflyavzdcbcccqbawnssyazuh` (`handle`),
  KEY `idx_lxiepuewdenfmonxfiqomakawotojerkmagq` (`dateDeleted`),
  KEY `fk_qczmnggviszwpssmgkmetkluidamxvomavzj` (`fieldLayoutId`),
  CONSTRAINT `fk_qczmnggviszwpssmgkmetkluidamxvomavzj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yuadjzldlzzcgjdsjfuxqsuhjajzgiwuvnzg` (`groupId`),
  CONSTRAINT `fk_iimszkjsrtluyjqnzbebzauosjnuargchxdb` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vmqditozkbmgbzjiyespdifexhdgiolqfwmv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_elvspohiubdnupqptisyczwyyjetpwmcdvec` (`token`),
  KEY `idx_ukpurzowlfvcjwsvvqxybysjijqfrolfzdqs` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zceliapnendgdymuflzccdiqohzxzwxlwxgq` (`handle`),
  KEY `idx_xixklbjzkxnpaeyqsbhzqjuwpwuupomlonug` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_doxbxtvlsmjbssoiucvmqchqvivoohwrbanp` (`groupId`,`userId`),
  KEY `idx_smdoqxndmvtytgcvybaqancilszwbjnygwfm` (`userId`),
  CONSTRAINT `fk_eyvngupgzamfhzhynixghlyntkyufydlobsf` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ontutuceuxuqictbtwdkwtcjgrodbzwkaohq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vqxqkmwuccvroayhdzxhnglajrenfxgmizsf` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uoweeqyahwycitoxylwsutgabdnoudzisxvf` (`permissionId`,`groupId`),
  KEY `idx_nakfvywirkhenhulfigjolliuekyyphysmnl` (`groupId`),
  CONSTRAINT `fk_jkgfngycyclxmbhjcqtocmarzrurxotsphtp` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rwzmwnysjreugcqsiljzdrmmaahwrcnvhzbn` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iktzwwebcjmfmvcqyazvrigplnbouxewnbpq` (`permissionId`,`userId`),
  KEY `idx_dhyijmsvosefdusyeewhwcatlxnjqhkwxtwo` (`userId`),
  CONSTRAINT `fk_xishesjxhbbswyjarozzezdmquyemlidoxyp` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yphxswgzcplpcdjvifarelbfblsgbrdxhfnj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_qkwzkizehstusvcmuikunrbkpyfxwkqqdqmr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xbiopjaxsvbxyblchsigopidebvnmkuowbln` (`active`),
  KEY `idx_iithnpcldtmamdvmbvgguybopirkicrdgtlu` (`locked`),
  KEY `idx_xcdgqeheazjvqyevwcmvfyynqvboxiqvomau` (`pending`),
  KEY `idx_okwzobatrojwibdocggomrxaebamrrfpqypf` (`suspended`),
  KEY `idx_qtigvwcxshbyokclanehgrrbyrenwvzlewxl` (`verificationCode`),
  KEY `idx_ilfirsuwxmyyhyrrwvoddzhyvvgtyqcwyqmg` (`email`),
  KEY `idx_rjbemuqhjznhwekzdzzzyghllincsinogvty` (`username`),
  KEY `fk_xjhkazqlfhtutosqfcthnpaijmtikrdnzxfg` (`photoId`),
  KEY `fk_iusqgnowmjqkviudmavanlfbegmssggtjerz` (`affiliatedSiteId`),
  CONSTRAINT `fk_iusqgnowmjqkviudmavanlfbegmssggtjerz` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mygouvbkwwvloexkenyhyxppskkracdtjvpt` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xjhkazqlfhtutosqfcthnpaijmtikrdnzxfg` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fqhvftvecozpmbrrnqkwltycdljxoyipxuzk` (`name`,`parentId`,`volumeId`),
  KEY `idx_avjrrkktxrbafbfpsivvnwnswvsvbzxtmcpq` (`parentId`),
  KEY `idx_qxdnribityiixlkkizapjbeusntxktowavxo` (`volumeId`),
  CONSTRAINT `fk_cdmkzlkjnvqfajxgbqqegvptedaqagxyxpce` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_exrtqdtrmvfpbwjiacqxlgdwoezgkauozpnl` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vvuhvgzggskzzssiddvbfqgkcbeavfwnopht` (`name`),
  KEY `idx_yalahbqzvqohrnslngdpooqipaauhsgzgsen` (`handle`),
  KEY `idx_fvfsjigocylptydjpdagvtqpmwbderjtmuns` (`fieldLayoutId`),
  KEY `idx_jiblmgwqziyqitzrwjjbegqhzksgbcekckye` (`dateDeleted`),
  CONSTRAINT `fk_ioxzymvoybuoxswegppvfoglaynihjksnizt` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_uiglqzqtouvdwsysjomywfnrfsgfpzykxkuw` (`userId`),
  CONSTRAINT `fk_uiglqzqtouvdwsysjomywfnrfsgfpzykxkuw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vzdmuaxxmybldwwpiccbaobmrudpstgwhege` (`userId`),
  CONSTRAINT `fk_wkjzzlbnncwajizsmwnohjocmwlspdzpjdyw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'dpvnkagjdf'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-24 17:36:21
-- MySQL dump 10.13  Distrib 8.4.8, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: dpvnkagjdf
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (9,1,3,1,'denys-nevozhai-z0nVqfrOqWA-unsplash.jpg','image/jpeg','image','',NULL,NULL,2716904,NULL,NULL,NULL,'2026-03-17 05:55:07','2026-03-15 19:05:52','2026-03-17 05:55:42'),(10,1,3,1,'pexels-steve-1690351.jpg','image/jpeg','image','',NULL,NULL,2764109,NULL,NULL,NULL,'2026-03-17 05:55:06','2026-03-15 19:06:49','2026-03-17 05:55:41'),(36,1,3,1,'dbtsearch-icon.png','image/png','image',NULL,NULL,NULL,104749,NULL,NULL,NULL,'2026-03-17 05:55:09','2026-03-17 04:17:56','2026-03-17 05:55:41'),(37,1,3,1,'dbtsearch-logo.svg','text/plain','image',NULL,100,100,5060,NULL,NULL,NULL,'2026-03-17 05:55:09','2026-03-17 04:17:56','2026-03-17 05:55:40'),(38,1,7,1,'acp-associated-clinic.webp','image/webp','image',NULL,NULL,NULL,16026,NULL,NULL,NULL,'2026-03-17 05:55:04','2026-03-17 04:19:06','2026-03-17 05:55:46'),(39,1,7,1,'advanded-behavioral-health-inc.png','image/png','image',NULL,NULL,NULL,27474,NULL,NULL,NULL,'2026-03-17 05:55:07','2026-03-17 04:19:06','2026-03-17 05:55:45'),(40,1,7,1,'align-your-soul.jpg','image/avif','image',NULL,NULL,NULL,83250,NULL,NULL,NULL,'2026-03-17 05:55:08','2026-03-17 04:19:06','2026-03-17 05:55:43'),(41,1,7,1,'art-of-validation-and-change.jpg','image/jpeg','image',NULL,NULL,NULL,18588,NULL,NULL,NULL,'2026-03-17 05:55:10','2026-03-17 04:19:07','2026-03-17 05:55:43'),(42,1,7,1,'asc-psychological-services.webp','image/webp','image',NULL,NULL,NULL,5328,NULL,NULL,NULL,'2026-03-17 05:55:06','2026-03-17 04:19:08','2026-03-17 05:55:46'),(43,1,7,1,'autonomy-couseling.jpg','image/avif','image',NULL,NULL,NULL,15446,NULL,NULL,NULL,'2026-03-17 05:55:05','2026-03-17 04:19:08','2026-03-17 05:55:44'),(44,1,7,1,'choices-psychotherapy.png','image/png','image',NULL,NULL,NULL,11731,NULL,NULL,NULL,'2026-03-17 05:55:07','2026-03-17 04:19:09','2026-03-17 05:55:44'),(45,1,7,1,'dbt-associates-llp.png','image/png','image',NULL,NULL,NULL,16807,NULL,NULL,NULL,'2026-03-17 05:55:10','2026-03-17 04:19:09','2026-03-17 05:55:45'),(46,1,7,1,'meridian-behavioral-health.svg','image/svg+xml','image',NULL,100,100,4608,NULL,NULL,NULL,'2026-03-17 05:55:05','2026-03-17 04:19:09','2026-03-17 05:55:44'),(47,1,7,1,'tiny-tree-counseling.png','image/png','image',NULL,NULL,NULL,66543,NULL,NULL,NULL,'2026-03-17 05:55:05','2026-03-17 04:19:09','2026-03-17 05:55:44'),(48,1,7,1,'volunteers-of-america-mn-wi.svg','image/svg+xml','image',NULL,100,100,26940,NULL,NULL,NULL,'2026-03-17 05:55:06','2026-03-17 04:19:09','2026-03-17 05:55:43');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets_sites` VALUES (9,1,''),(10,1,''),(36,1,NULL),(37,1,NULL),(38,1,NULL),(39,1,NULL),(40,1,NULL),(41,1,NULL),(42,1,NULL),(43,1,NULL),(44,1,NULL),(45,1,NULL),(46,1,NULL),(47,1,NULL),(48,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `auth_oauth_tokens`
--

LOCK TABLES `auth_oauth_tokens` WRITE;
/*!40000 ALTER TABLE `auth_oauth_tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `auth_oauth_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `bulkopevents`
--

LOCK TABLES `bulkopevents` WRITE;
/*!40000 ALTER TABLE `bulkopevents` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `bulkopevents` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (1,1,'firstName','2026-03-14 15:47:33',0,1),(1,1,'fullName','2026-03-14 15:47:33',0,1),(1,1,'lastName','2026-03-14 15:47:33',0,1),(1,1,'lastPasswordChangeDate','2026-04-06 17:15:21',0,1),(1,1,'password','2026-04-06 17:15:21',0,1),(1,1,'username','2026-03-14 15:47:33',0,1),(1,1,'verificationCode','2026-04-06 17:15:21',0,1),(1,1,'verificationCodeIssuedDate','2026-04-06 17:15:21',0,1),(2,1,'email','2026-03-14 15:48:28',0,1),(2,1,'firstName','2026-03-14 15:48:28',0,1),(2,1,'fullName','2026-03-14 15:48:28',0,1),(2,1,'lastName','2026-03-14 15:48:28',0,1),(2,1,'username','2026-03-14 15:48:28',0,1),(3,1,'title','2026-04-08 15:17:49',0,1),(4,1,'enabled','2026-03-17 14:06:41',0,1),(4,1,'slug','2026-03-15 19:07:24',0,1),(5,1,'expiryDate','2026-03-15 18:54:27',0,1),(5,1,'fieldId','2026-03-15 18:54:27',0,1),(5,1,'id','2026-03-15 18:54:27',0,1),(5,1,'postDate','2026-03-15 18:54:27',0,1),(5,1,'primaryOwnerId','2026-03-15 18:54:27',0,1),(5,1,'sectionId','2026-03-15 18:54:27',0,1),(5,1,'status','2026-03-15 18:54:27',0,1),(5,1,'title','2026-03-15 18:54:27',0,1),(5,1,'typeId','2026-03-15 18:54:27',0,1),(11,1,'slug','2026-03-15 19:07:24',0,1),(65,1,'enabled','2026-03-17 06:02:19',0,1),(66,1,'enabled','2026-03-17 06:03:00',0,1),(67,1,'enabled','2026-03-17 06:03:04',0,1),(68,1,'enabled','2026-03-17 06:03:09',0,1),(69,1,'enabled','2026-03-17 06:03:51',0,1),(71,1,'enabled','2026-03-17 14:06:40',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (4,1,1,'337e5aec-0c5a-433d-bd78-cf5ce79dfdef','2026-03-15 19:10:13',0,1),(4,1,1,'3c17e516-45ef-413c-b36c-6c0e63dbe8f1','2026-03-15 19:10:13',0,1),(4,1,1,'b7bb25ce-84b3-420f-8390-0f4faa141f63','2026-03-17 06:01:13',0,1),(4,1,2,'e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9','2026-03-15 19:10:32',0,1),(4,1,3,'d99165ad-d54c-4bd5-9628-a6b356f4cf1f','2026-03-15 19:08:24',0,1),(4,1,4,'54105f47-70cb-4862-a58b-713095eac6cc','2026-03-17 04:07:23',0,1),(14,1,3,'d99165ad-d54c-4bd5-9628-a6b356f4cf1f','2026-03-15 19:08:24',0,1),(18,1,1,'337e5aec-0c5a-433d-bd78-cf5ce79dfdef','2026-03-15 19:10:13',0,1),(18,1,1,'3c17e516-45ef-413c-b36c-6c0e63dbe8f1','2026-03-15 19:10:13',0,1),(21,1,2,'e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9','2026-03-15 19:10:32',0,1),(33,1,4,'54105f47-70cb-4862-a58b-713095eac6cc','2026-03-17 04:07:23',0,1),(35,1,1,'b7bb25ce-84b3-420f-8390-0f4faa141f63','2026-03-17 04:11:46',0,1),(64,1,1,'b7bb25ce-84b3-420f-8390-0f4faa141f63','2026-03-17 06:01:13',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `contentblocks`
--

LOCK TABLES `contentblocks` WRITE;
/*!40000 ALTER TABLE `contentblocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `contentblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (1,1,1,NULL,'save','2026-03-14 15:47:33'),(1,1,1,NULL,'view','2026-04-09 14:36:48'),(2,1,1,NULL,'save','2026-03-14 15:48:28'),(2,1,1,NULL,'view','2026-03-15 19:07:14'),(4,1,1,NULL,'edit','2026-03-17 14:06:38'),(4,1,1,NULL,'save','2026-03-17 14:06:41'),(4,1,1,NULL,'view','2026-04-08 02:31:12'),(8,1,1,NULL,'save','2026-03-15 19:03:42'),(8,1,1,NULL,'view','2026-03-15 19:03:42'),(9,1,1,NULL,'save','2026-03-17 03:59:02'),(9,1,1,NULL,'view','2026-03-17 03:59:02'),(10,1,1,NULL,'save','2026-03-17 03:58:41'),(10,1,1,NULL,'view','2026-03-17 03:58:41');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2026-03-14 15:44:21','2026-04-06 17:15:20',NULL,NULL,NULL,'4d1516fd-e687-4ee6-8e49-a7471163f3a8'),(2,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2026-03-14 15:47:59','2026-03-14 15:48:28',NULL,NULL,NULL,'bd9c2698-31f4-4cac-93a1-cc4f3d724e79'),(3,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Form',1,0,'2026-03-15 18:41:49','2026-04-08 15:17:49',NULL,NULL,NULL,'fc511b46-58af-4a80-848e-1e0c91bb3327'),(4,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2026-03-15 18:54:27','2026-03-17 14:06:40',NULL,NULL,NULL,'33038f0e-5cea-4bbe-9966-1f1b419bc723'),(5,4,NULL,1,1,'craft\\elements\\Entry',1,0,'2026-03-15 18:54:27','2026-03-15 18:54:27',NULL,NULL,NULL,'d4ac180a-dcdd-4a29-b08a-00961d0ef2dd'),(6,4,NULL,2,1,'craft\\elements\\Entry',1,0,'2026-03-15 18:54:53','2026-03-15 18:54:53',NULL,NULL,NULL,'4944604a-8e1f-4ae0-805c-dfbfa96c60ab'),(7,4,NULL,3,1,'craft\\elements\\Entry',1,0,'2026-03-15 18:55:14','2026-03-15 18:55:14',NULL,NULL,NULL,'7f303208-65dc-4e3a-aa7d-379ae1ede46f'),(8,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-15 19:03:15','2026-03-15 19:04:48',NULL,'2026-03-15 19:04:48',NULL,'093a42a8-ebc3-41ee-86a4-b127d170f0f7'),(9,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-15 19:05:52','2026-03-17 05:55:42',NULL,NULL,NULL,'e034006e-9a3b-4f2b-ad53-0b574ec3adc6'),(10,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-15 19:06:49','2026-03-17 05:55:41',NULL,NULL,NULL,'062959d9-c971-4755-8ee7-bfb00f25d2c2'),(11,4,NULL,4,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:07:24','2026-03-15 19:07:24',NULL,NULL,NULL,'e0e96d1c-bbac-46f7-801e-0440d7331bc1'),(12,4,NULL,5,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:08:11','2026-03-15 19:08:11',NULL,NULL,NULL,'5b224d05-71a9-486a-b8e7-54c6c6272c98'),(14,4,NULL,6,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:08:24','2026-03-15 19:08:24',NULL,NULL,NULL,'1fc704b0-0e28-43e8-8d9e-2efe9ccc66c4'),(15,4,NULL,7,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:09:09','2026-03-15 19:09:09',NULL,NULL,NULL,'f6a2ca65-6b09-40f7-8bc7-48effd472f31'),(16,4,NULL,8,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:09:37','2026-03-15 19:09:37',NULL,NULL,NULL,'ed13615c-2901-4fce-a2a1-cc412b0d1069'),(18,4,NULL,9,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:10:13','2026-03-15 19:10:13',NULL,NULL,NULL,'930dceda-7530-4e77-ae3f-e5c3f9349b6b'),(19,4,NULL,10,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:10:25','2026-03-15 19:10:25',NULL,NULL,NULL,'a14c82aa-4c37-4f51-844a-f71fa315f6f2'),(21,4,NULL,11,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:10:32','2026-03-15 19:10:32',NULL,NULL,NULL,'46420078-2568-428d-88f5-4ce90cf8fa9d'),(22,4,NULL,12,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:11:37','2026-03-15 19:11:37',NULL,NULL,NULL,'1ab777c4-fd34-4d61-be30-5518693347b1'),(23,4,NULL,13,1,'craft\\elements\\Entry',1,0,'2026-03-15 19:12:41','2026-03-15 19:12:41',NULL,NULL,NULL,'57706d0f-a28c-49ae-a57e-a8c045a31953'),(24,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-15 20:08:55','2026-03-17 04:29:07',NULL,'2026-03-17 04:29:07',NULL,'1309e874-b75d-4e34-836c-ec6f6763e454'),(25,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-15 20:09:07','2026-03-15 20:09:07',NULL,NULL,NULL,'059fd8c3-f5b4-481b-b55d-77bf5326c6d3'),(26,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-15 20:09:07','2026-03-15 20:09:07',NULL,NULL,NULL,'f6aa585e-4125-4683-a084-4684ff653be9'),(27,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-15 20:09:42','2026-03-15 20:09:42',NULL,NULL,NULL,'ea9f1124-ba01-48a4-9ce3-74924e258399'),(28,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-15 20:09:47','2026-03-15 20:09:47',NULL,NULL,NULL,'eaf9e786-fbee-431f-aef4-4178bfdf9ac4'),(29,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-15 20:18:40','2026-03-17 04:29:07',NULL,'2026-03-17 04:29:07',NULL,'9eea1ae3-2943-4118-889c-f5058b182ce5'),(30,4,NULL,14,1,'craft\\elements\\Entry',1,0,'2026-03-17 03:59:14','2026-03-17 03:59:14',NULL,NULL,NULL,'a51a88cb-636d-4fbd-8038-597930634fc6'),(31,4,NULL,15,1,'craft\\elements\\Entry',1,0,'2026-03-17 04:06:52','2026-03-17 04:06:52',NULL,NULL,NULL,'cd2d4f77-935f-4387-b264-e00935b3166c'),(33,4,NULL,16,1,'craft\\elements\\Entry',1,0,'2026-03-17 04:07:23','2026-03-17 04:07:23',NULL,NULL,NULL,'5894ddd8-194e-4e9e-9f76-d96ddc635fca'),(35,4,NULL,17,1,'craft\\elements\\Entry',1,0,'2026-03-17 04:11:46','2026-03-17 04:11:46',NULL,NULL,NULL,'28af983b-794c-4b3c-bf6b-fff75777118d'),(36,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:17:56','2026-03-17 05:55:41',NULL,NULL,NULL,'8ecebc57-4c3b-4b29-bff2-31c1754c7fb0'),(37,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:17:56','2026-03-17 05:55:40',NULL,NULL,NULL,'472b3c37-81f7-4acc-a6e3-d647105a912b'),(38,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:06','2026-03-17 05:55:46',NULL,NULL,NULL,'4042990f-bb9a-487f-b3bb-ad629885c780'),(39,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:06','2026-03-17 05:55:45',NULL,NULL,NULL,'de5d4d6d-c078-4432-8d9a-f969b725acaa'),(40,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:06','2026-03-17 05:55:43',NULL,NULL,NULL,'8285cd77-7a4c-4abc-81eb-68b68a9af768'),(41,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:07','2026-03-17 05:55:43',NULL,NULL,NULL,'87302d6f-eef9-4a5e-9c02-4e138652acfe'),(42,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:08','2026-03-17 05:55:46',NULL,NULL,NULL,'bca2bc45-554e-43bc-a36b-d479eff8d342'),(43,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:08','2026-03-17 05:55:44',NULL,NULL,NULL,'52c8751b-c689-404d-919d-cf073885ea17'),(44,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:08','2026-03-17 05:55:44',NULL,NULL,NULL,'995aa0ae-a1ae-49b4-a09c-9098d25777ff'),(45,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:09','2026-03-17 05:55:45',NULL,NULL,NULL,'86f3e87e-92f3-4212-a342-132ff0afb502'),(46,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:09','2026-03-17 05:55:44',NULL,NULL,NULL,'2686a0ba-94d1-4b3a-9a79-b2bcb22c9015'),(47,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:09','2026-03-17 05:55:44',NULL,NULL,NULL,'3ef364b8-85d6-478a-869e-c946d220acb6'),(48,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2026-03-17 04:19:09','2026-03-17 05:55:43',NULL,NULL,NULL,'20b40329-832a-4cf9-8b1e-8e550340bdbd'),(49,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-17 04:28:44','2026-03-17 04:29:07',NULL,'2026-03-17 04:29:07',NULL,'23d9b565-b780-4e6c-8848-cb0e407612bf'),(50,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-17 04:28:54','2026-03-17 04:29:07',NULL,'2026-03-17 04:29:07',NULL,'dda79086-98bd-40fd-a0a7-2cd08dd919bc'),(51,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-17 04:32:41','2026-03-17 04:37:12',NULL,'2026-03-17 04:37:12',NULL,'9dec3bcf-b2bf-4d71-87cf-53206b9af4bb'),(52,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-17 04:33:25','2026-03-17 04:37:12',NULL,'2026-03-17 04:37:12',NULL,'7861df58-03d4-4693-8b55-47ddc8b4d9fc'),(53,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-17 04:33:41','2026-03-17 04:37:12',NULL,'2026-03-17 04:37:12',NULL,'32f783e7-8d27-4f39-8fcc-7ec34a0bfa1c'),(54,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-17 04:36:56','2026-03-17 04:37:12',NULL,'2026-03-17 04:37:12',NULL,'237c26ab-efc7-478f-8e67-05b7fc327613'),(55,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-17 04:38:24','2026-04-08 15:15:55',NULL,'2026-04-08 15:15:55',NULL,'ff9277b5-d9d5-4288-ad5a-bd0ed47b3d88'),(56,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-17 05:57:18','2026-04-08 15:15:55',NULL,'2026-04-08 15:15:55',NULL,'acb01f89-4cfc-42d0-a734-8eb17a13d3d3'),(57,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-17 05:57:35','2026-03-17 05:57:35',NULL,NULL,NULL,'1e350d61-c398-47a2-861f-68bbc46b65ca'),(58,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-17 05:57:36','2026-03-17 05:57:36',NULL,NULL,NULL,'d6672a29-ac5e-4fa7-8cf2-046fe8effdcd'),(59,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-17 05:59:02','2026-03-17 05:59:02',NULL,NULL,NULL,'28ec7be1-6a29-4c17-a825-252c726893c1'),(60,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-17 05:59:02','2026-03-17 05:59:02',NULL,NULL,NULL,'9afa37c9-a65b-4bf2-9446-3aa8b7618371'),(61,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-17 05:59:02','2026-03-17 05:59:02',NULL,NULL,NULL,'2e12c111-b25f-4225-92aa-6a96b443ee20'),(62,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-17 05:59:42','2026-03-17 05:59:42',NULL,NULL,NULL,'2d4e7f26-8acc-4bfa-9258-b5ead660bd4f'),(64,4,NULL,18,1,'craft\\elements\\Entry',1,0,'2026-03-17 06:01:13','2026-03-17 06:01:13',NULL,NULL,NULL,'f5c57ff5-39a8-4262-9806-db1c7a748003'),(65,4,NULL,19,1,'craft\\elements\\Entry',0,0,'2026-03-17 06:02:19','2026-03-17 06:02:19',NULL,NULL,NULL,'314a1a7f-4611-4116-8830-b69824d1fbe9'),(66,4,NULL,20,1,'craft\\elements\\Entry',1,0,'2026-03-17 06:03:00','2026-03-17 06:03:00',NULL,NULL,NULL,'62172dc7-0ccd-4f64-9274-8e7ce7a82c1f'),(67,4,NULL,21,1,'craft\\elements\\Entry',0,0,'2026-03-17 06:03:04','2026-03-17 06:03:04',NULL,NULL,NULL,'c274473b-8b5a-4ed3-a159-874289c35372'),(68,4,NULL,22,1,'craft\\elements\\Entry',1,0,'2026-03-17 06:03:09','2026-03-17 06:03:09',NULL,NULL,NULL,'0169c1ff-4095-40e1-9465-ce5387122395'),(69,4,NULL,23,1,'craft\\elements\\Entry',0,0,'2026-03-17 06:03:51','2026-03-17 06:03:51',NULL,NULL,NULL,'65405209-1bfb-42ce-88da-8dc725483652'),(71,4,NULL,24,1,'craft\\elements\\Entry',1,0,'2026-03-17 14:06:40','2026-03-17 14:06:40',NULL,NULL,NULL,'b453e2c5-3c00-44fe-ac3a-d45399e6bddf'),(72,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-03-17 14:07:25','2026-04-08 15:15:55',NULL,'2026-04-08 15:15:55',NULL,'644b5787-fe45-448b-a343-f792a9beb558'),(73,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-17 14:08:12','2026-03-17 14:08:12',NULL,NULL,NULL,'be141e0b-9f4d-432d-88bf-1ac3ba2d36b6'),(74,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-03-17 14:08:12','2026-03-17 14:08:12',NULL,NULL,NULL,'8fb1c1ae-66b8-45c1-8ffb-a2746473735d'),(75,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-06 17:10:32','2026-04-08 15:15:55',NULL,'2026-04-08 15:15:55',NULL,'44db26c6-059e-4563-aa81-a22e0371c10f'),(76,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-04-06 17:14:37','2026-04-06 17:14:37',NULL,NULL,NULL,'083cc03d-21e2-4ac6-a114-f56a6045dff0'),(77,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-04-06 17:14:37','2026-04-06 17:14:37',NULL,NULL,NULL,'6fa8a2bc-ca63-45f4-87d8-6aefa06b8da5'),(78,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 02:31:04','2026-04-08 15:15:55',NULL,'2026-04-08 15:15:55',NULL,'849f76c9-e8bf-4e29-a730-5b2621d633d0'),(79,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-04-08 02:31:17','2026-04-08 02:31:17',NULL,NULL,NULL,'ef8db815-854e-4f5c-948e-31c9e751138b'),(80,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\SentNotification',1,0,'2026-04-08 02:31:18','2026-04-08 02:31:18',NULL,NULL,NULL,'adf05a35-17bf-4b3b-95fe-13a236c4bc6e'),(81,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 14:59:25','2026-04-08 14:59:25',NULL,NULL,NULL,'9d9310b9-e6e0-4a3f-9d55-c05736124d86'),(82,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 14:59:31','2026-04-08 14:59:31',NULL,NULL,NULL,'4a976e98-aa39-4cba-99a8-8b41863ffd56'),(83,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 14:59:57','2026-04-08 14:59:57',NULL,NULL,NULL,'92f1a470-3ccb-4c9e-9276-a64af196c4d3'),(84,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 15:00:08','2026-04-08 15:00:08',NULL,NULL,NULL,'9a2532d3-44f5-40c4-a348-b8252964c45c'),(85,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 15:00:14','2026-04-08 15:00:14',NULL,NULL,NULL,'2fb1c77c-e474-4565-8492-2c7a1e34bb33'),(86,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 15:00:19','2026-04-08 15:00:19',NULL,NULL,NULL,'1576b0f2-4cfa-45ba-acc2-ba8ab983afe7'),(87,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 15:01:52','2026-04-08 15:01:52',NULL,NULL,NULL,'4b47f078-9133-403f-9a1f-98b642b61359'),(88,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 15:02:32','2026-04-08 15:02:32',NULL,NULL,NULL,'6100fafa-4537-488d-9c3d-637a5e9e20af'),(89,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 15:17:25','2026-04-08 15:17:25',NULL,NULL,NULL,'a5f9a95b-4008-41a0-9a25-c270ecaabae0'),(90,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-08 22:16:02','2026-04-08 22:16:02',NULL,NULL,NULL,'f05900e1-f1b4-4f0c-b756-79244ff51ed2'),(91,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-09 01:15:25','2026-04-09 01:15:25',NULL,NULL,NULL,'8168c0c3-700b-4064-82c5-f27aedab546c'),(92,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-09 12:51:07','2026-04-09 12:51:07',NULL,NULL,NULL,'9296f8f9-e6ff-4801-b8e9-0679d0443372'),(93,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-09 15:10:26','2026-04-24 16:11:52',NULL,NULL,NULL,'ec7480bb-4aa2-4a55-9158-2888fba4013d'),(94,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-10 02:44:52','2026-04-10 02:44:52',NULL,NULL,NULL,'0aee630e-abb4-4240-92a9-78e0ed757173'),(95,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-10 16:07:49','2026-04-10 16:07:49',NULL,NULL,NULL,'1425dea5-e34c-498c-8324-83685be27e97'),(96,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Submission',1,0,'2026-04-13 14:33:59','2026-04-13 14:33:59',NULL,NULL,NULL,'a810adc3-443a-4613-b268-b8b003117f2e');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2026-03-14 15:44:21','2026-03-14 15:44:21','6a41af5f-b136-4158-9716-30010755ab8a'),(2,2,1,NULL,NULL,NULL,NULL,1,'2026-03-14 15:47:59','2026-03-14 15:47:59','68b8a05f-385f-4a33-9690-50302ead6f9e'),(3,3,1,'Launch Sign-up',NULL,NULL,NULL,1,'2026-03-15 18:41:49','2026-03-15 18:41:49','43bdc964-441c-4868-b4cb-06ed74c3f0b2'),(4,4,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"b7bb25ce-84b3-420f-8390-0f4faa141f63\": \"✨ Get notified…\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-15 18:54:27','2026-03-17 06:01:13','43f05d96-0a78-49e8-8a54-8f31e7293338'),(5,5,1,'Splash Page','splash-page','__home__',NULL,1,'2026-03-15 18:54:27','2026-03-15 18:54:27','af046898-d0d6-4f5a-9992-c82c7c0ae021'),(6,6,1,'Splash Page','splash-page','__home__',NULL,1,'2026-03-15 18:54:53','2026-03-15 18:54:53','1b470888-5e2a-4182-9086-ac28215a5718'),(7,7,1,'Splash Page','splash-page','__home__',NULL,1,'2026-03-15 18:55:14','2026-03-15 18:55:14','4d3a3613-31c9-4133-8ae5-3a9b5934f61a'),(8,8,1,'Abstract 01',NULL,NULL,NULL,1,'2026-03-15 19:03:15','2026-03-15 19:03:42','7b08e934-0a1d-4696-9f67-fffcacc3bf55'),(9,9,1,'Denys nevozhai z0n Vqfr Oq WA unsplash',NULL,NULL,NULL,1,'2026-03-15 19:05:52','2026-03-15 19:05:52','d016ed77-31b2-4692-96c0-6257d4b889f5'),(10,10,1,'Pexels steve 1690351',NULL,NULL,NULL,1,'2026-03-15 19:06:49','2026-03-15 19:06:49','b4184b6c-43b4-486f-a41e-aab444496703'),(11,11,1,'Splash Page','__home__','__home__',NULL,1,'2026-03-15 19:07:24','2026-03-15 19:07:24','ec4c9e02-a4b2-4825-a00a-89f8aeb65d2a'),(12,12,1,'Splash Page','__home__','__home__',NULL,1,'2026-03-15 19:08:11','2026-03-15 19:08:11','40896c69-abb6-45c6-b31b-a6b7769fa4e9'),(14,14,1,'Splash Page','__home__','__home__','{\"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9]}',1,'2026-03-15 19:08:24','2026-03-15 19:08:24','2564b263-cf06-493c-ba02-9f3c1acf2863'),(15,15,1,'Splash Page','__home__','__home__','{\"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9]}',1,'2026-03-15 19:09:09','2026-03-15 19:09:09','4e28e162-e373-4af3-aeb2-45cc79c921ec'),(16,16,1,'Splash Page','__home__','__home__','{\"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9]}',1,'2026-03-15 19:09:37','2026-03-15 19:09:37','8237a0c1-fe18-4127-a01a-179a1603e280'),(18,18,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9]}',1,'2026-03-15 19:10:13','2026-03-15 19:10:13','d53a47c7-50fa-47ef-8911-a6408a2c8bcb'),(19,19,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9]}',1,'2026-03-15 19:10:25','2026-03-15 19:10:25','45d2f67c-4869-4f98-9c48-184d39f96c56'),(21,21,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-15 19:10:32','2026-03-15 19:10:32','68661722-6c54-4a0f-a65e-d40ee4788559'),(22,22,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-15 19:11:37','2026-03-15 19:11:37','703caf18-2d33-470c-812c-b401798ea0b9'),(23,23,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-15 19:12:41','2026-03-15 19:12:41','61d3eac8-10b0-4b09-b400-33b9c5d8e38d'),(24,24,1,'2026-03-15 13:08:55',NULL,NULL,NULL,1,'2026-03-15 20:08:55','2026-03-15 20:08:55','030d3029-de79-4aff-b70c-a53ba6e0bd5b'),(25,25,1,NULL,NULL,NULL,NULL,1,'2026-03-15 20:09:07','2026-03-15 20:09:07','d28051b3-1e95-4961-bbb5-2da9109c2da7'),(26,26,1,NULL,NULL,NULL,NULL,1,'2026-03-15 20:09:07','2026-03-15 20:09:07','48fe8fd3-80c6-4cca-b876-7407deddb49b'),(27,27,1,NULL,NULL,NULL,NULL,1,'2026-03-15 20:09:42','2026-03-15 20:09:42','51a1df14-e8e7-4b71-9e34-f7cb149a6c6f'),(28,28,1,NULL,NULL,NULL,NULL,1,'2026-03-15 20:09:47','2026-03-15 20:09:47','c0d819a7-0284-4f56-9c57-a9a200009b21'),(29,29,1,'2026-03-15 13:18:40',NULL,NULL,NULL,1,'2026-03-15 20:18:40','2026-03-15 20:18:40','26935170-1a9d-4ce6-9405-5b295ea1513d'),(30,30,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 03:59:14','2026-03-17 03:59:14','fc5d7dc5-82d4-4b00-9a11-bec5ea1549d8'),(31,31,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 04:06:52','2026-03-17 04:06:52','81bb4fe1-acd6-4803-b526-186c1fec4e87'),(33,33,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 04:07:23','2026-03-17 04:07:23','bba37876-a4a7-4744-8314-bb01587fd639'),(35,35,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"b7bb25ce-84b3-420f-8390-0f4faa141f63\": \"✨ Get notified when we launch…\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 04:11:47','2026-03-17 04:11:47','18c346a0-5298-4c14-9867-e3d894a1ebda'),(36,36,1,'Dbtsearch icon',NULL,NULL,NULL,1,'2026-03-17 04:17:56','2026-03-17 04:17:56','92f1d165-b78e-4ec4-9777-fe5d98d48443'),(37,37,1,'Dbtsearch logo',NULL,NULL,NULL,1,'2026-03-17 04:17:56','2026-03-17 04:17:56','d338744d-8e97-490f-9daa-27485263bbfe'),(38,38,1,'Acp associated clinic',NULL,NULL,NULL,1,'2026-03-17 04:19:06','2026-03-17 04:19:06','def785c2-1165-4fd6-bab9-3e6fc4dbabd1'),(39,39,1,'Advanded behavioral health inc',NULL,NULL,NULL,1,'2026-03-17 04:19:06','2026-03-17 04:19:06','1a12c739-8f8a-4049-872b-25541e354cf2'),(40,40,1,'Align your soul',NULL,NULL,NULL,1,'2026-03-17 04:19:06','2026-03-17 04:19:06','a61088eb-2709-4143-8415-e05dc5e2754f'),(41,41,1,'Art of validation and change',NULL,NULL,NULL,1,'2026-03-17 04:19:07','2026-03-17 04:19:07','e1ed3403-0a1c-4292-a5e6-89168553654b'),(42,42,1,'Asc psychological services',NULL,NULL,NULL,1,'2026-03-17 04:19:08','2026-03-17 04:19:08','378221ca-7235-48a4-8531-01565019a7fd'),(43,43,1,'Autonomy couseling',NULL,NULL,NULL,1,'2026-03-17 04:19:08','2026-03-17 04:19:08','38894c99-781b-4ee9-82e3-c5504aa530ad'),(44,44,1,'Choices psychotherapy',NULL,NULL,NULL,1,'2026-03-17 04:19:08','2026-03-17 04:19:08','71a32956-dded-40a1-b4fc-1aaabbebbe25'),(45,45,1,'Dbt associates llp',NULL,NULL,NULL,1,'2026-03-17 04:19:09','2026-03-17 04:19:09','162cc563-1b4f-432f-b0a5-315241973a9b'),(46,46,1,'Meridian behavioral health',NULL,NULL,NULL,1,'2026-03-17 04:19:09','2026-03-17 04:19:09','75756520-9376-42f6-893d-bf6d678846c2'),(47,47,1,'Tiny tree counseling',NULL,NULL,NULL,1,'2026-03-17 04:19:09','2026-03-17 04:19:09','149bc601-00de-4a23-87d5-a2c075eda4c2'),(48,48,1,'Volunteers of america mn wi',NULL,NULL,NULL,1,'2026-03-17 04:19:09','2026-03-17 04:19:09','3ef013d4-5fe7-453a-ac32-542ae181a5da'),(49,49,1,'2026-03-16 21:28:44',NULL,NULL,NULL,1,'2026-03-17 04:28:44','2026-03-17 04:28:44','bdb80b20-cc92-4f68-975a-c9c6baa42239'),(50,50,1,'2026-03-16 21:28:54',NULL,NULL,NULL,1,'2026-03-17 04:28:54','2026-03-17 04:28:54','a0cd0d38-ba6f-4da2-a25d-9cd022e76d0a'),(51,51,1,'Brian Larson',NULL,NULL,NULL,1,'2026-03-17 04:32:41','2026-03-17 04:32:41','2a4c9d67-3781-4bea-a351-8f14c65f9321'),(52,52,1,'Brian Larson',NULL,NULL,NULL,1,'2026-03-17 04:33:25','2026-03-17 04:33:26','30d89efe-0b1e-4de8-9fac-4addc0800f74'),(53,53,1,'Brian Larson',NULL,NULL,NULL,1,'2026-03-17 04:33:41','2026-03-17 04:33:41','5efb1301-b657-45c9-88f8-25430cc4a687'),(54,54,1,'Brian Larson',NULL,NULL,NULL,1,'2026-03-17 04:36:56','2026-03-17 04:36:57','2b623022-d1e8-43d0-aed5-48208d8371f6'),(55,55,1,'Brian Larson',NULL,NULL,NULL,1,'2026-03-17 04:38:24','2026-03-17 04:38:24','a7874535-5bce-4521-bf1e-13f453023cfd'),(56,56,1,'Brian Larson',NULL,NULL,NULL,1,'2026-03-17 05:57:18','2026-03-17 05:57:18','aa23cd8f-a6db-451c-9536-04990c9cd404'),(57,57,1,NULL,NULL,NULL,NULL,1,'2026-03-17 05:57:35','2026-03-17 05:57:35','8c68db09-af26-48dd-b51d-f18e1aeb5e15'),(58,58,1,NULL,NULL,NULL,NULL,1,'2026-03-17 05:57:36','2026-03-17 05:57:36','b5dbb742-814d-4e7f-8468-c63c0a0a4b7c'),(59,59,1,NULL,NULL,NULL,NULL,1,'2026-03-17 05:59:02','2026-03-17 05:59:02','e6fd9058-96c4-4967-be16-94d475baf3c4'),(60,60,1,NULL,NULL,NULL,NULL,1,'2026-03-17 05:59:02','2026-03-17 05:59:02','09ecd75c-1295-40cb-bfca-d7872e66c74b'),(61,61,1,NULL,NULL,NULL,NULL,1,'2026-03-17 05:59:02','2026-03-17 05:59:02','e85cafeb-138a-4b49-90de-cacca5f8b97b'),(62,62,1,NULL,NULL,NULL,NULL,1,'2026-03-17 05:59:42','2026-03-17 05:59:42','a9461c17-6722-4436-9069-470eb2cc3bd7'),(64,64,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"b7bb25ce-84b3-420f-8390-0f4faa141f63\": \"✨ Get notified…\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 06:01:13','2026-03-17 06:01:13','ce278818-cd12-4348-b8e7-435823ecd87f'),(65,65,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"b7bb25ce-84b3-420f-8390-0f4faa141f63\": \"✨ Get notified…\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 06:02:19','2026-03-17 06:02:19','c7529ecf-c437-47e3-8ad3-2fc6cef422d5'),(66,66,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"b7bb25ce-84b3-420f-8390-0f4faa141f63\": \"✨ Get notified…\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 06:03:00','2026-03-17 06:03:00','5859f692-4c24-46f3-9814-3d8b08c8f294'),(67,67,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"b7bb25ce-84b3-420f-8390-0f4faa141f63\": \"✨ Get notified…\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 06:03:04','2026-03-17 06:03:04','e6b766d1-1c14-4384-be6a-707a93a6de79'),(68,68,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"b7bb25ce-84b3-420f-8390-0f4faa141f63\": \"✨ Get notified…\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 06:03:09','2026-03-17 06:03:09','8004f701-53ff-404b-8011-58e0bba2affd'),(69,69,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"b7bb25ce-84b3-420f-8390-0f4faa141f63\": \"✨ Get notified…\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 06:03:51','2026-03-17 06:03:51','f05ce0bd-0471-46f7-a8e1-42def97008c7'),(71,71,1,'Splash Page','__home__','__home__','{\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\": \"Coming Soon!\", \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\": \"Find Available DBT Programs \\nin Minnesota\", \"54105f47-70cb-4862-a58b-713095eac6cc\": \"<p>Our single mission is to increase access for those in need of DBT. We\'re building a directory for anyone to find certified DBT providers in Minnesota and see who has current openings.</p>\", \"b7bb25ce-84b3-420f-8390-0f4faa141f63\": \"✨ Get notified…\", \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\": [10, 9], \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\": [3]}',1,'2026-03-17 14:06:40','2026-03-17 14:06:40','0f42b834-9b9c-497f-b41b-cce48e228640'),(72,72,1,'Mary Souder',NULL,NULL,NULL,1,'2026-03-17 14:07:25','2026-03-17 14:07:26','a99d00ec-ccc2-4503-881d-772383c7ec1a'),(73,73,1,NULL,NULL,NULL,NULL,1,'2026-03-17 14:08:12','2026-03-17 14:08:12','526d0ce5-ffc3-4198-99ee-34153fc793d3'),(74,74,1,NULL,NULL,NULL,NULL,1,'2026-03-17 14:08:12','2026-03-17 14:08:12','7ec1f46c-9ac2-4eb8-9da9-aebf93302703'),(75,75,1,'Brian Larson',NULL,NULL,NULL,1,'2026-04-06 17:10:32','2026-04-06 17:10:33','08b3d947-2857-4709-a7b9-a094b91c5707'),(76,76,1,NULL,NULL,NULL,NULL,1,'2026-04-06 17:14:37','2026-04-06 17:14:37','166f82d7-716e-41e8-b4ed-761fd18bc6e3'),(77,77,1,NULL,NULL,NULL,NULL,1,'2026-04-06 17:14:37','2026-04-06 17:14:37','b8d7936a-1d75-4a8b-af61-2d80846cd9b7'),(78,78,1,'Mary Souder',NULL,NULL,NULL,1,'2026-04-08 02:31:04','2026-04-08 02:31:05','adbe8324-3076-447a-b281-3132de946723'),(79,79,1,NULL,NULL,NULL,NULL,1,'2026-04-08 02:31:17','2026-04-08 02:31:17','e7f1118a-ed83-443f-bdf2-4055a3a298e6'),(80,80,1,NULL,NULL,NULL,NULL,1,'2026-04-08 02:31:18','2026-04-08 02:31:18','ee3b3737-7e09-40aa-be31-86ee16eddf17'),(81,81,1,'Madeline Asp',NULL,NULL,NULL,1,'2026-04-08 14:59:25','2026-04-08 14:59:25','a4a69959-bc6c-46ef-be6f-711c46f84b53'),(82,82,1,'Caila Kritzeck',NULL,NULL,NULL,1,'2026-04-08 14:59:31','2026-04-08 14:59:31','ee911d0a-37ee-483f-9a89-69ce34d97583'),(83,83,1,'Jo Ripplinger',NULL,NULL,NULL,1,'2026-04-08 14:59:57','2026-04-08 14:59:58','d7082ff9-02be-492e-891d-57886d1ab810'),(84,84,1,'Josh Powell',NULL,NULL,NULL,1,'2026-04-08 15:00:08','2026-04-08 15:00:08','e5a859ec-beed-4d7b-a93e-bcc5c3b46caa'),(85,85,1,'Elizabeth Carlton',NULL,NULL,NULL,1,'2026-04-08 15:00:14','2026-04-08 15:00:15','d3e10b93-5f3e-4979-914d-670a1e4417d9'),(86,86,1,'Marsha Werner',NULL,NULL,NULL,1,'2026-04-08 15:00:19','2026-04-08 15:00:20','7fa178ca-07cb-420b-9521-b8cd0e33dcb5'),(87,87,1,'Kate Perry',NULL,NULL,NULL,1,'2026-04-08 15:01:52','2026-04-08 15:01:52','e145179b-cfe1-41f8-ae21-8802a280e52e'),(88,88,1,'Haley Raifsnider',NULL,NULL,NULL,1,'2026-04-08 15:02:32','2026-04-08 15:02:32','69ec394f-bae1-4947-ba71-13b6838c6195'),(89,89,1,'Joyce Koerner',NULL,NULL,NULL,1,'2026-04-08 15:17:25','2026-04-08 15:17:25','6dfebceb-f63f-414f-a42f-1c26ec6c80fb'),(90,90,1,'Jennifer Goerger',NULL,NULL,NULL,1,'2026-04-08 22:16:02','2026-04-08 22:16:02','f1d7f0ec-f40f-4099-8a6a-77eb355359e9'),(91,91,1,'Colleen Starkey',NULL,NULL,NULL,1,'2026-04-09 01:15:25','2026-04-09 01:15:25','aa585343-fa21-4a94-a0e8-a225ba24d806'),(92,92,1,'Patty Lauer-Roberts',NULL,NULL,NULL,1,'2026-04-09 12:51:07','2026-04-09 12:51:08','3162956f-c450-4f02-aba7-6c3cc5873c91'),(93,93,1,'Kristin Bunge',NULL,NULL,NULL,1,'2026-04-09 15:10:26','2026-04-09 15:10:27','5d379f6c-8fa4-437a-acf3-07e07e64669b'),(94,94,1,'Aneata Test',NULL,NULL,NULL,1,'2026-04-10 02:44:52','2026-04-10 02:44:53','0ee87b0c-d75b-4c8c-9969-b563fdb5a4c6'),(95,95,1,'Stephanie Wanous',NULL,NULL,NULL,1,'2026-04-10 16:07:49','2026-04-10 16:07:49','775458d3-2d73-4daa-8158-322e0dceb7b6'),(96,96,1,'Beth Bordenave',NULL,NULL,NULL,1,'2026-04-13 14:33:59','2026-04-13 14:33:59','643247bc-31bc-4b92-8776-f3532092f5de');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (4,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 18:54:27','2026-03-15 18:54:27'),(5,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 18:54:27','2026-03-15 18:54:27'),(6,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 18:54:53','2026-03-15 18:54:53'),(7,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 18:55:14','2026-03-15 18:55:14'),(11,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:07:24','2026-03-15 19:07:24'),(12,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:08:11','2026-03-15 19:08:11'),(14,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:08:24','2026-03-15 19:08:24'),(15,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:09:09','2026-03-15 19:09:09'),(16,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:09:37','2026-03-15 19:09:37'),(18,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:10:13','2026-03-15 19:10:13'),(19,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:10:25','2026-03-15 19:10:25'),(21,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:10:32','2026-03-15 19:10:32'),(22,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:11:37','2026-03-15 19:11:37'),(23,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-15 19:12:41','2026-03-15 19:12:41'),(30,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 03:59:14','2026-03-17 03:59:14'),(31,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 04:06:52','2026-03-17 04:06:52'),(33,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 04:07:23','2026-03-17 04:07:23'),(35,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 04:11:47','2026-03-17 04:11:47'),(64,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 06:01:13','2026-03-17 06:01:13'),(65,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 06:02:19','2026-03-17 06:02:19'),(66,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 06:03:00','2026-03-17 06:03:00'),(67,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 06:03:04','2026-03-17 06:03:04'),(68,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 06:03:09','2026-03-17 06:03:09'),(69,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 06:03:51','2026-03-17 06:03:51'),(71,1,NULL,NULL,NULL,1,'2026-03-15 18:54:00',NULL,'live',NULL,NULL,'2026-03-17 14:06:40','2026-03-17 14:06:40');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,'Splash Page','splashPage',NULL,'hand-wave',NULL,'{title}',0,'site',NULL,'{title}',0,1,'site',NULL,1,'2026-03-15 18:54:25','2026-03-15 19:07:36',NULL,'bcf50025-2188-4126-a360-29999caeae89');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"3962ad29-c767-4408-904d-177a4036fce2\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Label\", \"width\": 100, \"handle\": \"label\", \"warning\": null, \"fieldUid\": \"ddb25fd5-a759-494a-9d4d-96a6e44c941e\", \"required\": false, \"dateAdded\": \"2026-03-15T19:09:36+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null}, {\"tip\": null, \"uid\": \"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Heading\", \"width\": 100, \"handle\": \"heading\", \"warning\": null, \"fieldUid\": \"ddb25fd5-a759-494a-9d4d-96a6e44c941e\", \"required\": false, \"dateAdded\": \"2026-03-15T18:54:25+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null}, {\"tip\": null, \"uid\": \"54105f47-70cb-4862-a58b-713095eac6cc\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Content\", \"width\": 100, \"handle\": \"content\", \"warning\": null, \"fieldUid\": \"68f6aaed-7edc-4e91-9996-3a86c16baf2f\", \"required\": false, \"dateAdded\": \"2026-03-17T04:06:50+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null}, {\"uid\": \"5f28f2bc-f3cb-4fa0-8af5-6a1a1fa88c0d\", \"type\": \"craft\\\\fieldlayoutelements\\\\HorizontalRule\", \"dateAdded\": \"2026-03-17T04:11:21+00:00\", \"userCondition\": null, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"b7bb25ce-84b3-420f-8390-0f4faa141f63\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Form Heading\", \"width\": 100, \"handle\": \"formHeading\", \"warning\": null, \"fieldUid\": \"ddb25fd5-a759-494a-9d4d-96a6e44c941e\", \"required\": false, \"dateAdded\": \"2026-03-17T04:10:34+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null}, {\"tip\": null, \"uid\": \"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"98fab9df-c419-4085-9a57-5c61f96573c2\", \"required\": false, \"dateAdded\": \"2026-03-15T18:54:25+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null}, {\"uid\": \"8241cdc9-92b5-4833-91f2-2de4c5ec8c94\", \"type\": \"craft\\\\fieldlayoutelements\\\\HorizontalRule\", \"dateAdded\": \"2026-03-17T04:11:21+00:00\", \"userCondition\": null, \"elementCondition\": null}, {\"tip\": \"Select one or multiple images to randomize on page load\", \"uid\": \"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Image(s)\", \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"fe417a71-4d1b-460f-8a63-7ac81c0e5092\", \"required\": false, \"dateAdded\": \"2026-03-15T18:54:25+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"elementCondition\": null, \"elementEditCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"thumbFieldKey\": null, \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2026-03-15 18:54:25','2026-03-17 04:11:21',NULL,'19b8c440-d617-47f4-b9b7-2dcaa4455df9'),(2,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"3c724645-9610-47df-9d65-56cb854bddb6\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"868219d9-9165-4ff0-8c75-f5aeb10958b6\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2026-03-15T18:57:47+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"uid\": \"eff7f937-547e-4260-b98f-876b9249331f\", \"type\": \"craft\\\\fieldlayoutelements\\\\HorizontalRule\", \"dateAdded\": \"2026-03-15T18:59:33+00:00\", \"userCondition\": null, \"elementCondition\": null}, {\"id\": null, \"tip\": null, \"uid\": \"f1acb816-b913-4e71-b62c-234bb5ff91a3\", \"cols\": null, \"name\": null, \"rows\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"alt\", \"dateAdded\": \"2026-03-15T18:59:33+00:00\", \"requirable\": true, \"orientation\": null, \"placeholder\": null, \"instructions\": null, \"userCondition\": null, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"thumbFieldKey\": null, \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2026-03-15 18:59:33','2026-03-15 18:59:33',NULL,'bec1e434-aec3-4db5-945f-598e2e1154c2');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,'Plain Text','plainText','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":1,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2026-03-15 18:52:28','2026-03-15 19:08:48',NULL,'ddb25fd5-a759-494a-9d4d-96a6e44c941e'),(2,'Form','form','global',NULL,NULL,0,'none',NULL,'verbb\\formie\\fields\\Forms','{\"allowSelfRelations\":false,\"branchLimit\":null,\"defaultPlacement\":\"end\",\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showSearchInput\":true,\"showSiteMenu\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2026-03-15 18:53:22','2026-03-15 18:53:22',NULL,'98fab9df-c419-4085-9a57-5c61f96573c2'),(3,'Images','images','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultPlacement\":\"end\",\"defaultUploadLocationSource\":\"volume:288c542e-3541-4e24-96ee-aa5fa0bea135\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:288c542e-3541-4e24-96ee-aa5fa0bea135\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showSearchInput\":true,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list-inline\"}','2026-03-15 18:53:45','2026-03-15 19:08:10',NULL,'fe417a71-4d1b-460f-8a63-7ac81c0e5092'),(4,'Basic Editor','basicEditor','global',NULL,NULL,0,'none',NULL,'craft\\ckeditor\\Field','{\"advancedLinkFields\":[\"urlSuffix\",\"target\",\"download\"],\"availableTransforms\":\"\",\"availableVolumes\":\"*\",\"characterLimit\":null,\"css\":null,\"defaultTransform\":null,\"defaultUploadLocationSubpath\":null,\"defaultUploadLocationVolume\":null,\"fullGraphqlData\":true,\"headingLevels\":false,\"imageEntryTypeUid\":null,\"imageFieldUid\":null,\"imageMode\":\"img\",\"js\":null,\"options\":null,\"parseEmbeds\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":false,\"sourceEditingGroups\":[\"__ADMINS__\"],\"toolbar\":[\"bold\",\"italic\",\"link\"],\"wordLimit\":null}','2026-03-17 04:06:07','2026-03-17 04:06:07',NULL,'68f6aaed-7edc-4e91-9996-3a86c16baf2f');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_emailtemplates`
--

LOCK TABLES `formie_emailtemplates` WRITE;
/*!40000 ALTER TABLE `formie_emailtemplates` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `formie_emailtemplates` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_fieldlayout_pages`
--

LOCK TABLES `formie_fieldlayout_pages` WRITE;
/*!40000 ALTER TABLE `formie_fieldlayout_pages` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_fieldlayout_pages` VALUES (1,1,'Page 1',0,'{\"submitButtonLabel\":\"Contact us\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-15 18:41:49','2026-03-15 18:41:49','0e80ca22-d11b-4e37-b3d2-9ddabda3568b');
/*!40000 ALTER TABLE `formie_fieldlayout_pages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_fieldlayout_rows`
--

LOCK TABLES `formie_fieldlayout_rows` WRITE;
/*!40000 ALTER TABLE `formie_fieldlayout_rows` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_fieldlayout_rows` VALUES (1,1,1,0,'2026-03-15 18:41:49','2026-03-15 18:41:49','99b5a238-d92b-4893-be4c-a58611909b91'),(3,1,1,1,'2026-03-15 18:41:49','2026-03-15 18:41:49','cfb481b0-afec-4ca6-992c-cae23f21e4bb'),(5,1,1,2,'2026-03-15 18:45:53','2026-03-15 18:45:53','fcca3cfe-9cce-48ec-a649-7c420915ff96');
/*!40000 ALTER TABLE `formie_fieldlayout_rows` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_fieldlayouts`
--

LOCK TABLES `formie_fieldlayouts` WRITE;
/*!40000 ALTER TABLE `formie_fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_fieldlayouts` VALUES (1,'2026-03-15 18:41:49','2026-03-15 18:41:49','bcffd7e5-5232-4449-8d18-88b6b3e1fb96');
/*!40000 ALTER TABLE `formie_fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_fields`
--

LOCK TABLES `formie_fields` WRITE;
/*!40000 ALTER TABLE `formie_fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_fields` VALUES (5,1,1,1,NULL,'Name','name','verbb\\formie\\fields\\Name',0,'{\"useMultipleFields\":false,\"instructions\":null,\"enabled\":true,\"required\":true,\"matchField\":null,\"placeholder\":null,\"defaultValue\":null,\"prePopulate\":null,\"errorMessage\":null,\"labelPosition\":null,\"instructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"cssClasses\":null,\"containerAttributes\":[],\"inputAttributes\":null,\"includeInEmail\":true,\"emailValue\":null,\"enableConditions\":false,\"conditions\":null,\"enableContentEncryption\":false,\"visibility\":null,\"nestedLayoutId\":null,\"contentTable\":null,\"subFieldLabelPosition\":null}','2026-03-15 18:41:49','2026-03-15 19:34:15','8f41dc43-dfa3-4b99-9762-4316a1fb7b9b'),(6,1,1,3,NULL,'Email Address','email','verbb\\formie\\fields\\Email',0,'{\"validateDomain\":false,\"blockedDomains\":[],\"blockFreeDomains\":false,\"uniqueValue\":false,\"instructions\":null,\"enabled\":true,\"required\":true,\"matchField\":null,\"placeholder\":null,\"defaultValue\":null,\"prePopulate\":null,\"errorMessage\":null,\"labelPosition\":null,\"instructionsPosition\":null,\"cssClasses\":null,\"containerAttributes\":[],\"inputAttributes\":[],\"includeInEmail\":true,\"emailValue\":null,\"enableConditions\":false,\"conditions\":null,\"enableContentEncryption\":false,\"visibility\":null}','2026-03-15 18:41:49','2026-03-15 19:34:54','2e8787bc-1e91-404d-962a-28497ad7bbd0'),(8,1,1,1,NULL,'Organization','organization','verbb\\formie\\fields\\SingleLineText',1,'{\"limit\":false,\"min\":null,\"minType\":\"characters\",\"max\":null,\"maxType\":\"characters\",\"uniqueValue\":false,\"instructions\":null,\"enabled\":true,\"required\":false,\"matchField\":null,\"placeholder\":null,\"defaultValue\":null,\"prePopulate\":null,\"errorMessage\":null,\"labelPosition\":null,\"instructionsPosition\":null,\"cssClasses\":null,\"containerAttributes\":[],\"inputAttributes\":[],\"includeInEmail\":true,\"emailValue\":null,\"enableConditions\":false,\"conditions\":null,\"enableContentEncryption\":false,\"visibility\":null}','2026-03-15 18:45:53','2026-03-15 18:45:53','407e1923-de50-4f0f-8dd5-6b626abc8d82'),(9,1,1,5,NULL,'Certified Provider','provider_listing','verbb\\formie\\fields\\Agree',0,'{\"description\":[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":\"start\"},\"content\":[{\"type\":\"text\",\"text\":\"I\'m a certified DBT provider or program representative\"}]}],\"checkedValue\":\"Yes\",\"uncheckedValue\":\"No\",\"instructions\":null,\"enabled\":true,\"required\":false,\"matchField\":null,\"placeholder\":null,\"defaultValue\":false,\"prePopulate\":null,\"errorMessage\":null,\"labelPosition\":\"verbb\\\\formie\\\\positions\\\\Hidden\",\"instructionsPosition\":null,\"cssClasses\":null,\"containerAttributes\":[],\"inputAttributes\":[],\"includeInEmail\":true,\"emailValue\":null,\"enableConditions\":false,\"conditions\":null,\"enableContentEncryption\":false,\"visibility\":null}','2026-03-15 18:45:53','2026-03-15 19:34:54','f999ee51-f86d-4be3-b1f9-b2d1a5771b2b');
/*!40000 ALTER TABLE `formie_fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_forms`
--

LOCK TABLES `formie_forms` WRITE;
/*!40000 ALTER TABLE `formie_forms` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_forms` VALUES (3,'splashSignup','{\"displayFormTitle\":false,\"displayCurrentPageTitle\":false,\"displayPageTabs\":false,\"displayPageProgress\":false,\"scrollToTop\":true,\"progressPosition\":\"end\",\"progressValuePosition\":\"inside-center\",\"defaultLabelPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"defaultInstructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"requiredIndicator\":\"asterisk\",\"submitMethod\":\"page-reload\",\"submitAction\":\"url\",\"submitActionTab\":\"same-tab\",\"submitActionUrl\":\"\\/?signedup=1\",\"submitActionFormHide\":true,\"submitActionMessage\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"attrs\\\":{\\\"textAlign\\\":\\\"start\\\"},\\\"content\\\":[{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\"Thank you for signing up! We\'ll let you know when it launches and if you\'re a provider we\'ll send an invite to fill out your profile in due time!\\\"}]}]\",\"submitActionMessageTimeout\":null,\"submitActionMessagePosition\":\"top-form\",\"loadingIndicator\":\"text\",\"loadingIndicatorText\":\"Please wait…\",\"validationOnSubmit\":true,\"validationOnFocus\":false,\"errorMessage\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"attrs\\\":{\\\"textAlign\\\":\\\"start\\\"},\\\"content\\\":[{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\"Couldn’t save submission due to errors.\\\"}]}]\",\"errorMessagePosition\":\"top-form\",\"requireUser\":false,\"requireUserMessage\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"attrs\\\":{\\\"textAlign\\\":\\\"start\\\"}}]\",\"scheduleForm\":false,\"scheduleFormStart\":null,\"scheduleFormEnd\":null,\"scheduleFormPendingMessage\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"attrs\\\":{\\\"textAlign\\\":\\\"start\\\"}}]\",\"scheduleFormExpiredMessage\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"attrs\\\":{\\\"textAlign\\\":\\\"start\\\"}}]\",\"limitSubmissions\":null,\"limitSubmissionsNumber\":null,\"limitSubmissionsType\":\"total\",\"limitSubmissionsMessage\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"attrs\\\":{\\\"textAlign\\\":\\\"start\\\"}}]\",\"limitSubmissionsIpAddressNumber\":null,\"limitSubmissionsIpAddressType\":\"total\",\"limitSubmissionsIpAddressMessage\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"attrs\\\":{\\\"textAlign\\\":\\\"start\\\"}}]\",\"integrations\":[],\"submissionTitleFormat\":\"{field:name}\",\"collectIp\":false,\"collectUser\":false,\"dataRetention\":null,\"dataRetentionValue\":null,\"fileUploadsAction\":null,\"redirectUrl\":null,\"pageRedirectUrl\":null,\"defaultEmailTemplateId\":null,\"disableCaptchas\":false}',1,1,NULL,NULL,1,'forever',NULL,'retain','retain','2026-03-15 18:41:49','2026-04-08 15:17:49','614d4ba7-1595-47bc-9b09-76b3fe658369');
/*!40000 ALTER TABLE `formie_forms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_formtemplates`
--

LOCK TABLES `formie_formtemplates` WRITE;
/*!40000 ALTER TABLE `formie_formtemplates` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_formtemplates` VALUES (1,'Splash','splash','_forms/splash',1,0,1,0,1,'page-header','page-footer',1,NULL,NULL,'2026-03-15 19:42:05','2026-03-15 19:42:05','eb8a7a70-63cb-4cc1-bae4-e3516a6766ee');
/*!40000 ALTER TABLE `formie_formtemplates` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_integrations`
--

LOCK TABLES `formie_integrations` WRITE;
/*!40000 ALTER TABLE `formie_integrations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `formie_integrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_notifications`
--

LOCK TABLES `formie_notifications` WRITE;
/*!40000 ALTER TABLE `formie_notifications` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_notifications` VALUES (1,3,NULL,NULL,'Admin Notification','adminNotification',0,'A new submission was made on \"{formName}\"','email','{systemEmail}',NULL,NULL,NULL,'{field:emailAddress}',NULL,NULL,NULL,NULL,'[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":\"start\"},\"content\":[{\"type\":\"text\",\"text\":\"A user submission has been made on the \\\"\"},{\"type\":\"variableTag\",\"attrs\":{\"label\":\"Form Name\",\"value\":\"{formName}\"}},{\"type\":\"text\",\"text\":\"\\\" form on \"},{\"type\":\"variableTag\",\"attrs\":{\"label\":\"Site Name\",\"value\":\"{siteName}\"}},{\"type\":\"text\",\"text\":\" at \"},{\"type\":\"variableTag\",\"attrs\":{\"label\":\"Timestamp (yyyy-mm-dd hh:mm:ss)\",\"value\":\"{timestamp}\"}}]},{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":\"start\"},\"content\":[{\"type\":\"text\",\"text\":\"Their submission details are:\"}]},{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":\"start\"},\"content\":[{\"type\":\"variableTag\",\"attrs\":{\"label\":\"All Form Fields\",\"value\":\"{allFields}\"}}]}]',1,NULL,'[]',NULL,NULL,'[]','2026-03-15 18:41:49','2026-04-08 15:17:49','eb69b688-043f-46e7-87a6-bc1a3d2f736f'),(2,3,NULL,NULL,'User Notification','userNotification',0,'Thanks for contacting us!','email','{field:emailAddress}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":\"start\"},\"content\":[{\"type\":\"text\",\"text\":\"Thanks again for contacting us. Our team will get back to you as soon as we can.\"}]},{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":\"start\"},\"content\":[{\"type\":\"text\",\"text\":\"As a reminder, you submitted the following details at \"},{\"type\":\"variableTag\",\"attrs\":{\"label\":\"Timestamp (yyyy-mm-dd hh:mm:ss)\",\"value\":\"{timestamp}\"}}]},{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":\"start\"},\"content\":[{\"type\":\"variableTag\",\"attrs\":{\"label\":\"All Form Fields\",\"value\":\"{allFields}\"}}]}]',1,NULL,'[]',NULL,NULL,'[]','2026-03-15 18:41:49','2026-04-08 15:17:49','d23dc7b6-6dda-480d-bb95-3da2e7a7bc1b');
/*!40000 ALTER TABLE `formie_notifications` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_payments`
--

LOCK TABLES `formie_payments` WRITE;
/*!40000 ALTER TABLE `formie_payments` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `formie_payments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_payments_plans`
--

LOCK TABLES `formie_payments_plans` WRITE;
/*!40000 ALTER TABLE `formie_payments_plans` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `formie_payments_plans` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_payments_subscriptions`
--

LOCK TABLES `formie_payments_subscriptions` WRITE;
/*!40000 ALTER TABLE `formie_payments_subscriptions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `formie_payments_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_pdftemplates`
--

LOCK TABLES `formie_pdftemplates` WRITE;
/*!40000 ALTER TABLE `formie_pdftemplates` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `formie_pdftemplates` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_relations`
--

LOCK TABLES `formie_relations` WRITE;
/*!40000 ALTER TABLE `formie_relations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `formie_relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_sentnotifications`
--

LOCK TABLES `formie_sentnotifications` WRITE;
/*!40000 ALTER TABLE `formie_sentnotifications` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_sentnotifications` VALUES (25,'Admin Notification',3,24,1,'A new submission was made on \"Launch Sign-up\"','support@tinytreecounseling.com',NULL,NULL,'','','support@tinytreecounseling.com','DBT Search',NULL,'A user submission has been made on the \"Launch Sign-up\" form on DBT\nSearch at 2026-03-15 13:09:07\n\nTheir submission details are:\n\nNAME\nMary Souder\n\nORGANIZATION\nTiny Tree Counseling & Consulting\n\nEMAIL ADDRESS\nsouder.mary@gmail.com\n\nCERTIFIED PROVIDER\nYes\n','<p>A user submission has been made on the \"Launch Sign-up\" form on DBT Search at 2026-03-15 13:09:07</p><p>Their submission details are:</p>    \n    <p>\n            <strong>Name</strong><br />\n    \n            Mary Souder\n    </p>\n    \n    <p>\n            <strong>Organization</strong><br />\n    \n            Tiny Tree Counseling &amp; Consulting\n    </p>\n    \n    <p>\n            <strong>Email Address</strong><br />\n    \n            souder.mary@gmail.com\n    </p>\n    \n    <p>\n            <strong>Certified Provider</strong><br />\n    \n            Yes\n    </p>','{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"192.168.97.1\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',1,NULL,'2026-03-15 20:09:07','2026-03-15 20:09:07','92d56e52-280f-44f6-bb1d-a7f3ee8eea5e'),(26,'User Notification',3,24,2,'','',NULL,NULL,'','','','',NULL,NULL,NULL,'{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"192.168.97.1\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email error. No recipient email address found.','2026-03-15 20:09:07','2026-03-15 20:09:07','13c407d0-7bc6-42dc-b1cf-63f81a6ad605'),(27,'Admin Notification',3,24,1,'A new submission was made on \"Launch Sign-up\"','support@tinytreecounseling.com',NULL,NULL,'','','support@tinytreecounseling.com','DBT Search',NULL,'A user submission has been made on the \"Launch Sign-up\" form on DBT\nSearch at 2026-03-15 13:09:42\n\nTheir submission details are:\n\nNAME\nMary Souder\n\nORGANIZATION\nTiny Tree Counseling & Consulting\n\nEMAIL ADDRESS\nsouder.mary@gmail.com\n\nCERTIFIED PROVIDER\nYes\n','<p>A user submission has been made on the \"Launch Sign-up\" form on DBT Search at 2026-03-15 13:09:42</p><p>Their submission details are:</p>    \n    <p>\n            <strong>Name</strong><br />\n    \n            Mary Souder\n    </p>\n    \n    <p>\n            <strong>Organization</strong><br />\n    \n            Tiny Tree Counseling &amp; Consulting\n    </p>\n    \n    <p>\n            <strong>Email Address</strong><br />\n    \n            souder.mary@gmail.com\n    </p>\n    \n    <p>\n            <strong>Certified Provider</strong><br />\n    \n            Yes\n    </p>','{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"192.168.97.1\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',1,NULL,'2026-03-15 20:09:42','2026-03-15 20:09:42','cceebc58-ce72-4b58-8a12-eadc80ecc280'),(28,'User Notification',3,24,2,'','',NULL,NULL,'','','','',NULL,NULL,NULL,'{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"192.168.97.1\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email error. No recipient email address found.','2026-03-15 20:09:47','2026-03-15 20:09:47','bdcb4b4f-1696-4c13-961b-07ffc537b901'),(57,'Admin Notification',3,56,1,'A new submission was made on \"Launch Sign-up\"','support@tinytreecounseling.com',NULL,NULL,'','','support@tinytreecounseling.com','DBT Search',NULL,'A user submission has been made on the \"Launch Sign-up\" form on DBT\nSearch at 2026-03-17 00:57:34\n\nTheir submission details are:\n\nNAME\nBrian Larson\n\nORGANIZATION\nMighty Citizen\n\nEMAIL ADDRESS\nblarson@mightycitizen.com\n\nCERTIFIED PROVIDER\nYes\n','<p>A user submission has been made on the \"Launch Sign-up\" form on DBT Search at 2026-03-17 00:57:34</p><p>Their submission details are:</p>    \n    <p>\n            <strong>Name</strong><br />\n    \n            Brian Larson\n    </p>\n    \n    <p>\n            <strong>Organization</strong><br />\n    \n            Mighty Citizen\n    </p>\n    \n    <p>\n            <strong>Email Address</strong><br />\n    \n            blarson@mightycitizen.com\n    </p>\n    \n    <p>\n            <strong>Certified Provider</strong><br />\n    \n            Yes\n    </p>','{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',1,NULL,'2026-03-17 05:57:35','2026-03-17 05:57:35','ef9dc6b5-ce38-4fdc-a692-bdf8caf1f24f'),(58,'User Notification',3,56,2,'','',NULL,NULL,'','','','',NULL,NULL,NULL,'{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email error. No recipient email address found.','2026-03-17 05:57:36','2026-03-17 05:57:36','33ebcde2-ab74-4ba6-a896-c5ecaf3a1bb5'),(59,'Admin Notification',3,55,1,'A new submission was made on \"Launch Sign-up\"','support@tinytreecounseling.com',NULL,NULL,'','','support@tinytreecounseling.com','DBT Search',NULL,'A user submission has been made on the \"Launch Sign-up\" form on DBT\nSearch at 2026-03-17 00:59:02\n\nTheir submission details are:\n\nNAME\nBrian Larson\n\nORGANIZATION\nNo response.\n\nEMAIL ADDRESS\nbrian@brianlarson.com\n\nCERTIFIED PROVIDER\nYes\n','<p>A user submission has been made on the \"Launch Sign-up\" form on DBT Search at 2026-03-17 00:59:02</p><p>Their submission details are:</p>    \n    <p>\n            <strong>Name</strong><br />\n    \n            Brian Larson\n    </p>\n    \n    <p>\n            <strong>Organization</strong><br />\n    \n            No response.\n    </p>\n    \n    <p>\n            <strong>Email Address</strong><br />\n    \n            brian@brianlarson.com\n    </p>\n    \n    <p>\n            <strong>Certified Provider</strong><br />\n    \n            Yes\n    </p>','{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',1,NULL,'2026-03-17 05:59:02','2026-03-17 05:59:02','26060b9f-f8f0-4b7d-814e-2b14c46d0d0f'),(60,'User Notification',3,55,2,'','',NULL,NULL,'','','','',NULL,NULL,NULL,'{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email error. No recipient email address found.','2026-03-17 05:59:02','2026-03-17 05:59:02','f1e89e7d-4fff-4030-b69a-072adbbfa4f8'),(61,'User Notification',3,56,2,'','',NULL,NULL,'','','','',NULL,NULL,NULL,'{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email error. No recipient email address found.','2026-03-17 05:59:02','2026-03-17 05:59:02','52416969-534e-400e-8eda-380e32eebf4e'),(62,'User Notification',3,56,2,'','',NULL,NULL,'','','','',NULL,NULL,NULL,'{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email error. No recipient email address found.','2026-03-17 05:59:42','2026-03-17 05:59:42','f82fcbb6-75b1-49ef-8fde-b8b26e7e62ac'),(73,'Admin Notification',3,72,1,'A new submission was made on \"Launch Sign-up\"','support@tinytreecounseling.com',NULL,NULL,'','','support@tinytreecounseling.com','DBT Search',NULL,'A user submission has been made on the \"Launch Sign-up\" form on DBT\nSearch at 2026-03-17 09:08:11\n\nTheir submission details are:\n\nNAME\nMary Souder\n\nORGANIZATION\nTiny Tree\n\nEMAIL ADDRESS\nsupport@tinytreecounseling.com\n\nCERTIFIED PROVIDER\nYes\n','<p>A user submission has been made on the \"Launch Sign-up\" form on DBT Search at 2026-03-17 09:08:11</p><p>Their submission details are:</p>    \n    <p>\n            <strong>Name</strong><br />\n    \n            Mary Souder\n    </p>\n    \n    <p>\n            <strong>Organization</strong><br />\n    \n            Tiny Tree\n    </p>\n    \n    <p>\n            <strong>Email Address</strong><br />\n    \n            support@tinytreecounseling.com\n    </p>\n    \n    <p>\n            <strong>Certified Provider</strong><br />\n    \n            Yes\n    </p>','{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/26.3 Mobile\\/15E148 Safari\\/604.1\",\"transportType\":\"Sendmail\"}',1,NULL,'2026-03-17 14:08:12','2026-03-17 14:08:12','d072ef7e-79e9-4565-9128-a05c9bcc900e'),(74,'User Notification',3,72,2,'','',NULL,NULL,'','','','',NULL,NULL,NULL,'{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/26.3 Mobile\\/15E148 Safari\\/604.1\",\"transportType\":\"Sendmail\"}',0,'Notification email error. No recipient email address found.','2026-03-17 14:08:12','2026-03-17 14:08:12','b1223e55-b0fc-4290-8d97-9990fdb32b20'),(76,'Admin Notification',3,75,1,'A new submission was made on \"Launch Sign-up\"','support@tinytreecounseling.com',NULL,NULL,'','','support@tinytreecounseling.com','DBT Search',NULL,'A user submission has been made on the \"Launch Sign-up\" form on DBT\nSearch at 2026-04-06 12:14:36\n\nTheir submission details are:\n\nNAME\nBrian Larson\n\nORGANIZATION\nMighty Citizen\n\nEMAIL ADDRESS\nblarson@mightycitizen.com\n\nCERTIFIED PROVIDER\nYes\n','<p>A user submission has been made on the \"Launch Sign-up\" form on DBT Search at 2026-04-06 12:14:36</p><p>Their submission details are:</p>    \n    <p>\n            <strong>Name</strong><br />\n    \n            Brian Larson\n    </p>\n    \n    <p>\n            <strong>Organization</strong><br />\n    \n            Mighty Citizen\n    </p>\n    \n    <p>\n            <strong>Email Address</strong><br />\n    \n            blarson@mightycitizen.com\n    </p>\n    \n    <p>\n            <strong>Certified Provider</strong><br />\n    \n            Yes\n    </p>','{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email “Admin Notification” could not be sent for submission “75”. Error: Call to undefined function Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\proc_open() /home/1606631.cloudwaysapps.com/dpvnkagjdf/public_html/cms/vendor/symfony/mailer/Transport/Smtp/Stream/ProcessStream.php:47','2026-04-06 17:14:37','2026-04-06 17:14:37','451a3766-b9fb-4330-9e3d-aa64280c1dea'),(77,'User Notification',3,75,2,'','',NULL,NULL,'','','','',NULL,NULL,NULL,'{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email error. No recipient email address found.','2026-04-06 17:14:37','2026-04-06 17:14:37','7c7412fd-28e6-46fc-972a-a81e79f0ca9e'),(79,'Admin Notification',3,78,1,'A new submission was made on \"Launch Sign-up\"','support@tinytreecounseling.com',NULL,NULL,'','','support@tinytreecounseling.com','DBT Search',NULL,'A user submission has been made on the \"Launch Sign-up\" form on DBT\nSearch at 2026-04-07 21:31:16\n\nTheir submission details are:\n\nNAME\nMary Souder\n\nORGANIZATION\nTiny Tree Counseling\n\nEMAIL ADDRESS\nsupport@tinytreecounseling.com\n\nCERTIFIED PROVIDER\nYes\n','<p>A user submission has been made on the \"Launch Sign-up\" form on DBT Search at 2026-04-07 21:31:16</p><p>Their submission details are:</p>    \n    <p>\n            <strong>Name</strong><br />\n    \n            Mary Souder\n    </p>\n    \n    <p>\n            <strong>Organization</strong><br />\n    \n            Tiny Tree Counseling\n    </p>\n    \n    <p>\n            <strong>Email Address</strong><br />\n    \n            support@tinytreecounseling.com\n    </p>\n    \n    <p>\n            <strong>Certified Provider</strong><br />\n    \n            Yes\n    </p>','{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email “Admin Notification” could not be sent for submission “78”. Error: Call to undefined function Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\proc_open() /home/1606631.cloudwaysapps.com/dpvnkagjdf/public_html/cms/vendor/symfony/mailer/Transport/Smtp/Stream/ProcessStream.php:47','2026-04-08 02:31:17','2026-04-08 02:31:17','fdff83a1-f26a-40d8-9124-8466decfd705'),(80,'User Notification',3,78,2,'','',NULL,NULL,'','','','',NULL,NULL,NULL,'{\"formieVersion\":\"Formie 3.1.17\",\"craftVersion\":\"Craft Pro 5.9.16\",\"ipAddress\":\"24.118.60.243\",\"userAgent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/146.0.0.0 Safari\\/537.36\",\"transportType\":\"Sendmail\"}',0,'Notification email error. No recipient email address found.','2026-04-08 02:31:18','2026-04-08 02:31:18','f537b5d1-6fbe-4ed6-bbee-240cd141398f');
/*!40000 ALTER TABLE `formie_sentnotifications` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_statuses`
--

LOCK TABLES `formie_statuses` WRITE;
/*!40000 ALTER TABLE `formie_statuses` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_statuses` VALUES (1,'Pending','pending','yellow','',NULL,1,NULL,'2026-03-15 18:00:19','2026-03-15 18:47:35','1f048049-d0c9-4364-8a8d-736b4d508537'),(2,'Approved','approved','green','',NULL,0,NULL,'2026-03-15 18:47:26','2026-03-15 18:48:20','acef0518-5cc6-4dd0-9231-234846cfc200'),(3,'Subscriber','subscriber','blue','',NULL,0,NULL,'2026-03-15 18:48:46','2026-03-15 18:48:54','ddb17090-e3f7-41d7-aab7-b1729da37d11');
/*!40000 ALTER TABLE `formie_statuses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_stencils`
--

LOCK TABLES `formie_stencils` WRITE;
/*!40000 ALTER TABLE `formie_stencils` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_stencils` VALUES (1,'Contact Form','contactForm','{\"notifications\":[{\"attachFiles\":true,\"content\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"content\\\":[{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\"A user submission has been made on the \\\\\\\"\\\"},{\\\"type\\\":\\\"variableTag\\\",\\\"attrs\\\":{\\\"label\\\":\\\"Form Name\\\",\\\"value\\\":\\\"{formName}\\\"}},{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\"\\\\\\\" form on \\\"},{\\\"type\\\":\\\"variableTag\\\",\\\"attrs\\\":{\\\"label\\\":\\\"Site Name\\\",\\\"value\\\":\\\"{siteName}\\\"}},{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\" at \\\"},{\\\"type\\\":\\\"variableTag\\\",\\\"attrs\\\":{\\\"label\\\":\\\"Timestamp (yyyy-mm-dd hh:mm:ss)\\\",\\\"value\\\":\\\"{timestamp}\\\"}}]},{\\\"type\\\":\\\"paragraph\\\",\\\"content\\\":[{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\"Their submission details are:\\\"}]},{\\\"type\\\":\\\"paragraph\\\",\\\"content\\\":[{\\\"type\\\":\\\"variableTag\\\",\\\"attrs\\\":{\\\"label\\\":\\\"All Form Fields\\\",\\\"value\\\":\\\"{allFields}\\\"}}]}]\",\"enabled\":true,\"name\":\"Admin Notification\",\"replyTo\":\"{field:emailAddress}\",\"subject\":\"A new submission was made on \\\"{formName}\\\"\",\"to\":\"{systemEmail}\"},{\"attachFiles\":true,\"content\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"content\\\":[{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\"Thanks again for contacting us. Our team will get back to you as soon as we can.\\\"}]},{\\\"type\\\":\\\"paragraph\\\",\\\"content\\\":[{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\"As a reminder, you submitted the following details at \\\"},{\\\"type\\\":\\\"variableTag\\\",\\\"attrs\\\":{\\\"label\\\":\\\"Timestamp (yyyy-mm-dd hh:mm:ss)\\\",\\\"value\\\":\\\"{timestamp}\\\"}}]},{\\\"type\\\":\\\"paragraph\\\",\\\"content\\\":[{\\\"type\\\":\\\"variableTag\\\",\\\"attrs\\\":{\\\"label\\\":\\\"All Form Fields\\\",\\\"value\\\":\\\"{allFields}\\\"}}]}]\",\"enabled\":true,\"name\":\"User Notification\",\"replyTo\":null,\"subject\":\"Thanks for contacting us!\",\"to\":\"{field:emailAddress}\"}],\"pages\":[{\"label\":\"Page 1\",\"settings\":{\"submitButtonLabel\":\"Contact us\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\"},\"rows\":[{\"fields\":[{\"type\":\"verbb\\\\formie\\\\fields\\\\Name\",\"settings\":{\"useMultipleFields\":true,\"instructions\":\"Please enter your full name.\",\"enabled\":true,\"required\":false,\"placeholder\":\"Your name\",\"labelPosition\":\"verbb\\\\formie\\\\positions\\\\Hidden\",\"instructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"label\":\"Your Name\",\"handle\":\"yourName\",\"rows\":[{\"fields\":[{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\NamePrefix\",\"settings\":{\"enabled\":false,\"required\":false,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"honorific-prefix\"}],\"options\":[{\"label\":\"Select an option\",\"value\":\"\",\"isDefault\":true,\"isOptgroup\":false}],\"label\":\"Prefix\",\"handle\":\"prefix\"}},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\NameFirst\",\"settings\":{\"enabled\":true,\"required\":true,\"placeholder\":\"e.g. Peter\",\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"given-name\"}],\"label\":\"First Name\",\"handle\":\"firstName\"}},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\NameMiddle\",\"settings\":{\"enabled\":false,\"required\":false,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"additional-name\"}],\"label\":\"Middle Name\",\"handle\":\"middleName\"}},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\NameLast\",\"settings\":{\"enabled\":true,\"required\":true,\"placeholder\":\"e.g. Sherman\",\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"family-name\"}],\"label\":\"Last Name\",\"handle\":\"lastName\"}}]}]}}]},{\"fields\":[{\"type\":\"verbb\\\\formie\\\\fields\\\\Email\",\"settings\":{\"instructions\":\"Please enter your email so we can get in touch.\",\"enabled\":true,\"required\":true,\"placeholder\":\"e.g. psherman@wallaby.com\",\"label\":\"Email Address\",\"handle\":\"emailAddress\"}}]},{\"fields\":[{\"type\":\"verbb\\\\formie\\\\fields\\\\MultiLineText\",\"settings\":{\"instructions\":\"Please enter your comments.\",\"enabled\":true,\"required\":true,\"placeholder\":\"e.g. The reason for my enquiry is...\",\"label\":\"Message\",\"handle\":\"message\"}}]}]}],\"settings\":{\"defaultInstructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"defaultLabelPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"errorMessage\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"content\\\":[{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\"Couldn’t save submission due to errors.\\\"}]}]\",\"errorMessagePosition\":\"top-form\",\"loadingIndicator\":\"spinner\",\"progressPosition\":\"end\",\"progressValuePosition\":\"inside-center\",\"submissionTitleFormat\":\"{timestamp}\",\"submitAction\":\"message\",\"submitActionMessage\":\"[{\\\"type\\\":\\\"paragraph\\\",\\\"content\\\":[{\\\"type\\\":\\\"text\\\",\\\"text\\\":\\\"Thank you for contacting us! Our team will get in touch shortly to follow up on your message.\\\"}]}]\",\"submitActionMessagePosition\":\"top-form\",\"submitMethod\":\"ajax\",\"validationOnFocus\":\"1\",\"validationOnSubmit\":\"1\"}}',NULL,NULL,NULL,1,NULL,'2026-03-15 18:00:19','2026-03-15 18:00:19','d7cbe0ad-28b6-4a03-ace9-d634d2072400');
/*!40000 ALTER TABLE `formie_stencils` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `formie_submissions`
--

LOCK TABLES `formie_submissions` WRITE;
/*!40000 ALTER TABLE `formie_submissions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `formie_submissions` VALUES (24,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"souder.mary@gmail.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Tiny Tree Counseling & Consulting\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Mary Souder\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'[]',NULL,'2026-03-15 20:08:55','2026-03-15 20:08:55','5c26d81c-3b3a-4e34-8057-1c8827864efc'),(29,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"blarson@mightycitizen.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Mighty Citizen\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian Larson\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": false}',3,1,NULL,0,0,NULL,NULL,'[]',NULL,'2026-03-15 20:18:40','2026-03-15 20:18:40','1f8b3912-e2e9-4a87-84c2-c18e3f3b14a4'),(49,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"blarson@mightycitizen.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Mighty Citizen\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian Larson\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'[]',NULL,'2026-03-17 04:28:44','2026-03-17 04:28:44','bb40ada6-7f65-4993-822a-59657cb6dbba'),(50,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"brian@brianlarson.com\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": false}',3,1,NULL,0,0,NULL,NULL,'[]',NULL,'2026-03-17 04:28:54','2026-03-17 04:28:54','21f4604d-49fb-4b40-a27d-fb4d3fa9315a'),(51,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"brian@brianlarson.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Mighty Citizen\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian Larson\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\"}}',NULL,'2026-03-17 04:32:41','2026-03-17 04:32:41','b720acf0-5fdb-4ddd-ae3d-e8cb130d66fd'),(52,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"brian@brianlarson.com\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian Larson\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": false}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\"}}',NULL,'2026-03-17 04:33:25','2026-03-17 04:33:25','e0293596-4a26-40cf-802f-c8a52803feeb'),(53,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"blarson26@gmail.com\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian Larson\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": false}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\"}}',NULL,'2026-03-17 04:33:41','2026-03-17 04:33:41','b5c07a7d-3a30-4c02-a792-59d008fbf1d7'),(54,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"brian@brianlarson.com\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian Larson\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": false}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-03-17 04:36:56','2026-03-17 04:36:56','722d4d98-7e2d-4bb2-a5e6-09ea62e7fa07'),(55,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"brian@brianlarson.com\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian Larson\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-03-17 04:38:24','2026-03-17 04:38:24','e1f45501-0a91-4c9d-9f44-5f85c5ba2781'),(56,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"blarson@mightycitizen.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Mighty Citizen\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian Larson\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-03-17 05:57:18','2026-03-17 05:57:18','494ddf89-c46c-4758-9759-5d221976bfdc'),(72,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"support@tinytreecounseling.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Tiny Tree\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Mary Souder\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-03-17 14:07:25','2026-03-17 14:07:25','13c37958-d437-453f-b0c9-77b9dbd340a9'),(75,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"blarson@mightycitizen.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Mighty Citizen\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Brian Larson\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-06 17:10:32','2026-04-06 17:10:32','8cc75565-4c11-4f1d-a51d-795608be4562'),(78,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"support@tinytreecounseling.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Tiny Tree Counseling\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Mary Souder\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 02:31:04','2026-04-08 02:31:04','2ad17c5d-d803-4913-8745-4f49112c96ad'),(81,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"masp@mhs-dbt.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Mental Health Systems\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Madeline Asp\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 14:59:25','2026-04-08 14:59:25','92926d64-e408-441e-8f43-adf67a6bbaee'),(82,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"caila@artofcounselingstpaul.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Art of Counseling\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Caila Kritzeck\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 14:59:31','2026-04-08 14:59:31','013c0a12-dba9-43f8-8a73-5c699ee86397'),(83,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"joripplinger@gmail.com\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Jo Ripplinger\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 14:59:57','2026-04-08 14:59:57','04f80b99-1e97-42bd-bb2c-1c90bb47ad1f'),(84,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"josh.powell@voamn.org\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Vona Center for Mental Health/VOA\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Josh Powell\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 15:00:08','2026-04-08 15:00:08','28914411-bdce-41bb-889d-d6992f4132b9'),(85,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"ecarlton@imsofmn.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"IMS\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Elizabeth Carlton\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 15:00:14','2026-04-08 15:00:14','4680aaf0-3902-416b-9c57-7a0dee23ca59'),(86,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"mwerner@autonomypllc.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Autonomy Counseling, PLLC\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Marsha Werner\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 15:00:19','2026-04-08 15:00:19','55b7ceb8-3dfe-45d0-987c-efd34aebf8b1'),(87,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"kperry@familyservicerochester.org\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Family Service Rochester\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Kate Perry\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 15:01:52','2026-04-08 15:01:52','5ca303b4-9dd4-4065-9806-d2f6410be895'),(88,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"haley@securebasecounselingcenter.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Secure Base Counseling Center\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Haley Raifsnider\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 15:02:32','2026-04-08 15:02:32','57a4a021-e68e-41cf-babf-b862f8297497'),(89,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"jkoerner@familyservicerochester.org\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Family Service Rochester\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Joyce Koerner\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 15:17:25','2026-04-08 15:17:25','ac2e142b-2d76-40d7-994f-97d02eb72971'),(90,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"jgoerger@fernbrook.org\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Fernbrook Family Center\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Jennifer Goerger\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-08 22:16:02','2026-04-08 22:16:02','3c375d3e-f6bd-4dd4-88aa-a2a096320d32'),(91,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"colleen.m.starkey@healthpartners.org\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Health Partners \", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Colleen Starkey\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": false}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-09 01:15:25','2026-04-09 01:15:25','53a307bb-47d8-4d99-9412-30f40a6695bf'),(92,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"patty.lauer-roberts@radiashealth.org\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"RADIAS Health\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Patty Lauer-Roberts\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-09 12:51:07','2026-04-09 12:51:07','d73557f7-2ee7-46dd-b0bf-afe93f6a5b34'),(93,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"kristin.bunge@tinytreecounseling.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Tiny Tree Counseling\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Kristin Bunge\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-09 15:10:26','2026-04-24 16:11:52','cc89bf7f-6f79-4249-948d-c33cb6dfd619'),(94,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"sarah.souder@gmail.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"This is cool! \", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Aneata Test\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": false}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-10 02:44:52','2026-04-10 02:44:52','31bd3d36-183f-4aaa-ba0e-6b6b00a5fa66'),(95,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"stephaniew@speromn.org\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"Spero\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Stephanie Wanous\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-10 16:07:49','2026-04-10 16:07:49','bad21362-e649-4535-b218-a5458362edc2'),(96,'{\"2e8787bc-1e91-404d-962a-28497ad7bbd0\": \"beth@prcounselingmn.com\", \"407e1923-de50-4f0f-8dd5-6b626abc8d82\": \"PhoenixRisen Counseling\", \"8f41dc43-dfa3-4b99-9762-4316a1fb7b9b\": \"Beth Bordenave\", \"f999ee51-f86d-4be3-b1f9-b2d1a5771b2b\": true}',3,1,NULL,0,0,NULL,NULL,'{\"form\":{\"redirectUrl\":\"\\/?signedup=1\",\"submitMethod\":\"page-reload\"}}',NULL,'2026-04-13 14:33:59','2026-04-13 14:33:59','f2155a0a-84e0-4127-8783-ba2c7ecc4709');
/*!40000 ALTER TABLE `formie_submissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2026-03-14 15:47:02','2026-03-14 15:47:02','3220f3b5-89ff-450e-9a8c-83bd4b04bdf5');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'5.9.16','5.9.0.8',0,'birwepfjctkw','3@wnzweibefo','2026-03-14 15:44:21','2026-04-08 03:44:21','bfb9e49a-1296-4fb9-b9c3-3f49e296f31f');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','0b078cf8-4f38-445f-a598-849713f0b292'),(2,'craft','m221101_115859_create_entries_authors_table','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','889461e4-d3c3-4dc4-adf5-efada913d10f'),(3,'craft','m221107_112121_add_max_authors_to_sections','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','3f02f779-a29e-4a38-89d0-c0a93d07df6d'),(4,'craft','m221205_082005_translatable_asset_alt_text','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','de6ef0d8-d8d5-4972-bbf8-cf1e972be3f7'),(5,'craft','m230314_110309_add_authenticator_table','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','57489870-6d57-4d11-b4c9-615357dddb6b'),(6,'craft','m230314_111234_add_webauthn_table','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','14ab234c-55bd-4de5-9d3c-1c03eead4d50'),(7,'craft','m230503_120303_add_recoverycodes_table','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','e73af813-9941-4639-b7ba-80654e6be09b'),(8,'craft','m230511_000000_field_layout_configs','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','beaf80fa-fa88-41a4-9e0a-e7be15daa196'),(9,'craft','m230511_215903_content_refactor','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','077a8514-7d44-40c7-b60a-b053eb1af66d'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','b27617c7-3deb-4bbc-a041-31e0c12aac13'),(11,'craft','m230524_000001_entry_type_icons','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','a36398fb-f90e-4011-9157-1ecec368de2d'),(12,'craft','m230524_000002_entry_type_colors','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','58f707eb-787c-499e-a22d-cdace035ac1a'),(13,'craft','m230524_220029_global_entry_types','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','d8552ef8-9f32-40a1-a008-6ab959a24ee3'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','2f6cb435-16f1-478a-b588-6ee2a36272bc'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','5616ff7d-f531-4dd7-bedb-dbe184f78297'),(16,'craft','m230616_173810_kill_field_groups','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','658f2062-28a1-4723-8447-876802c6478a'),(17,'craft','m230616_183820_remove_field_name_limit','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','d6fee18c-cbc8-4cf9-be54-b78e90984130'),(18,'craft','m230617_070415_entrify_matrix_blocks','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','ae6c8599-082c-426e-8453-98ffad03e168'),(19,'craft','m230710_162700_element_activity','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','7ba314b9-203f-461e-b5d2-5f8b248fe20b'),(20,'craft','m230820_162023_fix_cache_id_type','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','48117bf6-171a-43f2-97cf-d2555764292b'),(21,'craft','m230826_094050_fix_session_id_type','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','6f35d5a5-aac2-42a0-abdd-c28c88699c71'),(22,'craft','m230904_190356_address_fields','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','b3db8640-d455-4519-91a4-d99669c80afe'),(23,'craft','m230928_144045_add_subpath_to_volumes','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','626fa44c-22b8-4336-9e7e-5e967caffbac'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','eacb85d6-983c-4083-a83f-2b709d524637'),(25,'craft','m231213_030600_element_bulk_ops','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','56d074fa-6050-41fa-8a5c-e3dc5c5319b3'),(26,'craft','m240129_150719_sites_language_amend_length','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','c1f832a4-669d-4eac-b67e-fd43a21aa4b2'),(27,'craft','m240206_035135_convert_json_columns','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','4e20f95b-f899-4515-8516-6787ddc1ef87'),(28,'craft','m240207_182452_address_line_3','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','3e8d5f1b-e6f4-4805-a3e1-5d49b615db57'),(29,'craft','m240302_212719_solo_preview_targets','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','62efc00e-86e9-47ae-9541-7562a2cc4a65'),(30,'craft','m240619_091352_add_auth_2fa_timestamp','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','9e72a810-1f24-48f6-baaf-98708a764811'),(31,'craft','m240723_214330_drop_bulkop_fk','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','5436eef7-060f-491e-b3fe-c9091598d541'),(32,'craft','m240731_053543_soft_delete_fields','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','e0b787d1-ed58-4b83-a964-169850fe4ace'),(33,'craft','m240805_154041_sso_identities','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','5b60cc9f-bdcb-447b-8f4c-00d95c2cd8b5'),(34,'craft','m240926_202248_track_entries_deleted_with_section','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','0b6609a8-3cc9-48e1-ba12-bcf79b8fd4e4'),(35,'craft','m241120_190905_user_affiliated_sites','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','774327a4-4400-4937-a989-8d51df6d056c'),(36,'craft','m241125_122914_add_viewUsers_permission','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','1ecfce0d-f4ed-489d-9d2b-7797f563c454'),(37,'craft','m250119_135304_entry_type_overrides','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','f0183f7c-51b9-4c6b-9db4-058a599d8c68'),(38,'craft','m250206_135036_search_index_queue','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','bf3b34de-9fe1-4c16-bd22-b51ef19ca0d9'),(39,'craft','m250207_172349_bulkop_events','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','49409494-34df-455e-b373-7faf455e8adc'),(40,'craft','m250315_131608_unlimited_authors','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','7b535203-65a5-4f61-a17a-14b42b08887c'),(41,'craft','m250403_171253_static_statuses','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','af727c76-b421-4ff1-be2c-adafe2893819'),(42,'craft','m250512_164202_asset_mime_types','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','2f558811-b762-4da5-8e83-cde2ddcb8b44'),(43,'craft','m250522_090843_add_deleteEntriesForSite_and_deletePeerEntriesForSite_permissions','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','1ac4d7a1-3b8e-41ba-ad7f-f5b925982167'),(44,'craft','m250531_183058_content_blocks','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','5c2176a6-b31c-4f29-9eef-11ba91b45899'),(45,'craft','m250623_105031_entry_type_descriptions','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','75010d17-840d-4549-aa5f-f1108dc4d8d0'),(46,'craft','m250910_144630_add_elements_owners_sort_order_index','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','82595f7e-3bc5-4dd9-ab71-fe6eea49a827'),(47,'craft','m251030_203440_drop_widgets_enabled_column','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','e40e8010-1db3-458c-bf81-7f994632c065'),(48,'craft','m251110_192405_entry_type_ui_label_formats','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','4d6e0e5f-876d-498c-8fc6-81c4693409f1'),(49,'craft','m251205_190131_drop_searchindexqueue_fk','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','66f9d92d-64e1-4022-b3e8-d352a6b97036'),(50,'craft','m251230_192239_update_field_layouts','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','b0ee2f4f-9808-46c2-820e-a3cf60bd57a2'),(51,'craft','m260106_130629_directive_schema_components','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','30334937-63b5-405a-a2fa-3e1712c0b6b5'),(52,'craft','m260120_120907_line_breaks_in_titles','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','3462a62d-374a-4fb7-bff8-4f6b1798bd05'),(53,'craft','m260125_233614_changeAuthorForPeerEntries_permission','2026-03-14 15:44:22','2026-03-14 15:44:22','2026-03-14 15:44:22','0eaeff30-18a1-48d0-b817-f4c4806d0a44'),(54,'module:verbb-auth','m221127_000000_install','2026-03-15 18:00:17','2026-03-15 18:00:17','2026-03-15 18:00:17','f72cfd1d-54f8-4a7c-b89d-5040cbc5e79c'),(55,'plugin:formie','Install','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','a71b9acb-cf6b-42cf-85c3-2c7fdb902a68'),(56,'plugin:formie','m231125_000000_craft5','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','ba5ec374-982b-4e8b-aea1-757b0d1198e0'),(57,'plugin:formie','m231129_000000_integrations_mapping','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','b2fe9a22-5d56-40b5-8c9b-927f12daabc8'),(58,'plugin:formie','m231130_000000_conditions_mapping','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','dbfbd18d-d0d2-4ea2-9384-cb9df0b3983d'),(59,'plugin:formie','m231202_000000_auth_module','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','c0feeeb2-a066-4f5c-9f18-c2db451f4e13'),(60,'plugin:formie','m240130_000000_permissions','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','45d446e7-b405-40f2-b265-57b4fbd691df'),(61,'plugin:formie','m240313_000000_subfields','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','6686647e-d4cf-48c8-a370-596b1c2b344f'),(62,'plugin:formie','m240318_000000_fix_content_table','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','ede2d26e-28bc-44ce-b361-a9afb849f326'),(63,'plugin:formie','m240318_000000_migrate_stencils','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','2c308e2e-de76-4884-8ea9-b8cdef8b58da'),(64,'plugin:formie','m240318_000000_notification_fields','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','32b2adb2-f0cf-4e18-8714-308dffe0f6b7'),(65,'plugin:formie','m240325_000000_notifications_custom_settings','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','fef6a383-a490-4e0d-b15d-4b967f00395f'),(66,'plugin:formie','m240407_000000_payment_fk','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','38f25afb-fe7c-4a6a-b1f8-5346fe839ada'),(67,'plugin:formie','m240507_000000_entry_integration_ids','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','fe8b62ee-45bd-42b8-80ba-0a507556de90'),(68,'plugin:formie','m240528_000000_payment_fk','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','6cf1ed28-4b67-4441-a32c-c35ccfadf8dd'),(69,'plugin:formie','m240614_000000_klaviyo','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','27ec3c71-4149-4554-aa3c-e241b8cd749b'),(70,'plugin:formie','m240807_000000_migrate_date_field_datetime','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','0912c014-1328-4f1b-8a49-642cbeb1d082'),(71,'plugin:formie','m241128_000000_user_group_integrations','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','187e3ae6-0977-4397-9a55-01707b5d9868'),(72,'plugin:formie','m241128_100000_entry_integrations','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','931b8077-8b68-41b4-bb5c-dfcc327b7a6a'),(73,'plugin:formie','m250113_000000_calculations','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','efd48417-d8e7-4d18-a06d-906d3e798bd3'),(74,'plugin:formie','m250114_000000_email_blocked_domains','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','8d814556-7123-4544-8486-9c8ff3bada4b'),(75,'plugin:formie','m250117_000000_date_year_min','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','f6679feb-49b5-4e58-942f-f12553334d05'),(76,'plugin:formie','m250516_000000_payment_redirect','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','4ca7d298-9fbd-45fb-b4eb-17a6b2c75abe'),(77,'plugin:formie','m250711_000000_fix_element_field_source_ids','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','5c040977-9659-4b39-88c8-2c22c86287d0'),(78,'plugin:formie','m250806_000000_integrations_optin','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','4f98bb42-ab81-45d1-bd17-da71ba54bbe9'),(79,'plugin:formie','m251014_000000_date_subfields','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','59ac8681-3c53-4b2a-a0d6-cff63cca2f4c'),(80,'plugin:formie','m251114_000000_email_conditions_mapping','2026-03-15 18:00:19','2026-03-15 18:00:19','2026-03-15 18:00:19','1cbd94bf-e809-469e-9edd-9e270596bebd'),(81,'plugin:ckeditor','m260220_182920_drop_cke_configs','2026-03-17 04:01:11','2026-03-17 04:01:11','2026-03-17 04:01:11','266ba125-e646-40fc-8a04-1458eadded1f');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'formie','3.1.17','3.4.12','2026-03-15 18:00:17','2026-03-15 18:00:17','2026-03-15 18:00:17','a07b6bed-85a3-4265-9af1-473d0dca3103'),(2,'ckeditor','5.2.0','5.0.0.1','2026-03-17 04:01:11','2026-03-17 04:01:11','2026-03-17 04:01:11','52e73a2e-acb9-4803-bc7b-995124b1a156'),(3,'resend','5.0.0','1.0.0','2026-04-08 03:44:21','2026-04-08 03:44:21','2026-04-08 03:44:21','edd71f2f-120a-4319-b73d-a1f1cbc8f602');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1775618725'),('email.fromEmail','\"system@dbtsearch.org\"'),('email.fromName','\"DBT Search\"'),('email.replyToEmail','\"no-reply@dbtsearch.org\"'),('email.template','null'),('email.transportSettings.apiKey','\"$RESEND_API_KEY\"'),('email.transportType','\"superbig\\\\resend\\\\Adapter\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.allowLineBreaksInTitles','false'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.color','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.description','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.cardThumbAlignment','\"end\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elementCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.dateAdded','\"2026-03-15T19:09:36+00:00\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.editCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.elementCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.elementEditCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.fieldUid','\"ddb25fd5-a759-494a-9d4d-96a6e44c941e\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.handle','\"label\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.instructions','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.label','\"Label\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.required','false'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.tip','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.uid','\"337e5aec-0c5a-433d-bd78-cf5ce79dfdef\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.userCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.warning','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.0.width','100'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.dateAdded','\"2026-03-15T18:54:25+00:00\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.editCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.elementCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.elementEditCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.fieldUid','\"ddb25fd5-a759-494a-9d4d-96a6e44c941e\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.handle','\"heading\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.instructions','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.label','\"Heading\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.required','false'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.tip','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.uid','\"3c17e516-45ef-413c-b36c-6c0e63dbe8f1\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.userCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.warning','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.1.width','100'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.dateAdded','\"2026-03-17T04:06:50+00:00\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.editCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.elementCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.elementEditCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.fieldUid','\"68f6aaed-7edc-4e91-9996-3a86c16baf2f\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.handle','\"content\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.instructions','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.label','\"Content\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.required','false'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.tip','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.uid','\"54105f47-70cb-4862-a58b-713095eac6cc\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.userCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.warning','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.2.width','100'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.3.dateAdded','\"2026-03-17T04:11:21+00:00\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.3.elementCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\HorizontalRule\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.3.uid','\"5f28f2bc-f3cb-4fa0-8af5-6a1a1fa88c0d\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.3.userCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.dateAdded','\"2026-03-17T04:10:34+00:00\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.editCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.elementCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.elementEditCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.fieldUid','\"ddb25fd5-a759-494a-9d4d-96a6e44c941e\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.handle','\"formHeading\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.instructions','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.label','\"Form Heading\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.required','false'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.tip','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.uid','\"b7bb25ce-84b3-420f-8390-0f4faa141f63\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.userCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.warning','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.4.width','100'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.dateAdded','\"2026-03-15T18:54:25+00:00\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.editCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.elementCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.elementEditCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.fieldUid','\"98fab9df-c419-4085-9a57-5c61f96573c2\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.handle','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.instructions','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.label','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.required','false'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.tip','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.uid','\"e2b62ea0-43f5-437d-a08c-e5bbc3ad4de9\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.userCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.warning','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.5.width','100'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.6.dateAdded','\"2026-03-17T04:11:21+00:00\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.6.elementCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.6.type','\"craft\\\\fieldlayoutelements\\\\HorizontalRule\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.6.uid','\"8241cdc9-92b5-4833-91f2-2de4c5ec8c94\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.6.userCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.dateAdded','\"2026-03-15T18:54:25+00:00\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.editCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.elementCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.elementEditCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.fieldUid','\"fe417a71-4d1b-460f-8a63-7ac81c0e5092\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.handle','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.instructions','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.label','\"Image(s)\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.required','false'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.tip','\"Select one or multiple images to randomize on page load\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.uid','\"d99165ad-d54c-4bd5-9628-a6b356f4cf1f\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.userCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.warning','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.elements.7.width','100'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.name','\"Content\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.uid','\"3962ad29-c767-4408-904d-177a4036fce2\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.tabs.0.userCondition','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.fieldLayouts.19b8c440-d617-47f4-b9b7-2dcaa4455df9.thumbFieldKey','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.handle','\"splashPage\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.hasTitleField','false'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.icon','\"hand-wave\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.name','\"Splash Page\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.showSlugField','true'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.showStatusField','true'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.slugTranslationKeyFormat','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.slugTranslationMethod','\"site\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.titleFormat','\"{title}\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.titleTranslationKeyFormat','null'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.titleTranslationMethod','\"site\"'),('entryTypes.bcf50025-2188-4126-a360-29999caeae89.uiLabelFormat','\"{title}\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.columnSuffix','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.handle','\"basicEditor\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.instructions','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.name','\"Basic Editor\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.searchable','false'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.advancedLinkFields.0','\"urlSuffix\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.advancedLinkFields.1','\"target\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.advancedLinkFields.2','\"download\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.availableTransforms','\"\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.availableVolumes','\"*\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.characterLimit','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.css','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.defaultTransform','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.defaultUploadLocationSubpath','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.defaultUploadLocationVolume','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.fullGraphqlData','true'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.headingLevels','false'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.imageEntryTypeUid','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.imageFieldUid','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.imageMode','\"img\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.js','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.options','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.parseEmbeds','false'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.purifierConfig','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.purifyHtml','true'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.showUnpermittedFiles','false'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.showUnpermittedVolumes','false'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.showWordCount','false'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.sourceEditingGroups.0','\"__ADMINS__\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.toolbar.0','\"bold\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.toolbar.1','\"italic\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.toolbar.2','\"link\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.settings.wordLimit','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.translationKeyFormat','null'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.translationMethod','\"none\"'),('fields.68f6aaed-7edc-4e91-9996-3a86c16baf2f.type','\"craft\\\\ckeditor\\\\Field\"'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.columnSuffix','null'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.handle','\"form\"'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.instructions','null'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.name','\"Form\"'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.searchable','false'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.allowSelfRelations','false'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.branchLimit','null'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.defaultPlacement','\"end\"'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.maintainHierarchy','false'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.maxRelations','null'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.minRelations','null'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.selectionLabel','null'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.showSearchInput','true'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.showSiteMenu','false'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.sources','\"*\"'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.targetSiteId','null'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.validateRelatedElements','false'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.settings.viewMode','\"list\"'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.translationKeyFormat','null'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.translationMethod','\"none\"'),('fields.98fab9df-c419-4085-9a57-5c61f96573c2.type','\"verbb\\\\formie\\\\fields\\\\Forms\"'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.columnSuffix','null'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.handle','\"plainText\"'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.instructions','null'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.name','\"Plain Text\"'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.searchable','false'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.settings.byteLimit','null'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.settings.charLimit','null'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.settings.code','false'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.settings.initialRows','1'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.settings.multiline','true'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.settings.placeholder','null'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.settings.uiMode','\"normal\"'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.translationKeyFormat','null'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.translationMethod','\"none\"'),('fields.ddb25fd5-a759-494a-9d4d-96a6e44c941e.type','\"craft\\\\fields\\\\PlainText\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.columnSuffix','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.handle','\"images\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.instructions','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.name','\"Images\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.searchable','false'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.allowedKinds','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.allowSelfRelations','false'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.allowSubfolders','false'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.allowUploads','true'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.branchLimit','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.defaultPlacement','\"end\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.defaultUploadLocationSource','\"volume:288c542e-3541-4e24-96ee-aa5fa0bea135\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.defaultUploadLocationSubpath','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.maintainHierarchy','false'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.maxRelations','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.minRelations','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.previewMode','\"full\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.restrictedDefaultUploadSubpath','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.restrictedLocationSource','\"volume:288c542e-3541-4e24-96ee-aa5fa0bea135\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.restrictedLocationSubpath','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.restrictFiles','false'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.restrictLocation','false'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.selectionLabel','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.showSearchInput','true'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.showSiteMenu','true'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.showUnpermittedFiles','false'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.showUnpermittedVolumes','false'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.sources','\"*\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.targetSiteId','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.validateRelatedElements','false'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.settings.viewMode','\"list-inline\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.translationKeyFormat','null'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.translationMethod','\"none\"'),('fields.fe417a71-4d1b-460f-8a63-7ac81c0e5092.type','\"craft\\\\fields\\\\Assets\"'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.handle','\"splash\"'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.name','\"Splash\"'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.outputCssLayout','false'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.outputCssLocation','\"page-header\"'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.outputCssTheme','true'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.outputJsBase','false'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.outputJsLocation','\"page-footer\"'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.outputJsTheme','true'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.sortOrder','1'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.template','\"_forms/splash\"'),('formie.formTemplates.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee.useCustomTemplates','true'),('formie.statuses.1f048049-d0c9-4364-8a8d-736b4d508537.color','\"yellow\"'),('formie.statuses.1f048049-d0c9-4364-8a8d-736b4d508537.description','\"\"'),('formie.statuses.1f048049-d0c9-4364-8a8d-736b4d508537.handle','\"pending\"'),('formie.statuses.1f048049-d0c9-4364-8a8d-736b4d508537.isDefault','true'),('formie.statuses.1f048049-d0c9-4364-8a8d-736b4d508537.name','\"Pending\"'),('formie.statuses.1f048049-d0c9-4364-8a8d-736b4d508537.sortOrder','null'),('formie.statuses.acef0518-5cc6-4dd0-9231-234846cfc200.color','\"green\"'),('formie.statuses.acef0518-5cc6-4dd0-9231-234846cfc200.description','\"\"'),('formie.statuses.acef0518-5cc6-4dd0-9231-234846cfc200.handle','\"approved\"'),('formie.statuses.acef0518-5cc6-4dd0-9231-234846cfc200.isDefault','false'),('formie.statuses.acef0518-5cc6-4dd0-9231-234846cfc200.name','\"Approved\"'),('formie.statuses.acef0518-5cc6-4dd0-9231-234846cfc200.sortOrder','null'),('formie.statuses.ddb17090-e3f7-41d7-aab7-b1729da37d11.color','\"blue\"'),('formie.statuses.ddb17090-e3f7-41d7-aab7-b1729da37d11.description','\"\"'),('formie.statuses.ddb17090-e3f7-41d7-aab7-b1729da37d11.handle','\"subscriber\"'),('formie.statuses.ddb17090-e3f7-41d7-aab7-b1729da37d11.isDefault','false'),('formie.statuses.ddb17090-e3f7-41d7-aab7-b1729da37d11.name','\"Subscriber\"'),('formie.statuses.ddb17090-e3f7-41d7-aab7-b1729da37d11.sortOrder','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.dataRetention','\"forever\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.dataRetentionValue','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.fileUploadsAction','\"retain\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.collectIp','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.collectUser','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.dataRetention','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.dataRetentionValue','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.defaultEmailTemplateId','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.defaultInstructionsPosition','\"verbb\\\\formie\\\\positions\\\\AboveInput\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.defaultLabelPosition','\"verbb\\\\formie\\\\positions\\\\AboveInput\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.disableCaptchas','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.displayCurrentPageTitle','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.displayFormTitle','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.displayPageProgress','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.displayPageTabs','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.errorMessage.0.content.0.text','\"Couldn’t save submission due to errors.\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.errorMessage.0.content.0.type','\"text\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.errorMessage.0.type','\"paragraph\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.errorMessagePosition','\"top-form\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.fileUploadsAction','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.limitSubmissions','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.limitSubmissionsIpAddressMessage','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.limitSubmissionsIpAddressNumber','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.limitSubmissionsIpAddressType','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.limitSubmissionsMessage','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.limitSubmissionsNumber','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.limitSubmissionsType','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.loadingIndicator','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.loadingIndicatorText','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.pageRedirectUrl','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.progressPosition','\"end\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.progressValuePosition','\"inside-center\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.redirectUrl','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.requiredIndicator','\"asterisk\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.requireUser','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.requireUserMessage','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.scheduleForm','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.scheduleFormEnd','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.scheduleFormExpiredMessage','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.scheduleFormPendingMessage','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.scheduleFormStart','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.scrollToTop','true'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submissionTitleFormat','\"{timestamp}\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitAction','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitActionFormHide','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitActionMessage.0.content.0.text','\"Submission saved.\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitActionMessage.0.content.0.type','\"text\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitActionMessage.0.type','\"paragraph\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitActionMessagePosition','\"top-form\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitActionMessageTimeout','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitActionTab','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitActionUrl','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.submitMethod','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.validationOnFocus','false'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.settings.validationOnSubmit','true'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.data.userDeletedAction','\"retain\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.defaultStatus','\"1f048049-d0c9-4364-8a8d-736b4d508537\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.handle','\"contactForm\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.name','\"Contact Form\"'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.submitActionEntry','null'),('formie.stencils.d7cbe0ad-28b6-4a03-ace9-d634d2072400.template','null'),('fs.assets.hasUrls','true'),('fs.assets.name','\"Assets\"'),('fs.assets.settings.path','\"$CRAFT_WEB_ROOT/uploads\"'),('fs.assets.type','\"craft\\\\fs\\\\Local\"'),('fs.assets.url','\"$PRIMARY_SITE_URL/uploads\"'),('graphql.schemas.3220f3b5-89ff-450e-9a8c-83bd4b04bdf5.isPublic','true'),('graphql.schemas.3220f3b5-89ff-450e-9a8c-83bd4b04bdf5.name','\"Public Schema\"'),('meta.__names__.0e198a9f-3b1b-487f-80ee-3c2aeed6d349','\"DBT Search\"'),('meta.__names__.1f048049-d0c9-4364-8a8d-736b4d508537','\"Pending\"'),('meta.__names__.288c542e-3541-4e24-96ee-aa5fa0bea135','\"General\"'),('meta.__names__.3220f3b5-89ff-450e-9a8c-83bd4b04bdf5','\"Public Schema\"'),('meta.__names__.68f6aaed-7edc-4e91-9996-3a86c16baf2f','\"Basic Editor\"'),('meta.__names__.98fab9df-c419-4085-9a57-5c61f96573c2','\"Form\"'),('meta.__names__.acef0518-5cc6-4dd0-9231-234846cfc200','\"Approved\"'),('meta.__names__.bcf50025-2188-4126-a360-29999caeae89','\"Splash Page\"'),('meta.__names__.cc0c373f-6532-483b-831f-3c8878b9bb8e','\"DBT Search\"'),('meta.__names__.d7cbe0ad-28b6-4a03-ace9-d634d2072400','\"Contact Form\"'),('meta.__names__.ddb17090-e3f7-41d7-aab7-b1729da37d11','\"Subscriber\"'),('meta.__names__.ddb25fd5-a759-494a-9d4d-96a6e44c941e','\"Plain Text\"'),('meta.__names__.e37b7064-6cc1-44c5-a156-52caa30e8b65','\"Splash Page\"'),('meta.__names__.eb8a7a70-63cb-4cc1-bae4-e3516a6766ee','\"Splash\"'),('meta.__names__.fe417a71-4d1b-460f-8a63-7ac81c0e5092','\"Images\"'),('plugins.ckeditor.edition','\"standard\"'),('plugins.ckeditor.enabled','true'),('plugins.ckeditor.schemaVersion','\"5.0.0.1\"'),('plugins.formie.edition','\"standard\"'),('plugins.formie.enabled','true'),('plugins.formie.licenseKey','\"QUKB6ZEKL37AO89B4TEAAZKZ\"'),('plugins.formie.schemaVersion','\"3.4.12\"'),('plugins.formie.settings.ajaxTimeout','10'),('plugins.formie.settings.alertEmails.0.0','\"Brian Larson\"'),('plugins.formie.settings.alertEmails.0.1','\"brian@brianlarson.com\"'),('plugins.formie.settings.allowPublicVolumes','true'),('plugins.formie.settings.defaultDateDisplayType','\"calendar\"'),('plugins.formie.settings.defaultDateTime','null'),('plugins.formie.settings.defaultDateValueOption','\"\"'),('plugins.formie.settings.defaultEmailTemplate','\"\"'),('plugins.formie.settings.defaultExportFolder','\"@storage/formie-export\"'),('plugins.formie.settings.defaultFileUploadVolume','\"\"'),('plugins.formie.settings.defaultFormTemplate','\"\"'),('plugins.formie.settings.defaultInstructionsPosition','\"verbb\\\\formie\\\\positions\\\\AboveInput\"'),('plugins.formie.settings.defaultLabelPosition','\"verbb\\\\formie\\\\positions\\\\AboveInput\"'),('plugins.formie.settings.defaultPage','\"forms\"'),('plugins.formie.settings.emptyValuePlaceholder','\"No response.\"'),('plugins.formie.settings.enableBackSubmission','true'),('plugins.formie.settings.enableCsrfValidationForGuests','true'),('plugins.formie.settings.enableLargeFieldStorage','false'),('plugins.formie.settings.enableUnloadWarning','true'),('plugins.formie.settings.filterIntegrationMapping','true'),('plugins.formie.settings.includeDraftElementUsage','false'),('plugins.formie.settings.includeRevisionElementUsage','false'),('plugins.formie.settings.maxIncompleteSubmissionAge','30'),('plugins.formie.settings.maxSentNotificationsAge','30'),('plugins.formie.settings.outputConsoleMessages','true'),('plugins.formie.settings.pdfPaperOrientation','\"portrait\"'),('plugins.formie.settings.pdfPaperSize','\"letter\"'),('plugins.formie.settings.pluginName','\"Forms\"'),('plugins.formie.settings.queuePriority','null'),('plugins.formie.settings.saveSpam','true'),('plugins.formie.settings.sendEmailAlerts','true'),('plugins.formie.settings.sentNotifications','true'),('plugins.formie.settings.setOnlyCurrentPagePayload','false'),('plugins.formie.settings.spamBehaviour','\"showSuccess\"'),('plugins.formie.settings.spamBehaviourMessage','\"\"'),('plugins.formie.settings.spamEmailNotifications','true'),('plugins.formie.settings.spamKeywords','\"\"'),('plugins.formie.settings.spamLimit','500'),('plugins.formie.settings.submissionsBehaviour','\"all\"'),('plugins.formie.settings.useCssLayers','false'),('plugins.formie.settings.useQueueForIntegrations','true'),('plugins.formie.settings.useQueueForNotifications','true'),('plugins.formie.settings.validateCustomTemplates','true'),('plugins.resend.edition','\"standard\"'),('plugins.resend.enabled','true'),('plugins.resend.schemaVersion','\"1.0.0\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.defaultPlacement','\"end\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.enableVersioning','true'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.entryTypes.0.uid','\"bcf50025-2188-4126-a360-29999caeae89\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.handle','\"splashPage\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.maxAuthors','1'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.name','\"Splash Page\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.previewTargets.0.label','\"Primary entry page\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.previewTargets.0.refresh','\"1\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.previewTargets.0.urlFormat','\"{url}\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.propagationMethod','\"all\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.siteSettings.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.enabledByDefault','true'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.siteSettings.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.hasUrls','true'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.siteSettings.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.template','\"splash/index.twig\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.siteSettings.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.uriFormat','\"__home__\"'),('sections.e37b7064-6cc1-44c5-a156-52caa30e8b65.type','\"single\"'),('siteGroups.cc0c373f-6532-483b-831f-3c8878b9bb8e.name','\"DBT Search\"'),('sites.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.handle','\"default\"'),('sites.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.hasUrls','true'),('sites.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.language','\"en\"'),('sites.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.name','\"DBT Search\"'),('sites.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.primary','true'),('sites.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.siteGroup','\"cc0c373f-6532-483b-831f-3c8878b9bb8e\"'),('sites.0e198a9f-3b1b-487f-80ee-3c2aeed6d349.sortOrder','1'),('system.edition','\"team\"'),('system.live','true'),('system.name','\"DBT Search\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.9.0.8\"'),('system.timeZone','\"America/Chicago\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.altTranslationKeyFormat','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.altTranslationMethod','\"none\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.cardThumbAlignment','\"end\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elementCondition','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.autocapitalize','true'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.autocomplete','false'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.autocorrect','true'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.class','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.dateAdded','\"2026-03-15T18:57:47+00:00\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.disabled','false'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.elementCondition','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.id','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.inputType','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.instructions','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.label','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.max','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.min','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.name','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.orientation','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.placeholder','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.readonly','false'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.requirable','false'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.size','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.step','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.tip','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.title','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.uid','\"868219d9-9165-4ff0-8c75-f5aeb10958b6\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.userCondition','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.warning','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.0.width','100'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.1.dateAdded','\"2026-03-15T18:59:33+00:00\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.1.elementCondition','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\HorizontalRule\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.1.uid','\"eff7f937-547e-4260-b98f-876b9249331f\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.1.userCondition','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.attribute','\"alt\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.class','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.cols','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.dateAdded','\"2026-03-15T18:59:33+00:00\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.disabled','false'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.elementCondition','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.id','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.instructions','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.label','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.name','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.orientation','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.placeholder','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.readonly','false'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.requirable','true'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.required','false'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.rows','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.tip','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.title','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.uid','\"f1acb816-b913-4e71-b62c-234bb5ff91a3\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.userCondition','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.warning','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.elements.2.width','100'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.name','\"Content\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.uid','\"3c724645-9610-47df-9d65-56cb854bddb6\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.tabs.0.userCondition','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fieldLayouts.bec1e434-aec3-4db5-945f-598e2e1154c2.thumbFieldKey','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.fs','\"assets\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.handle','\"general\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.name','\"General\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.sortOrder','1'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.subpath','\"\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.titleTranslationKeyFormat','null'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.titleTranslationMethod','\"site\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.transformFs','\"assets\"'),('volumes.288c542e-3541-4e24-96ee-aa5fa0bea135.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (3,3,4,NULL,10,1,'2026-03-15 19:08:24','2026-03-15 19:08:24','e2bb7247-ae78-48d4-8203-dfd48bdf956b'),(4,3,4,NULL,9,2,'2026-03-15 19:08:24','2026-03-15 19:08:24','421962dd-330c-4d92-ae0b-904df6c1aa10'),(5,3,14,NULL,10,1,'2026-03-15 19:08:24','2026-03-15 19:08:24','f0d59753-e34d-438b-be23-51ed453ccf96'),(6,3,14,NULL,9,2,'2026-03-15 19:08:24','2026-03-15 19:08:24','12f73b2f-030d-4ccc-8183-649fb444cbb6'),(7,3,15,NULL,10,1,'2026-03-15 19:09:09','2026-03-15 19:09:09','6246c7d4-bac7-4bd9-b066-95213293c051'),(8,3,15,NULL,9,2,'2026-03-15 19:09:09','2026-03-15 19:09:09','43789c7c-e2e2-44c4-86be-b04f53fed90e'),(9,3,16,NULL,10,1,'2026-03-15 19:09:37','2026-03-15 19:09:37','4822762c-dab2-4adb-8a63-9ae8ffc2afa5'),(10,3,16,NULL,9,2,'2026-03-15 19:09:37','2026-03-15 19:09:37','b609f5b2-5da5-4946-aebc-e97d174ba20d'),(13,3,18,NULL,10,1,'2026-03-15 19:10:13','2026-03-15 19:10:13','44c0a575-2638-4745-945a-0ca323681f65'),(14,3,18,NULL,9,2,'2026-03-15 19:10:13','2026-03-15 19:10:13','17a36c19-69c7-42c1-afdb-06d023ea7193'),(15,3,19,NULL,10,1,'2026-03-15 19:10:25','2026-03-15 19:10:25','96cf326f-47f9-4da0-9cea-4bcc2d562702'),(16,3,19,NULL,9,2,'2026-03-15 19:10:25','2026-03-15 19:10:25','7f3323d9-76bf-4847-855a-be3b3742b976'),(20,2,4,NULL,3,1,'2026-03-15 19:10:32','2026-03-15 19:10:32','9d106b17-dc2d-4eac-b427-b09b28252461'),(21,3,21,NULL,10,1,'2026-03-15 19:10:32','2026-03-15 19:10:32','ed26058a-bd83-4586-b6c9-77dc31a581b6'),(22,3,21,NULL,9,2,'2026-03-15 19:10:32','2026-03-15 19:10:32','6758aaa8-4306-4312-b75d-84b4b94a1430'),(23,2,21,NULL,3,1,'2026-03-15 19:10:32','2026-03-15 19:10:32','219d5bab-4a29-4c6b-9919-c3264f86bf99'),(24,3,22,NULL,10,1,'2026-03-15 19:11:37','2026-03-15 19:11:37','f5049596-4ef6-426f-b489-7dd46c667790'),(25,3,22,NULL,9,2,'2026-03-15 19:11:37','2026-03-15 19:11:37','8de27fd9-351f-4db3-844d-868c86b5160d'),(26,2,22,NULL,3,1,'2026-03-15 19:11:37','2026-03-15 19:11:37','b721aa79-889c-4608-836e-45b853421dc2'),(27,3,23,NULL,10,1,'2026-03-15 19:12:41','2026-03-15 19:12:41','f3d65d0e-8744-4538-8ea5-54e3c80ea345'),(28,3,23,NULL,9,2,'2026-03-15 19:12:41','2026-03-15 19:12:41','6a6220d3-9d82-4bd1-b4a8-232919e521ec'),(29,2,23,NULL,3,1,'2026-03-15 19:12:41','2026-03-15 19:12:41','7ce47b33-cb06-4edb-9be7-c00129d7392f'),(30,3,30,NULL,10,1,'2026-03-17 03:59:14','2026-03-17 03:59:14','e74dbd39-71d4-42d2-a118-6a6fdb13c447'),(31,3,30,NULL,9,2,'2026-03-17 03:59:14','2026-03-17 03:59:14','a2cd4a7c-b33e-4d8d-abb6-7e2445e60dc8'),(32,2,30,NULL,3,1,'2026-03-17 03:59:14','2026-03-17 03:59:14','487130de-fc20-421f-9fe5-0befae5f8dad'),(33,3,31,NULL,10,1,'2026-03-17 04:06:52','2026-03-17 04:06:52','f847dba1-3e32-47a8-ae50-be5f434f45a5'),(34,3,31,NULL,9,2,'2026-03-17 04:06:52','2026-03-17 04:06:52','454ee082-df72-4d4e-beb1-c1ff7a71c72a'),(35,2,31,NULL,3,1,'2026-03-17 04:06:52','2026-03-17 04:06:52','9901b9f1-be0a-431b-9319-928fb7407380'),(39,3,33,NULL,10,1,'2026-03-17 04:07:23','2026-03-17 04:07:23','2112901c-5b10-4032-a118-daa7641aece3'),(40,3,33,NULL,9,2,'2026-03-17 04:07:23','2026-03-17 04:07:23','e81b9aca-cf73-4202-aa11-e992b6ba5f77'),(41,2,33,NULL,3,1,'2026-03-17 04:07:23','2026-03-17 04:07:23','0834b814-35c5-482c-95d0-1885e5459663'),(45,2,35,NULL,3,1,'2026-03-17 04:11:47','2026-03-17 04:11:47','1c8204f8-6cb8-4ab0-9462-c3c2610fcca4'),(46,3,35,NULL,10,1,'2026-03-17 04:11:47','2026-03-17 04:11:47','94b0f4e7-80e7-4e23-a0a8-8a136e2e73e7'),(47,3,35,NULL,9,2,'2026-03-17 04:11:47','2026-03-17 04:11:47','baeb4866-67b0-4633-a0a3-e9a9fce059cc'),(51,2,64,NULL,3,1,'2026-03-17 06:01:13','2026-03-17 06:01:13','9f86da26-ba93-4e89-b1be-350bf509c1ae'),(52,3,64,NULL,10,1,'2026-03-17 06:01:13','2026-03-17 06:01:13','30d7f699-ece6-475b-9f46-b025fdff23e9'),(53,3,64,NULL,9,2,'2026-03-17 06:01:13','2026-03-17 06:01:13','2c8e5911-fdc8-4ae0-8370-2a34b9115f1c'),(54,2,65,NULL,3,1,'2026-03-17 06:02:19','2026-03-17 06:02:19','8c64f17e-5a32-4f4b-982b-d6832339a598'),(55,3,65,NULL,10,1,'2026-03-17 06:02:19','2026-03-17 06:02:19','efcb8b30-9116-4781-9f81-9bcfb297e8e5'),(56,3,65,NULL,9,2,'2026-03-17 06:02:19','2026-03-17 06:02:19','fb673527-87da-477a-9e1d-16c981a8a1f0'),(57,2,66,NULL,3,1,'2026-03-17 06:03:00','2026-03-17 06:03:00','8bf9fb47-aac6-4653-abc3-c6e1e50270c8'),(58,3,66,NULL,10,1,'2026-03-17 06:03:00','2026-03-17 06:03:00','de3181a2-2dfb-4fde-aa6d-ef2dbbb32916'),(59,3,66,NULL,9,2,'2026-03-17 06:03:00','2026-03-17 06:03:00','50c1d1f4-467e-4438-b664-f9de9f8d7696'),(60,2,67,NULL,3,1,'2026-03-17 06:03:04','2026-03-17 06:03:04','d5742102-35b2-4c00-bad5-f7cced5228d1'),(61,3,67,NULL,10,1,'2026-03-17 06:03:04','2026-03-17 06:03:04','a285aa91-330a-4b1a-b950-7522dc730d87'),(62,3,67,NULL,9,2,'2026-03-17 06:03:04','2026-03-17 06:03:04','c539593f-cfb5-4ff8-91e2-f0e232babe1e'),(63,2,68,NULL,3,1,'2026-03-17 06:03:09','2026-03-17 06:03:09','02e2839a-fcad-4f90-b257-3da8c9d82208'),(64,3,68,NULL,10,1,'2026-03-17 06:03:09','2026-03-17 06:03:09','7a74734f-de33-49d5-898e-922d773bc053'),(65,3,68,NULL,9,2,'2026-03-17 06:03:09','2026-03-17 06:03:09','f1cbf491-7b8e-4ab6-8487-cb57cee3f7c9'),(66,2,69,NULL,3,1,'2026-03-17 06:03:51','2026-03-17 06:03:51','8d1468dc-bb14-4ed5-b964-bcbc6a4f2da1'),(67,3,69,NULL,10,1,'2026-03-17 06:03:51','2026-03-17 06:03:51','82f35a0d-865b-48fb-8ccb-f9fb64b94d0b'),(68,3,69,NULL,9,2,'2026-03-17 06:03:51','2026-03-17 06:03:51','52002349-f158-4903-8a29-8675ba01f648'),(72,2,71,NULL,3,1,'2026-03-17 14:06:41','2026-03-17 14:06:41','a813de71-9418-40e3-9612-1cacef2aae2e'),(73,3,71,NULL,10,1,'2026-03-17 14:06:41','2026-03-17 14:06:41','2ccb7ce3-c097-480f-84e7-27451b761169'),(74,3,71,NULL,9,2,'2026-03-17 14:06:41','2026-03-17 14:06:41','9966d05d-2c63-46b4-b8dc-46168d3284b0');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,4,1,1,NULL),(2,4,1,2,''),(3,4,1,3,''),(4,4,1,4,''),(5,4,1,5,''),(6,4,1,6,'Applied “Draft 1”'),(7,4,1,7,''),(8,4,1,8,''),(9,4,1,9,'Applied “Draft 1”'),(10,4,1,10,''),(11,4,1,11,'Applied “Draft 1”'),(12,4,1,12,''),(13,4,1,13,''),(14,4,1,14,''),(15,4,1,15,''),(16,4,1,16,'Applied “Draft 1”'),(17,4,1,17,'Applied “Draft 1”'),(18,4,1,18,'Applied “Draft 1”'),(19,4,1,19,NULL),(20,4,1,20,NULL),(21,4,1,21,NULL),(22,4,1,22,NULL),(23,4,1,23,NULL),(24,4,1,24,'Applied “Draft 1”');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' brian brianlarson com '),(1,'firstname',0,1,' brian '),(1,'fullname',0,1,' brian larson '),(1,'lastname',0,1,' larson '),(1,'slug',0,1,''),(1,'username',0,1,' brianlarson '),(2,'email',0,1,' support tinytreecounseling com '),(2,'firstname',0,1,' mary '),(2,'fullname',0,1,' mary souder '),(2,'lastname',0,1,' souder '),(2,'slug',0,1,''),(2,'username',0,1,' marysouder '),(3,'handle',0,1,' splashsignup '),(3,'slug',0,1,''),(3,'title',0,1,' launch sign up '),(4,'slug',0,1,' home '),(4,'title',0,1,' splash page '),(8,'alt',0,1,' abstract painting texture '),(8,'extension',0,1,' jpg '),(8,'filename',0,1,' pexels steve 1690351 jpg '),(8,'kind',0,1,' image '),(8,'slug',0,1,''),(8,'title',0,1,' abstract 01 '),(9,'alt',0,1,''),(9,'extension',0,1,' jpg '),(9,'filename',0,1,' denys nevozhai z0nvqfroqwa unsplash jpg '),(9,'kind',0,1,' image '),(9,'slug',0,1,''),(9,'title',0,1,' denys nevozhai z0n vqfr oq wa unsplash '),(10,'alt',0,1,''),(10,'extension',0,1,' jpg '),(10,'filename',0,1,' pexels steve 1690351 jpg '),(10,'kind',0,1,' image '),(10,'slug',0,1,''),(10,'title',0,1,' pexels steve 1690351 '),(24,'field:5',0,1,' mary souder '),(24,'field:6',0,1,' souder mary gmail com '),(24,'field:8',0,1,' tiny tree counseling consulting '),(24,'field:9',0,1,' yes '),(24,'title',0,1,' 2026 03 15 13 08 55 '),(25,'slug',0,1,''),(25,'subject',0,1,' a new submission was made on launch sign up '),(25,'to',0,1,' support tinytreecounseling com '),(26,'slug',0,1,''),(26,'subject',0,1,''),(26,'to',0,1,''),(27,'slug',0,1,''),(27,'subject',0,1,' a new submission was made on launch sign up '),(27,'to',0,1,' support tinytreecounseling com '),(28,'slug',0,1,''),(28,'subject',0,1,''),(28,'to',0,1,''),(29,'field:5',0,1,' brian larson '),(29,'field:6',0,1,' blarson mightycitizen com '),(29,'field:8',0,1,' mighty citizen '),(29,'field:9',0,1,' no '),(29,'title',0,1,' 2026 03 15 13 18 40 '),(36,'alt',0,1,''),(36,'extension',0,1,' png '),(36,'filename',0,1,' dbtsearch icon png '),(36,'kind',0,1,' image '),(36,'slug',0,1,''),(36,'title',0,1,' dbtsearch icon '),(37,'alt',0,1,''),(37,'extension',0,1,' svg '),(37,'filename',0,1,' dbtsearch logo svg '),(37,'kind',0,1,' image '),(37,'slug',0,1,''),(37,'title',0,1,' dbtsearch logo '),(38,'alt',0,1,''),(38,'extension',0,1,' webp '),(38,'filename',0,1,' acp associated clinic webp '),(38,'kind',0,1,' image '),(38,'slug',0,1,''),(38,'title',0,1,' acp associated clinic '),(39,'alt',0,1,''),(39,'extension',0,1,' png '),(39,'filename',0,1,' advanded behavioral health inc png '),(39,'kind',0,1,' image '),(39,'slug',0,1,''),(39,'title',0,1,' advanded behavioral health inc '),(40,'alt',0,1,''),(40,'extension',0,1,' jpg '),(40,'filename',0,1,' align your soul jpg '),(40,'kind',0,1,' image '),(40,'slug',0,1,''),(40,'title',0,1,' align your soul '),(41,'alt',0,1,''),(41,'extension',0,1,' jpg '),(41,'filename',0,1,' art of validation and change jpg '),(41,'kind',0,1,' image '),(41,'slug',0,1,''),(41,'title',0,1,' art of validation and change '),(42,'alt',0,1,''),(42,'extension',0,1,' webp '),(42,'filename',0,1,' asc psychological services webp '),(42,'kind',0,1,' image '),(42,'slug',0,1,''),(42,'title',0,1,' asc psychological services '),(43,'alt',0,1,''),(43,'extension',0,1,' jpg '),(43,'filename',0,1,' autonomy couseling jpg '),(43,'kind',0,1,' image '),(43,'slug',0,1,''),(43,'title',0,1,' autonomy couseling '),(44,'alt',0,1,''),(44,'extension',0,1,' png '),(44,'filename',0,1,' choices psychotherapy png '),(44,'kind',0,1,' image '),(44,'slug',0,1,''),(44,'title',0,1,' choices psychotherapy '),(45,'alt',0,1,''),(45,'extension',0,1,' png '),(45,'filename',0,1,' dbt associates llp png '),(45,'kind',0,1,' image '),(45,'slug',0,1,''),(45,'title',0,1,' dbt associates llp '),(46,'alt',0,1,''),(46,'extension',0,1,' svg '),(46,'filename',0,1,' meridian behavioral health svg '),(46,'kind',0,1,' image '),(46,'slug',0,1,''),(46,'title',0,1,' meridian behavioral health '),(47,'alt',0,1,''),(47,'extension',0,1,' png '),(47,'filename',0,1,' tiny tree counseling png '),(47,'kind',0,1,' image '),(47,'slug',0,1,''),(47,'title',0,1,' tiny tree counseling '),(48,'alt',0,1,''),(48,'extension',0,1,' svg '),(48,'filename',0,1,' volunteers of america mn wi svg '),(48,'kind',0,1,' image '),(48,'slug',0,1,''),(48,'title',0,1,' volunteers of america mn wi '),(49,'field:5',0,1,' brian larson '),(49,'field:6',0,1,' blarson mightycitizen com '),(49,'field:8',0,1,' mighty citizen '),(49,'field:9',0,1,' yes '),(49,'title',0,1,' 2026 03 16 21 28 44 '),(50,'field:5',0,1,' brian '),(50,'field:6',0,1,' brian brianlarson com '),(50,'field:8',0,1,''),(50,'field:9',0,1,' no '),(50,'title',0,1,' 2026 03 16 21 28 54 '),(51,'field:5',0,1,' brian larson '),(51,'field:6',0,1,' brian brianlarson com '),(51,'field:8',0,1,' mighty citizen '),(51,'field:9',0,1,' yes '),(51,'title',0,1,' brian larson '),(52,'field:5',0,1,' brian larson '),(52,'field:6',0,1,' brian brianlarson com '),(52,'field:8',0,1,''),(52,'field:9',0,1,' no '),(52,'title',0,1,' brian larson '),(53,'field:5',0,1,' brian larson '),(53,'field:6',0,1,' blarson26 gmail com '),(53,'field:8',0,1,''),(53,'field:9',0,1,' no '),(53,'title',0,1,' brian larson '),(54,'field:5',0,1,' brian larson '),(54,'field:6',0,1,' brian brianlarson com '),(54,'field:8',0,1,''),(54,'field:9',0,1,' no '),(54,'title',0,1,' brian larson '),(55,'field:5',0,1,' brian larson '),(55,'field:6',0,1,' brian brianlarson com '),(55,'field:8',0,1,''),(55,'field:9',0,1,' yes '),(55,'title',0,1,' brian larson '),(56,'field:5',0,1,' brian larson '),(56,'field:6',0,1,' blarson mightycitizen com '),(56,'field:8',0,1,' mighty citizen '),(56,'field:9',0,1,' yes '),(56,'title',0,1,' brian larson '),(57,'slug',0,1,''),(57,'subject',0,1,' a new submission was made on launch sign up '),(57,'to',0,1,' support tinytreecounseling com '),(58,'slug',0,1,''),(58,'subject',0,1,''),(58,'to',0,1,''),(59,'slug',0,1,''),(59,'subject',0,1,' a new submission was made on launch sign up '),(59,'to',0,1,' support tinytreecounseling com '),(60,'slug',0,1,''),(60,'subject',0,1,''),(60,'to',0,1,''),(61,'slug',0,1,''),(61,'subject',0,1,''),(61,'to',0,1,''),(62,'slug',0,1,''),(62,'subject',0,1,''),(62,'to',0,1,''),(72,'field:5',0,1,' mary souder '),(72,'field:6',0,1,' support tinytreecounseling com '),(72,'field:8',0,1,' tiny tree '),(72,'field:9',0,1,' yes '),(72,'title',0,1,' mary souder '),(73,'slug',0,1,''),(73,'subject',0,1,' a new submission was made on launch sign up '),(73,'to',0,1,' support tinytreecounseling com '),(74,'slug',0,1,''),(74,'subject',0,1,''),(74,'to',0,1,''),(75,'field:5',0,1,' brian larson '),(75,'field:6',0,1,' blarson mightycitizen com '),(75,'field:8',0,1,' mighty citizen '),(75,'field:9',0,1,' yes '),(75,'title',0,1,' brian larson '),(76,'slug',0,1,''),(76,'subject',0,1,' a new submission was made on launch sign up '),(76,'to',0,1,' support tinytreecounseling com '),(77,'slug',0,1,''),(77,'subject',0,1,''),(77,'to',0,1,''),(78,'field:5',0,1,' mary souder '),(78,'field:6',0,1,' support tinytreecounseling com '),(78,'field:8',0,1,' tiny tree counseling '),(78,'field:9',0,1,' yes '),(78,'title',0,1,' mary souder '),(79,'slug',0,1,''),(79,'subject',0,1,' a new submission was made on launch sign up '),(79,'to',0,1,' support tinytreecounseling com '),(80,'slug',0,1,''),(80,'subject',0,1,''),(80,'to',0,1,''),(81,'field:5',0,1,' madeline asp '),(81,'field:6',0,1,' masp mhs dbt com '),(81,'field:8',0,1,' mental health systems '),(81,'field:9',0,1,' yes '),(81,'title',0,1,' madeline asp '),(82,'field:5',0,1,' caila kritzeck '),(82,'field:6',0,1,' caila artofcounselingstpaul com '),(82,'field:8',0,1,' art of counseling '),(82,'field:9',0,1,' yes '),(82,'title',0,1,' caila kritzeck '),(83,'field:5',0,1,' jo ripplinger '),(83,'field:6',0,1,' joripplinger gmail com '),(83,'field:8',0,1,''),(83,'field:9',0,1,' yes '),(83,'title',0,1,' jo ripplinger '),(84,'field:5',0,1,' josh powell '),(84,'field:6',0,1,' josh powell voamn org '),(84,'field:8',0,1,' vona center for mental health voa '),(84,'field:9',0,1,' yes '),(84,'title',0,1,' josh powell '),(85,'field:5',0,1,' elizabeth carlton '),(85,'field:6',0,1,' ecarlton imsofmn com '),(85,'field:8',0,1,' ims '),(85,'field:9',0,1,' yes '),(85,'title',0,1,' elizabeth carlton '),(86,'field:5',0,1,' marsha werner '),(86,'field:6',0,1,' mwerner autonomypllc com '),(86,'field:8',0,1,' autonomy counseling pllc '),(86,'field:9',0,1,' yes '),(86,'title',0,1,' marsha werner '),(87,'field:5',0,1,' kate perry '),(87,'field:6',0,1,' kperry familyservicerochester org '),(87,'field:8',0,1,' family service rochester '),(87,'field:9',0,1,' yes '),(87,'title',0,1,' kate perry '),(88,'field:5',0,1,' haley raifsnider '),(88,'field:6',0,1,' haley securebasecounselingcenter com '),(88,'field:8',0,1,' secure base counseling center '),(88,'field:9',0,1,' yes '),(88,'title',0,1,' haley raifsnider '),(89,'field:5',0,1,' joyce koerner '),(89,'field:6',0,1,' jkoerner familyservicerochester org '),(89,'field:8',0,1,' family service rochester '),(89,'field:9',0,1,' yes '),(89,'title',0,1,' joyce koerner '),(90,'field:5',0,1,' jennifer goerger '),(90,'field:6',0,1,' jgoerger fernbrook org '),(90,'field:8',0,1,' fernbrook family center '),(90,'field:9',0,1,' yes '),(90,'title',0,1,' jennifer goerger '),(91,'field:5',0,1,' colleen starkey '),(91,'field:6',0,1,' colleen m starkey healthpartners org '),(91,'field:8',0,1,' health partners '),(91,'field:9',0,1,' no '),(91,'title',0,1,' colleen starkey '),(92,'field:5',0,1,' patty lauer roberts '),(92,'field:6',0,1,' patty lauer roberts radiashealth org '),(92,'field:8',0,1,' radias health '),(92,'field:9',0,1,' yes '),(92,'title',0,1,' patty lauer roberts '),(93,'field:5',0,1,' kristin bunge '),(93,'field:6',0,1,' kristin bunge tinytreecounseling com '),(93,'field:8',0,1,' tiny tree counseling '),(93,'field:9',0,1,' yes '),(93,'title',0,1,' kristin bunge '),(94,'field:5',0,1,' aneata test '),(94,'field:6',0,1,' sarah souder gmail com '),(94,'field:8',0,1,' this is cool '),(94,'field:9',0,1,' no '),(94,'title',0,1,' aneata test '),(95,'field:5',0,1,' stephanie wanous '),(95,'field:6',0,1,' stephaniew speromn org '),(95,'field:8',0,1,' spero '),(95,'field:9',0,1,' yes '),(95,'title',0,1,' stephanie wanous '),(96,'field:5',0,1,' beth bordenave '),(96,'field:6',0,1,' beth prcounselingmn com '),(96,'field:8',0,1,' phoenixrisen counseling '),(96,'field:9',0,1,' yes '),(96,'title',0,1,' beth bordenave ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindexqueue`
--

LOCK TABLES `searchindexqueue` WRITE;
/*!40000 ALTER TABLE `searchindexqueue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `searchindexqueue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindexqueue_fields`
--

LOCK TABLES `searchindexqueue_fields` WRITE;
/*!40000 ALTER TABLE `searchindexqueue_fields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `searchindexqueue_fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Splash Page','splashPage','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2026-03-15 18:54:27','2026-03-15 18:54:27',NULL,'e37b7064-6cc1-44c5-a156-52caa30e8b65');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES (1,1,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','splash/index.twig',1,'2026-03-15 18:54:27','2026-03-15 18:54:27','68396ae4-058c-4417-8c64-26dda59f8ab9');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'DBT Search','2026-03-14 15:44:21','2026-03-14 15:44:21',NULL,'cc0c373f-6532-483b-831f-3c8878b9bb8e');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'true','DBT Search','default','en',1,'$PRIMARY_SITE_URL',1,'2026-03-14 15:44:21','2026-03-14 15:44:21',NULL,'0e198a9f-3b1b-487f-80ee-3c2aeed6d349');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tokens` VALUES (1,'fciP-qFJMy3euRJuSNoP9btg2aS_u5RN','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":4,\"siteId\":1,\"draftId\":null,\"revisionId\":null,\"userId\":1}]',NULL,NULL,'2026-03-18 03:59:16','2026-03-17 03:59:16','2026-03-17 03:59:16','f3a9d6ed-963c-4d8f-bc5d-8355d97f7dd0'),(2,'rkGNqfvnaAiOTp_f2Aqiqh_pqCy-eZAN','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":4,\"siteId\":1,\"draftId\":null,\"revisionId\":null,\"userId\":1}]',NULL,NULL,'2026-03-18 04:09:57','2026-03-17 04:09:57','2026-03-17 04:09:57','1a9a5237-6c29-4c3c-903b-f89642859db8');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `usergroups` VALUES (1,'Team','team',NULL,'2026-04-08 15:17:49','2026-04-08 15:17:49','c55ca0a9-4bd6-409b-afd8-c1884dafecd0');
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpermissions` VALUES (1,'accesssitewhensystemisoff','2026-03-14 15:48:57','2026-03-14 15:48:57','52220aed-ce70-4315-bda1-3b596b2a4cd4'),(2,'accesscpwhensystemisoff','2026-03-14 15:48:57','2026-03-14 15:48:57','864c0e14-c196-4902-9a8d-8a525c009583'),(3,'performupdates','2026-03-14 15:48:57','2026-03-14 15:48:57','6f6b9f7e-9d81-4cda-a862-c7d911a2bb49'),(4,'accesscp','2026-03-14 15:48:57','2026-03-14 15:48:57','5235b9df-5ced-4411-a7ae-338b310991f0'),(5,'registerusers','2026-03-14 15:48:57','2026-03-14 15:48:57','3e785149-5dc4-4c32-9445-05bab0b1e51f'),(6,'moderateusers','2026-03-14 15:48:57','2026-03-14 15:48:57','7f9ec2bb-3e89-4075-a6bc-75950022f47d'),(7,'administrateusers','2026-03-14 15:48:57','2026-03-14 15:48:57','2e5635a0-42a5-4aa0-8411-c218376cd4be'),(8,'impersonateusers','2026-03-14 15:48:57','2026-03-14 15:48:57','46240bab-964c-4183-8ee5-705df9781083'),(9,'assignuserpermissions','2026-03-14 15:48:57','2026-03-14 15:48:57','8f8ccff3-015f-48c3-a01a-fc77e25c4c11'),(10,'editusers','2026-03-14 15:48:57','2026-03-14 15:48:57','1c36aac7-13b0-45fa-b23a-79ca5f8f4ae9'),(11,'deleteusers','2026-03-14 15:48:57','2026-03-14 15:48:57','1f3ef179-f1bd-4cc2-bfe3-12b07b70b823'),(12,'viewusers','2026-03-14 15:48:57','2026-03-14 15:48:57','d6c414f3-7750-4017-b334-ce3a984ae5af'),(13,'utility:system-report','2026-03-14 15:48:57','2026-03-14 15:48:57','bf197a31-0fa8-4cb1-b5ec-0473aaaa769c'),(14,'utility:php-info','2026-03-14 15:48:57','2026-03-14 15:48:57','c1d3b5e4-f9d0-4311-a8a1-52ecc2fbe9fd'),(15,'utility:system-messages','2026-03-14 15:48:57','2026-03-14 15:48:57','ef9a463b-e9cf-4ae6-a4ed-68d501f76d04'),(16,'utility:queue-manager','2026-03-14 15:48:57','2026-03-14 15:48:57','09a2e165-fa46-4046-8dbf-54303cffdee0'),(17,'utility:clear-caches','2026-03-14 15:48:57','2026-03-14 15:48:57','c74fbf49-3da3-4c14-bb6c-dfe03ac3e3fd'),(18,'utility:db-backup','2026-03-14 15:48:57','2026-03-14 15:48:57','7457ac51-51db-4ed4-b59b-dda880524df8'),(19,'utility:migrations','2026-03-14 15:48:57','2026-03-14 15:48:57','e9355494-adbc-4d90-963a-6e5d8999d7dc');
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpermissions_users` VALUES (1,1,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','17570e94-ec5f-4a4b-bf6e-39677a13c085'),(2,2,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','356ce593-2ba5-4a15-9870-8a41e5810f5d'),(3,3,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','343ede71-c4cc-4b02-ad2c-3076a5c19d1d'),(4,4,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','decca886-76d0-41f9-842b-be4c8026997d'),(5,5,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','4682dfa5-343b-46f1-bdff-b0200f899110'),(6,6,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','4a922ac0-6dbf-4a0d-928a-0a2be96971d7'),(7,7,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','a8f82df9-c238-4e22-a891-9d48f3824b62'),(8,8,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','a3c26698-bb4f-42e6-9bb9-24e448c8411a'),(9,9,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','dcd0497e-214a-43d0-a76d-3132dad5d887'),(10,10,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','0612eb8f-5fb9-4d30-8413-77a5b1bccafd'),(11,11,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','8e66d20a-31f7-4697-91bf-a4880e8fd9f7'),(12,12,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','6b4cec24-345f-4c2c-aedc-c1f06fd84a9b'),(13,13,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','7bcc32dc-aa19-4b11-87ce-ddd41384c6dd'),(14,14,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','07c3dea6-c5a0-4a9d-a051-bdcb34baad20'),(15,15,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','3084e3d0-656b-4b6c-9a5b-2e1c13eb37f0'),(16,16,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','b6e6a10c-393e-4e68-8042-f3dedbf830d8'),(17,17,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','041d29de-8f0c-4712-a123-6c362db6c973'),(18,18,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','ed1a3734-cfcc-485d-9ae3-3cfeaa41d4ce'),(19,19,2,'2026-03-14 15:48:57','2026-03-14 15:48:57','8b42ea04-ced7-4ac1-86a6-11b7cca61372');
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,NULL,1,0,0,0,1,'brianlarson','Brian Larson','Brian','Larson','brian@brianlarson.com','$2y$13$Gwh.j3SAsKYks/7i4K8Z9ei.zxh0TvGcKIP5vj/lOJER0uYFM07li','2026-04-24 16:11:04',NULL,NULL,NULL,'2026-04-06 17:09:58',NULL,1,NULL,NULL,NULL,0,'2026-04-06 17:15:21','2026-03-14 15:44:21','2026-04-24 16:11:04'),(2,NULL,NULL,0,0,0,0,0,'marysouder','Mary Souder','Mary','Souder','support@tinytreecounseling.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,'2026-03-14 15:47:59','2026-03-15 18:50:20');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,NULL,'Temporary Uploads',NULL,'2026-03-15 18:41:49','2026-03-15 18:41:49','1ff4de0b-da8a-488f-84c5-d276096e6038'),(2,1,NULL,'user_1','user_1/','2026-03-15 18:41:49','2026-03-15 18:41:49','335741db-9a5a-4d53-ab20-baeca54a3fa0'),(3,NULL,1,'General',NULL,'2026-03-15 18:59:33','2026-03-15 19:01:14','7a662dec-8f76-447f-9c8b-f6fa557c7245'),(6,3,1,'providers','providers/','2026-03-17 04:18:04','2026-03-17 04:18:04','8de18d51-0217-4b02-b70e-c21e024749ba'),(7,6,1,'logos','providers/logos/','2026-03-17 04:18:15','2026-03-17 04:18:15','4e09ddb1-0979-4cf3-8825-83e4617f625c');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,2,'General','general','assets','','assets','','site',NULL,'none',NULL,1,'2026-03-15 18:59:33','2026-03-15 19:01:14',NULL,'288c542e-3541-4e24-96ee-aa5fa0bea135');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `webauthn` VALUES (2,1,'KExJBkkh8LiIQdvOLkxxIvbYnL8','{\"publicKeyCredentialId\":\"KExJBkkh8LiIQdvOLkxxIvbYnL8\",\"type\":\"public-key\",\"transports\":[\"hybrid\",\"internal\"],\"attestationType\":\"none\",\"trustPath\":[],\"aaguid\":\"fbfc3007-154e-4ecc-8c0b-6e020557d7bd\",\"credentialPublicKey\":\"pQECAyYgASFYIF5RZAhQnbTWYOWdVcaPL464TXijPLNGa7jpZEQlXqUYIlgge3zyjTVdZ3mtE6Asj6mSOt_ktQ_Z38hAkfadflQeVVM\",\"userHandle\":\"TkdReE5URTJabVF0WlRZNE55MDBaV1UyTFRobE5Ea3RZVGMwTnpFeE5qTm1NMkU0\",\"counter\":0,\"backupEligible\":true,\"backupStatus\":true,\"uvInitialized\":true}','Chrome on Mac (prod)','2026-03-17 05:54:00','2026-03-17 05:54:00','2026-03-17 05:54:00','d818ecc5-0e5f-4812-9051-e414aac2964f');
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',2,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}','2026-03-14 15:44:40','2026-04-08 15:18:59','1ff61abe-62a4-48ea-b958-56a454cd6dbf'),(2,1,'craft\\widgets\\CraftSupport',3,NULL,'[]','2026-03-14 15:44:40','2026-04-08 15:18:59','157c3d77-7b7c-4880-b427-d7161cd2e17d'),(3,1,'craft\\widgets\\Updates',4,NULL,'[]','2026-03-14 15:44:40','2026-04-08 15:18:59','45f44ed9-c31d-4e89-a963-3539bd1ebc65'),(4,1,'craft\\widgets\\Feed',5,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}','2026-03-14 15:44:40','2026-04-08 15:18:59','1d61e8b0-0745-4448-a749-ed14e5f21da1'),(5,1,'verbb\\formie\\widgets\\RecentSubmissions',1,1,'{\"limit\": 99, \"title\": \"Recent Form Submissions\", \"endDate\": \"2026-04-08T00:15:17-05:00\", \"formIds\": \"*\", \"dateRange\": null, \"startDate\": \"2026-04-08T00:15:17-05:00\", \"displayType\": \"list\"}','2026-04-08 15:15:23','2026-04-08 15:19:16','ef64921f-6ffa-4ce2-bbf4-8fdc68fb4a55');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'dpvnkagjdf'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-24 17:36:23
