--
-- PostgreSQL database dump
--

\restrict qk7lCBpVd2rcLJsw5Y7MNMqJdgvULu1vcgUO1YlVmRGiRK9aqYqjppp7tI64kHS

-- Dumped from database version 14.22 (Debian 14.22-1.pgdg13+1)
-- Dumped by pg_dump version 14.22 (Debian 14.22-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: set_updated_at_to_now(); Type: FUNCTION; Schema: public; Owner: db
--

CREATE FUNCTION public.set_updated_at_to_now() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_updated_at_to_now() OWNER TO db;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: providers; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.providers (
    id integer NOT NULL,
    name character varying,
    dbta_certified boolean DEFAULT false,
    availability boolean DEFAULT false,
    address character varying,
    city character varying,
    state character varying,
    zip character varying,
    website character varying,
    image character varying,
    phone character varying,
    email character varying,
    dbt_certificate_expires timestamp with time zone,
    manager_id integer,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.providers OWNER TO db;

--
-- Name: providers_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.providers_id_seq OWNER TO db;

--
-- Name: providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.providers_id_seq OWNED BY public.providers.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO db;

--
-- Name: users; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    password character varying(1000) NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO db;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO db;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: providers id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.providers ALTER COLUMN id SET DEFAULT nextval('public.providers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.providers (id, name, dbta_certified, availability, address, city, state, zip, website, image, phone, email, dbt_certificate_expires, manager_id, inserted_at, updated_at) FROM stdin;
9	Autonomy Counseling	f	f	800 Holiday Dr Suite 170	Moorhead	MN	56560	https://www.autonomycounseling.com/	\N	218 293 4221	\N	2027-09-06 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
1	Addictions and Stress Clinic dba ASC Psychological Services	f	t	12 Civic Center Plaza #615	Mankato	MN	56001	https://www.ascpsychological.com/contact-us/	asc-psychological-services.webp	507-345-4679	\N	2024-08-23 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
2	Addictions and Stress Clinic dba ASC Psychological Services	f	t	2277 Highway 36 #150 & #155	Roseville	MN	55113	https://www.ascpsychological.com/contact-us/	asc-psychological-services.webp	507-345-4679	\N	2024-08-23 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
3	Advanced Behavioral Health, Inc	f	f	6160 Summit Dr N Ste 375	Brooklyn Center	MN	55430	http://www.abhtherapy.com/	advanded-behavioral-health-inc.png	763-560-8331	\N	2026-06-01 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
4	Align Your Soul Counseling Provider	t	f	Ironwood Square Building 300 3rd Ave Suite 302	Rochester	MN	55904	http://www.alignyoursoulcounseling.com/	\N	507-218-5913	\N	2026-06-26 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
5	Art of Counseling PLLC Provider	t	f	275 4th St East Suite 301	St Paul	MN	55101	https://artofcounselingstpaul.com/	\N	651-318-0109	\N	2026-12-01 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
6	Associated Clinic of Psychology (ACP DBT) Provider	t	t	4027 County Road 25	Minneapolis	MN	55416	http://acp-mn.com/	\N	612-925-6033	\N	2026-02-21 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
7	Associated Clinic of Psychology (ACP DBT) Provider	t	f	6950 W 146th St Suite 100	Apple Valley	MN	55124	http://acp-mn.com/	\N	952-432-1484	\N	2026-02-21 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
8	Associated Clinic of Psychology (ACP DBT) Provider	t	f	149 Thompson Ave E Suite 150W	St Paul	MN	55118	http://acp-mn.com/	\N	651-450-0860	\N	2026-02-11 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
10	Avalon St Anthony Park - Meridian Behavioral Health	f	f	1821 University Avenue West Suite N 385	St Paul	MN	55104	https://nbminnesota.com/	\N	612-326-7579	\N	2024-10-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
11	Choices Psychotherapy Ltd	f	f	10201 Wayzata Boulevard Suite 100	Minnetonka	MN	55305	https://choicespsychotherapy.net/services/dbt/	\N	952-544-6806	\N	2027-04-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
12	Choices Psychotherapy Ltd	f	f	7901 Xerxes Ave S Suite 225	Bloomington	MN	55431	https://choicespsychotherapy.net/services/dbt/	\N	952-544-6806	\N	2027-04-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
13	Choices Psychotherapy Ltd	f	f	7975 Stone Creek Dr Suite 130	Chanhassen	MN	55317	https://choicespsychotherapy.net/services/dbt/	\N	952-544-6806	\N	2027-04-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
14	DBT-PTSD & EMDR Specialist	f	f	10000 Hwy 55 Suite 300	Plymouth	MN	55441	https://dbt-ptsdspecialists.com/	\N	763-412-0722	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
15	DBT Associates Provider	t	f	7362 University Avenue Northeast Suite 101	Fridley	MN	55432	https://www.dbtassociates.com/	\N	763-503-3981	\N	2026-01-22 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
16	Elevacare dba Southwest Mental Health Clinic	f	t	1210 5th Avenue	Worthington	MN	56187	https://www.elevacare.org/	\N	507-376-4141	\N	2025-09-30 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
17	Family Services of Rochester Provider	t	t	4600 18th Avenue Northwest	Rochester	MN	55901	http://familyservicerochester.org/	\N	507-507-2010	\N	2026-04-14 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
18	Healing Connections Therapy Center	f	f	1751 Southcross Drive West	Burnsville	MN	55306	http://www.healingconnectionsonline.com/	\N	952-892-7690	\N	2026-06-01 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
19	Healthy Minds	f	f	400 Selby Ave Ste Q	St Paul	MN	55102	https://www.healthyminds.io/	\N	651-571-2865	\N	2025-02-05 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
20	HP Psychological Associates PC	f	f	4815 Burning Tree Road Ste 200	Duluth	MN	55811	http://www.hppsychological.com/	\N	218-464-0908	\N	2025-05-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
21	Imagine Mental Health Counseling	f	f	116 Ash Ave NW Suite 2	Wadena	MN	56482	https://imaginemhc.com/	\N	218-632-4300	\N	2025-01-18 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
22	Independent Management Services Provider	t	f	101 21st Street Suite 1	Austin	MN	55912	https://www.imsofmn.com/	\N	507-437-6389	\N	2026-05-14 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
23	Independent Management Services Provider	t	f	226 W Clark Street	Albert Lea	MN	56007	https://www.imsofmn.com/	\N	507-437-6389	\N	2026-05-14 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
24	Lakeland Mental Health Center	f	f	702 34th Avenue East	Alexandria	MN	56308	https://lmhc.org/	\N	320-762-2400	\N	2026-05-18 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
25	Life Development Resources PA Provider	t	f	7580 160th Street West	Lakeville	MN	55044	http://lifedrs.com/	\N	952-898-1133	\N	2026-07-18 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
26	Life Development Resources PA Provider	t	f	1619 Dayton Avenue	St Paul	MN	55104	http://lifedrs.com/	\N	952-898-1133	\N	2026-07-18 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
27	Lighthouse Child & Family Services LLC	f	f	160 3rd Avenue Northwest	Milaca	MN	56353	http://www.lighthousecfs.com/	\N	320-983-2335	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
28	MAP Behavioral Health Center	f	f	324 West Superior St Suite 260	Duluth	MN	55802	https://www.mapbhc.com/	\N	218 606-1797	\N	2024-09-01 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
29	The Meadows Counseling Center Provider	t	t	3737 40th Avenue Northwest	Rochester	MN	55901	http://www.highlandmeadowscc.com/	\N	507-288-6978	\N	2027-10-30 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
30	Mental Health Systems - Adherent Team Only	f	f	6600 France Avenue Suite 230	Edina	MN	55435	https://www.mhs-dbt.com/	\N	952-835-2002	\N	2026-10-04 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
31	Mental Health Systems - Adherent Team Only	f	f	6063 Hudson Road Suite 200	Woodbury	MN	55125	https://www.mhs-dbt.com/	\N	763-325-1686	\N	2026-10-04 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
32	Minnesota Center for Psychology LLC Provider	t	f	2324 University Avenue West Suite 120	St Paul	MN	55114	https://www.minnesotacenterforpsychology.com/dialectical-behavior-therapy	\N	651-644-4100	\N	2026-07-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
33	Mindfully Healing Inc	f	f	4154 Shoreline Drive Suite 202	Spring Park	MN	55384	https://mindfullyhealing.com/	\N	952-491-9450	\N	2025-02-05 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
34	Mindfully Healing Inc	f	f	101 Main Street South Suite 102	Hutchinson	MN	55350	https://mindfullyhealing.com/	\N	952-491-9450	\N	2025-02-05 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
35	Mindfully Healing Inc	f	f	10650 Red Circle Dr Suite 103	Minnetonka	MN	55343	https://mindfullyhealing.com/	\N	952-491-9450	\N	2025-02-05 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
36	Natalis Counseling and Psychology Solutions	f	f	1600 University Avenue West	St Paul	MN	55104	https://www.natalispsychology.com/	\N	651-379-5157	\N	2026-11-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
37	Northern Pines Mental Health Center Inc Provider	t	f	520 5th Street Northwest	Brainerd	MN	56401	http://www.npmh.org/	\N	218-892-3235	\N	2026-06-10 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
38	Northern Pines Mental Health Center Inc Provider	t	f	1906 5th Avenue SE	Little Falls	MN	56345	http://www.npmh.org/	\N	320-639-2025	\N	2026-06-10 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
39	Northern Pines Mental Health Center Inc Provider	t	f	16 9th Ave SE	Long Prairie	MN	56347	http://www.npmh.org/	\N	320-639-2025	\N	2026-06-10 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
40	Northern Pines Mental Health Center Inc Provider	t	f	11 2nd St W	Wadena	MN	56482	http://www.npmh.org/	\N	320-639-2025	\N	2026-06-10 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
41	Northland Counseling Center - Grand Rapids	f	f	215 SE 2nd Avenue	Grand Rapids	MN	55744	https://northlandcounseling.org/mental-health/dialectical-behavior-therapy/	\N	218-326-1274	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
42	Northland Counseling Center - International Falls	f	f	900 5th Street Suite 305	International Falls	MN	56649	http://northlandcounselingifalls.org/	\N	218-283-3406	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
43	Northland Counseling Center - Grand Rapids	f	f	3130 SE 2nd Ave	Grand Rapids	MN	55744	http://northlandcounselingifalls.org/	\N	218-283-3406	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
44	Northland Counseling Center - International Falls	f	f	1902 Valley Pine Circle	International Falls	MN	56649	http://northlandcounselingifalls.org/	\N	218-283-3406	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
45	Nystrom and Associates Ltd	f	t	1101 East 78th Street Suite 100	Bloomington	MN	55420	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	952-854-5034	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
46	Nystrom and Associates Ltd Provider	t	t	11660 Round Lake Boulevard Northwest	Coon Rapids	MN	55433	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	763-767-3350	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
47	Nystrom and Associates Ltd	f	f	332 West Superior StreetSuite 300	Duluth	MN	55802	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	218-722-4379	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
48	Nystrom and Associates Ltd Provider	t	f	11010 Prairie Lakes Drive Suite 350	Eden Prairie	MN	55344	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	952-746-2522	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
49	Nystrom and Associates Ltd Provider	t	t	17685 Juniper Path Suite 303	Lakeville	MN	55044	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	952-214-8959	\N	2026-04-06 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
50	Nystrom and Associates Ltd Provider	t	f	201 North Broad Street	Mankato	MN	56011	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy-dbt/	\N	507-225-1500	\N	2025-06-30 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
51	Nystrom and Associates Ltd Provider	t	f	13603 80th Circle North	Maple Grove	MN	55369	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	763-274-3120	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
52	Nystrom and Associates Ltd	f	f	13100 Wayzata Boulevard Suite 200	Minnetonka	MN	55305	https://www.nystromcounseling.com/	\N	952-206-2040	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
53	Nystrom and Associates Ltd Provider	t	f	1900 Silver Lake Road Suite 110	New Brighton	MN	55112	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	651-628-9566	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
54	Nystrom and Associates Ltd	f	f	9245 Quantrelle Avenue	Otsego	MN	55330	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	763-746-9492	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
55	Nystrom and Associates Ltd Provider	t	f	101 Delher Drive	St. Cloud	MN	56377	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	320-253-3512	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
56	Nystrom and Associates Ltd Provider	t	f	1811 Weir Drive Suite 270	Woodbury	MN	55125	https://www.nystromcounseling.com/our-locations/minnesota/woodbury-clinic/	\N	651-714-9646	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
57	Nystrom and Associates Ltd	f	f	2405 8th Street SouthSuite 200	Moorhead	MN	56560	https://www.nystromcounseling.com/our-services/dialectical-behavior-therapy/	\N	952-997-3020	\N	2026-12-12 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
58	Olmsted County DBT Program	f	f	2100 Campus Drive Southeast Suite 200	Rochester	MN	55904	https://www.olmstedcounty.gov/residents/services-individuals-families/adults-seniors/adult-behavioral-health#considering-dbt4	\N	507-328-6400	\N	2026-06-05 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
59	Omni Mental Health	f	t	245 Ruth Street North Suite 101	St Paul	MN	55119	https://www.omnimentalhealth.com/	\N	651-955-4633	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
60	Omni Mental Health	f	f	9298 Central Ave NE Suite 310	Blaine	MN	55434	https://www.omnimentalhealth.com/	\N	651-955-4633	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
61	Omni Mental Health	f	f	268 S Main St	Zumbrota	MN	55992	https://www.omnimentalhealth.com/	\N	651-955-4633	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
62	Omni Mental Health	f	f	2 N Minnesota St	New Ulm	MN	56073	https://www.omnimentalhealth.com/	\N	651-955-4633	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
63	Parker Collins Family Mental Health	t	f	1056 Centerville Circle	Vadnais Heights	MN	55127	https://parkercollins.com/	\N	615-604-7771	\N	2026-02-17 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
64	Psych Recovery Inc	f	f	2550 University Ave West Suite 229N	St Paul	MN	55114	http://www.psychrecoveryinc.com/dbt.html	\N	651-645-3115	\N	2028-09-21 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
65	RADIAS Health Provider	t	f	166 4th Street East	St Paul	MN	55101	http://www.south-metro.org/programs/	\N	651-389-4690	\N	2026-04-20 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
66	Riverstone Psychological Services Inc. Provider	t	f	511 Northern Hills Drive Northeast Suite 2	Rochester	MN	55906	https://www.riverstonepsych.com/	\N	507-696-2523	\N	2024-12-16 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
67	Schmidt Counseling Services Inc dba Southbridge Counseling Associates	f	f	8646 Eagle Creek Circle Suite 213	Savage	MN	55378	http://www.southbridgecounseling.com/	\N	952-583-1055	\N	2024-11-03 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
68	Secure Base Counseling Center Provider	t	f	570 Professional Drive	Northfield	MN	55057	https://www.securebasecounselingcenter.com/	\N	507-301-3412	\N	2026-05-26 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
69	Secure Base Counseling Center Provider	t	f	213 First St	Farmington	MN	55024	https://www.securebasecounselingcenter.com/	\N	507-301-3412	\N	2026-05-26 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
70	Secure Base Counseling Center Provider	t	t	301 E Main St	New Prague	MN	56071	https://www.securebasecounselingcenter.com/	\N	507-301-3412	\N	2026-05-26 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
71	Solutions Behavioral Health Center	f	f	891 Belsly Boulevard	Moorhead	MN	56560	https://www.solutionsinpractice.org/	\N	218-287-4338	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
72	Solutions Behavioral Health Center	f	f	1104 West River Road	Detroit Lakes	MN	56051	https://www.solutionsinpractice.org/	\N	218-844-6853	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
73	Solutions Behavioral Health Center	f	f	1806 Fir Avenue E Suite 200	Fergus Falls	MN	56537	https://www.solutionsinpractice.org/	\N	218-988-2992	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
74	Solutions Behavioral Health Center	f	f	423 Great Oak Dr	Waite Park	MN	56387	https://www.solutionsinpractice.org/	\N	320-281-5305	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
75	Tiny Tree Counseling & Consulting LLC	f	t	3950 Lyndale Ave S Suite 2	Minneapolis	MN	55409	https://www.tinytreecounseling.com/	tiny-tree-counseling.png	833-482-5546	support@tinytreecounseling.com	2025-03-04 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
76	Tubman Chrysalis Center	f	f	4432 Chicago Avenue South	Minneapolis	MN	55407	https://www.tubman.org/	\N	612-870-2426	\N	2024-05-07 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
77	Volunteers of America of MN Mental Health Clinic dba Vona Center for Mental Health by Volunteers of America of MN Provider	t	t	9220 Bass Lake Road Suite 255	New Hope	MN	55422	http://www.voamnwi.org/dbt-outpatient-therapy	\N	763-225-4029	\N	2026-08-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
78	Washburn Center for Children	f	f	1100 Glenwood Ave	Minneapolis	MN	55405	https://washburn.org/	\N	612-871-1454	\N	2025-06-26 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
79	Western Mental Health Clinic Provider	t	f	1212 East College Drive	Marshall	MN	56258	http://wmhcinc.org/	\N	507-532-3236	\N	2026-07-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
80	Western Mental Health Clinic Provider	t	t	112 St. Olaf Ave S	Canby	MN	56220	http://wmhcinc.org/	\N	800-658-2429	\N	2026-07-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
81	Western Mental Health Clinic Provider	t	t	818 Prentice Drive	Granite Falls	MN	56241	http://wmhcinc.org/	\N	800-658-2449	\N	2026-07-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
82	Western Mental Health Clinic Provider	t	t	2001 Maple St	Slayton	MN	56172	http://wmhcinc.org/	\N	800-658-2249	\N	2026-07-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
83	Western Mental Health Clinic Provider	t	f	101 Caring Way	Redwood Falls	MN	56283	http://wmhcinc.org/	\N	507-532-3236	\N	2026-07-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
84	Western Mental Health Clinic Provider	t	f	2042 Juniper Drive	Slayton	MN	56172	http://wmhcinc.org/	\N	800-658-2429	\N	2026-07-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
85	Western Mental Health Clinic Provider	t	f	240 Willow St	Tyler	MN	56178	http://wmhcinc.org/	\N	800-658-2429	\N	2026-07-31 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
86	Wholehearted Healing LLC	f	f	6381 Osgood Ave North Building C	Stillwater	MN	55082	https://www.wholeheartedhealingllc.com/	\N	612-217-1560	\N	2025-07-18 00:00:00+00	2	2026-03-13 04:41:51.472234+00	2026-03-13 04:41:51.472234+00
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.session (sid, sess, expire) FROM stdin;
-TSR2yIywfsEWrBN6vLIzMt0-EFh5E3X	{"cookie":{"originalMaxAge":604800000,"expires":"2026-03-20T18:51:22.921Z","secure":false,"httpOnly":true,"path":"/"},"passport":{"user":1}}	2026-03-20 18:51:23
NVl02c-Qvdgq2akHRePG4TAMbK4juELJ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-03-20T18:58:10.892Z","secure":false,"httpOnly":true,"path":"/"}}	2026-03-20 18:58:22
AzQZYRNIue5YOoJG2_cgCJn87jqSV-Cc	{"cookie":{"originalMaxAge":604800000,"expires":"2026-03-20T21:23:11.644Z","secure":false,"httpOnly":true,"path":"/"},"passport":{"user":2}}	2026-03-20 21:53:57
aiwNN9PjCQsusxij8ShG26uf3b6tEOha	{"cookie":{"originalMaxAge":604800000,"expires":"2026-03-20T21:30:51.559Z","secure":false,"httpOnly":true,"path":"/"}}	2026-03-20 21:30:52
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.users (id, username, password, inserted_at, updated_at) FROM stdin;
1	playwright_user_1773427879363	$2a$10$Jc5H9Ep5LOvsKBd4mDuLzeV7SFknuk/uW3hhfc4wi5rVK6E4ECPcO	2026-03-13 18:51:22.732637+00	2026-03-13 18:51:22.732637+00
2	tinytree	$2a$10$1tEEFNxiNR5Z7Zt0PwqkD.7q2J8CtYKyLGureNQJDTkieO/oTZ.pK	2026-03-13 18:57:52.198114+00	2026-03-13 18:57:52.198114+00
\.


--
-- Name: providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.providers_id_seq', 86, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: providers providers_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: users on_user_update; Type: TRIGGER; Schema: public; Owner: db
--

CREATE TRIGGER on_user_update BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_to_now();


--
-- Name: providers providers_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict qk7lCBpVd2rcLJsw5Y7MNMqJdgvULu1vcgUO1YlVmRGiRK9aqYqjppp7tI64kHS

